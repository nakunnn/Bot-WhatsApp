const fs = require('fs')

//settings bot
global.owner = ["6285726013874", "38367043559609"]
global.namaowner = "Nakun"
global.reply = "https://d.top4top.io/p_3754p8kpa0.jpg"
global.status = true
global.prefa = ["."];
global.channelJid = "120363425454088709@newsletter" // ID channel Anda
global.channelName = "NakunStore" // Nama channel Anda

// Settings Panel Pterodactyl 
global.egg = "15"; // Egg ID
global.nestid = "5"; // Nest ID
global.loc = "1"; // Location ID
global.domain = "https://renmods.panel-prvt.web.id/";
global.apikey = ""; // PTLC
global.capikey = "ptla_pIBk2hBMgwk0cp3m606bPake7GJsPm2BY46eLu3k0NT"; // PTLA Fallback
global.capikeys = [
    "ptla_pIBk2hBMgwk0cp3m606bPake7GJsPm2BY46eLu3k0NT", // Key 1
    "ptla_fnDLh14qmCeGWZQoDuRxFfcvRCW4wNf2n0WuSk20SOv", // Key 2
    "ptla_HAdRSB3GjS8DWan8zvBXjXYlS7daeE5eEr0vJXJex24"  // Key 3
];

//mess
global.mess = {
	owner: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Khusus Owner Bot ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	admin: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Khusus Admin Group ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	botAdmin: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Bot Harus Jadi Admin Terlebih dahulu ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	group: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya berlaku di Group ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	private: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya dapat di lakukan di private cht ⚠️
╰━━━━━━━━━━━━━━━━━⬣`,
	murbug: `╭━━〔 𝐀𝐤𝐬𝐞𝐬 𝐃𝐢 𝐓𝐨𝐥𝐚𝐤 ❌ 〕━⬣
┃ Fitur Ini Hanya Untuk User Premium ⚠️
╰━━━━━━━━━━━━━━━━━⬣`
}


//nama seticker
global.packname = 'Nakun'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

//End Settings

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})
