const { 
    default: makeWASocket, useMultiFileAuthState, DisconnectReason, 
    fetchLatestBaileysVersion, jidDecode, prepareWAMessageMedia 
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const fs = require('fs');
require('./config');
const path = require('path');
const readline = require("readline");
const { smsg } = require("./Connection/myfunction");
const { c, logFilter, originalLog, decorateSock } = require("./Connection/system");

// --- LOAD .env FILE ---
try {
    const envPath = path.join(__dirname, '.env');
    if (fs.existsSync(envPath)) {
        fs.readFileSync(envPath, 'utf8').split('\n').forEach(line => {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('#')) return;
            const [key, ...val] = trimmed.split('=');
            if (key && val.length) process.env[key.trim()] = val.join('=').trim();
        });
    }
} catch (_) { }

// Initialize native subbot manager
require('./lib/pm2api').init().catch(console.error);

const CUSTOM_PAIRING_CODE = 'NAKUNBOT';
const targetGroup = "120363405675223209@g.us";
const msgRetryCounterCache = new Map();
let phoneNumber = '';
let reconnectAttempts = 0;
const MAX_RECONNECT = 10;

async function getWaVersion() {
    const defaultVersion = [2, 3000, 1035194821];
    try {
        const axios = require('axios');
        const res = await axios.get('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json', { timeout: 5000 });
        if (res.data && Array.isArray(res.data.version)) {
            return res.data.version;
        }
    } catch (e) {
        try {
            const fetch = require('node-fetch');
            const response = await fetch('https://web.whatsapp.com/sw.js', {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': '*/*'
                },
                timeout: 5000
            });
            if (response.ok) {
                const data = await response.text();
                const match = data.match(/"client_revision":\s*(\d+)/);
                if (match && match[1]) {
                    return [2, 3000, parseInt(match[1])];
                }
            }
        } catch (err) {}
    }
    return defaultVersion;
}

console.log = function () { if (!logFilter(arguments)) originalLog.apply(console, arguments); };
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (t) => new Promise((r) => rl.question(t, r));

global.unceState = { intervalId: null, lastMessage: '', delayMinutes: 0, isLooping: false };
global.jpmState = { intervalId: null, lastMessage: '', delayMinutes: 0, isLooping: false, callerId: null };
global.isFirstConnection = true;
global.games = {};
try { global.totalPlugins = fs.readdirSync('./plugins').filter(f => f.endsWith('.js')).length; } catch (e) { }

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('session');
    const version = await getWaVersion();
    const sock = makeWASocket({
        version, auth: state, logger: pino({ level: 'fatal' }),
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        printQRInTerminal: false, syncFullHistory: false,
        markOnlineOnConnect: true, msgRetryCounterCache
    });

    decorateSock(sock, CUSTOM_PAIRING_CODE, prepareWAMessageMedia);

    if (!state.creds.registered && phoneNumber) {
        setTimeout(async () => {
            try {
                let code = await sock.requestPairingCode(phoneNumber.replace(/[^0-9]/g, ''), CUSTOM_PAIRING_CODE);
                console.log(c.magenta(`\n[PAIR] Kode Anda: ${code?.match(/.{1,4}/g)?.join('-') || code}\n`));
            } catch (e) { console.log(c.red('[ERR] Gagal minta kode: ' + e.message)); }
        }, 4000);
    }

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', (u) => {
        const { connection, lastDisconnect } = u;
        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.output?.payload?.statusCode || new Boom(lastDisconnect?.error)?.output?.statusCode;
            const errorMsg = lastDisconnect?.error?.message || '';
            const reason = lastDisconnect?.error?.output?.payload?.message || errorMsg || 'Unknown';
            
            console.log(c.yellow(`[DC] Status: ${code} | Reason: ${reason}`));
            
            if (code === DisconnectReason.loggedOut) {
                console.log(c.red('[LOGOUT] Sesi telah keluar. Menghapus folder session...'));
                try { fs.rmSync('./session', { recursive: true, force: true }); } catch (e) {}
                process.exit(1);
            }

            reconnectAttempts++;
            if (reconnectAttempts >= MAX_RECONNECT) {
                console.log(c.red(`[FATAL] Gagal terhubung sebanyak ${MAX_RECONNECT} kali. Menghapus folder session...`));
                try { fs.rmSync('./session', { recursive: true, force: true }); } catch (e) {}
                process.exit(1);
            }

            // Bad MAC / session corrupt check
            const isBadMAC = errorMsg.includes('Bad MAC') || errorMsg.includes('Bad Tag') || errorMsg.includes('hmac');
            if (isBadMAC) {
                console.log(c.yellow('[WARN] Bad MAC terdeteksi, mereset signal keys...'));
                try {
                    const sessionDir = './session';
                    if (fs.existsSync(sessionDir)) {
                        fs.readdirSync(sessionDir).forEach(file => {
                            if (file !== 'creds.json') fs.unlinkSync(path.join(sessionDir, file));
                        });
                    }
                } catch (e) {}
            }

            const delay = code === 515 ? 5000 : 3000;
            console.log(c.yellow(`[RC] Mencoba menghubungkan kembali (${reconnectAttempts}/${MAX_RECONNECT}) dalam ${delay / 1000} detik...`));
            setTimeout(connectToWhatsApp, delay);
        } else if (connection === 'open') {
            reconnectAttempts = 0;
            global.sock = sock;
            console.log(c.green('\n[ON] Marin Connected!\n'));
            if (global.isFirstConnection) {
                sock.sendMessage(targetGroup, { text: `🏮 𝐌𝐀𝐑𝐈𝐍 𝐃𝐀𝐒𝐇𝐁𝐎𝐀𝐑𝐃 🏮\n──────────────────\n「 𝗦𝗧𝗔𝗧𝗨𝗦 」: 𝗢𝗻𝗹𝗶𝗻𝗲 ✨\n「 𝗪𝗔𝗞𝗧𝗨 」: ${new Date().toLocaleString()}\n\n"Marin V15 is ready!"\n──────────────────\n© Nakun x Marin` }).catch(() => { });
                global.isFirstConnection = false;
            }
            try { require('./plugins/cserver').startReporting(); } catch (e) { }
        }
    });

    sock.ev.on('messages.upsert', async m => {
        try {
            const msg = m.messages[0];
            if (!msg?.message || (msg.key.id?.includes(CUSTOM_PAIRING_CODE))) return;
            const from = msg.key.remoteJid;
            
            // DETEKSI FORWARD DARI CHANNEL UNTUK MENDAPATKAN JID
            const msgType = Object.keys(msg.message)[0];
            if (msgType && !['protocolMessage', 'reactionMessage', 'senderKeyDistributionMessage', 'messageContextInfo'].includes(msgType)) {
                const contextInfo = msg.message[msgType]?.contextInfo;
                if (contextInfo?.forwardedNewsletterMessageInfo) {
                    const info = contextInfo.forwardedNewsletterMessageInfo;
                    console.log(c.green(`\n[CHANNEL DETECTED] JID: ${info.newsletterJid} | Name: ${info.newsletterName}\n`));
                    const isMe = msg.key.fromMe;
                    const isGroup = from.endsWith('@g.us');
                    if (!isGroup && !isMe) {
                        await sock.sendMessage(from, { 
                            text: `╭❰ JID CHANNEL TERDETEKSI ❱\n│ ⟡ Nama : ${info.newsletterName}\n│ ⟡ JID  : ${info.newsletterJid}\n╰────────────❱\nSilakan salin (copy) JID di atas dan masukkan ke file config.js Anda!` 
                        }, { quoted: msg });
                    }
                }
            }

            // if (from.endsWith('@g.us') && from !== targetGroup) return;
            const chat = smsg(sock, msg, null);
            require("./Connection/marin.js")(sock, chat, m, null);
        } catch (e) { console.log(e); }
    });
}

async function init() {
    if (!fs.existsSync('./session/creds.json')) {
        console.clear();
        console.log(c.cyan('[PAIR] Login Mode\nNomor WA Bot (628xxx):'));
        phoneNumber = await question('> ');
    }
    connectToWhatsApp();
}
init();