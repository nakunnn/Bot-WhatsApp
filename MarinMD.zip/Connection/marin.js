require("../config");
const fs = require("fs");
const axios = require("axios");
const chalk = require("chalk");
const path = require("path");
const os = require("os");
const moment = require("moment-timezone");
const sharp = require("sharp");
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

/**
 * MARIN MASTER HANDLER (INDUK)
 * Digabung dengan fitur Middleware dari Helper (AFK, Game, Maintenance, RVO, AR)
 */
module.exports = async (sock, m, chatUpdate, store) => {
    try {
        const from = m.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const targetGroup = "120363405675223209@g.us";
        const isPM = !isGroup;
        const isTargetGroup = from === targetGroup;

        // --- SILENT FILTER: Hemat RAM, abaikan chat selain PM & Target Group ---
        // if (!isPM && !isTargetGroup) return;

        const body = m.body || "";
        const budy = JSON.stringify(m.message);
        const sender = m.key.fromMe ? sock.user.id.split(":")[0] + "@s.whatsapp.net" || sock.user.id : m.key.participant || m.key.remoteJid;
        const pushname = m.pushName || "No Name";

        // --- MIDDLEWARE 1: MAINTENANCE MODE ---
        const maintenancePath = "./Connection/database/maintenance.json";
        if (fs.existsSync(maintenancePath)) {
            const mntData = JSON.parse(fs.readFileSync(maintenancePath));
            if (mntData.status && !body.includes("maintenance")) {
                const isOwner = [sock.decodeJid(sock.user.id), ...JSON.parse(fs.readFileSync("./Connection/database/owner.json")), ...global.owner].map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender);
                if (!isOwner) return; // Skip if maintenance and not owner
            }
        }

        // --- MIDDLEWARE 2: RVO (Read View Once) ---
        if (m.mtype === 'viewOnceMessageV2' || m.mtype === 'viewOnceMessage') {
            try {
                const { handleRVO } = require('../plugins/rvo');
                await handleRVO(sock, m);
            } catch (e) { }
        }

        // --- MIDDLEWARE 3: AFK CHECKER ---
        const afkFile = "./Connection/database/afk.json";
        if (fs.existsSync(afkFile) && !body.startsWith('.afk')) {
            let afkData = JSON.parse(fs.readFileSync(afkFile));
            if (afkData[sender]) {
                const afkTime = Date.now() - afkData[sender].time;
                const hours = Math.floor(afkTime / 3600000);
                const minutes = Math.floor((afkTime % 3600000) / 60000);
                const seconds = Math.floor((afkTime % 60000) / 1000);
                let timeString = (hours > 0 ? `${hours} jam ` : "") + (minutes > 0 ? `${minutes} menit ` : "") + `${seconds} detik`;
                delete afkData[sender];
                fs.writeFileSync(afkFile, JSON.stringify(afkData, null, 2));
                sock.sendMessage(from, { text: `╭❰ AFK ❱\n│ ⟡ Kamu telah kembali dari AFK!\n│ ⟡ Total waktu AFK: ${timeString}\n╰────────────❱\n©NakunStore` }, { quoted: m });
            }
        }

        // --- MIDDLEWARE 4: GAME CHECKER ---
        if (global.games && global.games[from]) {
            const game = global.games[from];
            if (body.toLowerCase() === game.jawaban.toLowerCase()) {
                await sock.sendMessage(from, { text: `╭❰ GAME ❱\n│ ⟡ Jawaban benar!\n│ ⟡ Jawaban: ${game.jawaban}\n╰────────────❱\n©NakunStore` }, { quoted: m });
                delete global.games[from];
                return;
            }
        }

        // Database & Status Setup
        const premium = JSON.parse(fs.readFileSync("./Connection/database/premium.json"));
        const reseller = JSON.parse(fs.readFileSync("./Connection/database/reseller.json"));
        const owner = JSON.parse(fs.readFileSync("./Connection/database/owner.json"));
        const isOwner = [sock.decodeJid(sock.user.id), ...owner, ...global.owner].map(v => v.replace(/[^0-9]/g, "")).some(id => m.sender.startsWith(id));
        const isPremium = premium.includes(m.sender) || isOwner;
        const isReseller = reseller.includes(m.sender) || isOwner;

        const prefix = global.prefa.filter(p => body.startsWith(p))[0] || "";
        const isCmd = body.startsWith(prefix);
        const command = isCmd ? body.slice(prefix.length).trim().split(" ").shift().toLowerCase() : "";
        const args = body.trim().split(/ +/).slice(1);
        const q = args.join(" ");

        const groupMetadata = isGroup ? await sock.groupMetadata(m.chat).catch(e => { }) : "";
        const participants = isGroup ? await groupMetadata.participants : "";
        const groupAdmins = isGroup ? participants.filter(v => v.admin !== null).map(v => v.id) : "";
        const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
        const isBotAdmin = isGroup ? groupAdmins.includes(sock.decodeJid(sock.user.id)) : false;

        // --- MIDDLEWARE 5: ANTI BADWORD ---
        const badwordsPath = "./Connection/database/badwords.json";
        let badwords = fs.existsSync(badwordsPath) ? JSON.parse(fs.readFileSync(badwordsPath)) : [];
        badwords = badwords.filter(w => w && typeof w === 'string');
        const abwOffPath = "./Connection/database/antibadword_off.json";
        if (isGroup && body) {
            const abwOffData = fs.existsSync(abwOffPath) ? JSON.parse(fs.readFileSync(abwOffPath)) : [];
            if (!abwOffData.includes(from)) {
                const containsBadword = badwords.some(word => body.toLowerCase().includes(word.toLowerCase()));
                if (containsBadword && !isOwner) {
                    if (isBotAdmin) {
                        await sock.sendMessage(from, { delete: m.key });
                        return;
                    }
                }
            }
        }

        const { smsg, tanggal, runtime, fetchJson, getBuffer } = require("./myfunction");
        const reply = async (text) => sock.sendMessage(m.chat, { text: text }, { quoted: m });
        const react = async (jid, emoji) => sock.sendMessage(jid, { react: { text: emoji, key: m.key } });

        if (m.message && isCmd) {
            console.log(chalk.bgHex("#e74c3c").bold("▢ New Command"));
            console.log(chalk.bgHex("#00FF00").black(`   ⌬ Cmd: ${prefix + command} | From: ${pushname} | In: ${isGroup ? 'Group' : 'Private'}`));
        }

        // --- PLUGIN LOADER ---
        if (isCmd && command) {
            const pluginsDir = path.join(__dirname, '../plugins');
            const files = fs.readdirSync(pluginsDir);

            const context = {
                sock, m, chatUpdate, store,
                args, q, body, budy, prefix, command,
                sender, pushname, from, isGroup,
                isOwner, isPremium, isReseller, isAdmins, isBotAdmin,
                participants,
                runtime, performance: performance.now(),
                reply, react,
                tanggal: tanggal(Date.now()),
                quoted: m.quoted ? m.quoted : m
            };

            for (const file of files) {
                if (file.endsWith('.js')) {
                    const plugin = require(path.join(pluginsDir, file));
                    if (!plugin.command) continue; // Skip middleware or non-command files

                    const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
                    if (commands.includes(command)) {
                        try {
                            // Check style: Marin ({ args, ... }) vs Helper (args array)
                            const argsStr = plugin.execute.toString().match(/\((.*?)\)/)?.[1] || "";
                            const isMarinStyle = argsStr.includes('{');
                            if (isMarinStyle) {
                                await plugin.execute(sock, m, context);
                            } else {
                                await plugin.execute(sock, m, context.args, context);
                            }
                        } catch (err) {
                            console.error(`[ERR] .${command}:`, err);
                            try {
                                await sock.sendMessage(from, { 
                                    text: `╭❰ SYSTEM ERROR ❱\n│ ⟡ Terjadi kesalahan saat menjalankan .${command}.\n│ ⟡ Error: ${err.message}\n╰────────────❱\n©NakunStore` 
                                }, { quoted: m });
                            } catch (sendErr) {
                                console.error('Failed to send error notification:', sendErr.message);
                            }
                        }
                        return;
                    }
                }
            }
        }

    } catch (err) {
        console.error(err);
    }
};