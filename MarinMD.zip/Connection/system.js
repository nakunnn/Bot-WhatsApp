const { jidDecode, downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');

// --- COLORS ---
const c = {
    red: (t) => `\x1b[31m${t}\x1b[0m`,
    green: (t) => `\x1b[32m${t}\x1b[0m`,
    yellow: (t) => `\x1b[33m${t}\x1b[0m`,
    magenta: (t) => `\x1b[35m${t}\x1b[0m`,
    cyan: (t) => `\x1b[36m${t}\x1b[0m`,
    white: (t) => `\x1b[37m${t}\x1b[0m`,
};

// --- LOG FILTER ---
const originalLog = console.log;
const logFilter = (args) => {
    const msg = args[0];
    return typeof msg === 'string' && (
        msg.includes('Closing session') || 
        msg.includes('incoming prekey bundle') || 
        msg.includes('SessionEntry')
    );
};

// --- SOCK DECORATOR ---
const decorateSock = (sock, CUSTOM_PAIRING_CODE, prepareWAMessageMedia) => {
    sock.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return (decode.user && decode.server && decode.user + "@" + decode.server) || jid;
        } else return jid;
    };

    sock.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };

    const originalSendMessage = sock.sendMessage;
    sock.sendMessage = async (jid, content, options = {}) => {
        if (!options.messageId) {
            options.messageId = CUSTOM_PAIRING_CODE + Math.random().toString(36).substring(2, 10).toUpperCase();
        }

        // Otomatis tambahkan efek "Forwarded dari Channel" ke semua pesan teks/media/interactiveMessage dll.
        if (content && typeof content === 'object' && !content.delete && !content.react && !content.pin) {
            if (content.interactiveMessage) {
                content.interactiveMessage.contextInfo = {
                    ...(content.interactiveMessage.contextInfo || {}),
                    isForwarded: true,
                    forwardingScore: 255,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.channelJid || '120363311910609503@newsletter',
                        newsletterName: global.channelName || 'Marin MD Updates',
                        serverMessageId: 1
                    }
                };
            } else {
                content.contextInfo = {
                    ...(content.contextInfo || {}),
                    isForwarded: true,
                    forwardingScore: 255,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.channelJid || '120363311910609503@newsletter',
                        newsletterName: global.channelName || 'Marin MD Updates',
                        serverMessageId: 1
                    }
                };
            }
        }

        return originalSendMessage.call(sock, jid, content, options);
    };

    sock.prepareWAMessageMedia = prepareWAMessageMedia;

    sock.sendImageAsSticker = async (jid, media, quoted, options = {}) => {
        const { writeExifImg } = require('./database/exif');
        let stickerPath = await writeExifImg(media, {
            packname: options.packname || global.packname,
            author: options.author || global.author,
            ...options
        });
        await sock.sendMessage(jid, { sticker: { url: stickerPath } }, { quoted });
        try {
            fs.unlinkSync(stickerPath);
        } catch (e) {}
    };

    sock.sendVideoAsSticker = async (jid, media, quoted, options = {}) => {
        const { writeExifVid } = require('./database/exif');
        let stickerPath = await writeExifVid(media, {
            packname: options.packname || global.packname,
            author: options.author || global.author,
            ...options
        });
        await sock.sendMessage(jid, { sticker: { url: stickerPath } }, { quoted });
        try {
            fs.unlinkSync(stickerPath);
        } catch (e) {}
    };
};

module.exports = { c, logFilter, originalLog, decorateSock };
