module.exports = {
    command: 'pricefile',
    description: 'Menampilkan daftar harga file',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const teks = `*Harga File*

🔥 FILE FREE FIRE
*[ BASIC TOOLS ]*
🛠️ *FF V7A* — 5k
🛠️ *Panel Remote Tele* — 10k
🧹 *Penghapus File/Cheat* — 2k

*[ AIMLOCK BODY/BADAN ]*
🎯 *Aimlock 70%* — 4k
🎯 *Aimlock 89%* — 6k
🎯 *Aimlock V1* — 8k
🎯 *Aimlock V2* — 11k
🎯 *Aimlock V3 / VVIP* — 16k
🎯 *Aimlock x Eazy Drag* — 16k
🎯 *Aimlock x Stabilizer* — 16k
🎯 *Aimlock Combo 3* — 14k

*[ EASY DRAG & HS ]*
🕹️ *Easy Drag Biasa* — 4k
🕹️ *Easy Drag VVIP* — 6k
🕹️ *Easy Drag V2* — 8k
🕹️ *Easy Drag 95%* — 11k
🕹️ *Drag HS Biasa* — 6k
🎯 *Drag HS 70%* — 8k
🎯 *Drag HS 75%* — 9k
🎯 *Aim Drag 83%* — 20k

*[ COMBO STABILIZER ]*
⚡ *DRAG HS 75% + Stabilizer* — 10k
⚡ *DRAG HS 85% + Stabilizer* — 15k
⚡ *DRAG HS 89% + Stabilizer* — 28k
⚡ *DRAG HS 90% + Stabilizer* — 40k

©NakunStore`;
        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
}
