const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

const GMAIL_USER = 'nakununcheck@gmail.com';
const GMAIL_PASS = 'uqii umtz rvdd ntoy'; 

module.exports = {
    command: 'unce',
    execute: async (sock, m, { args, reply, react }) => {
        if (args.length < 2) {
            let helpText = `*〔 UNCE HELPER 〕*

Gunakan format yang benar untuk mengirim akun ke email pembeli.

*Format:* \`.unce [email] [jumlah]\`
*Contoh:* \`.unce pembeli@gmail.com 10\``;

            return sock.sendMessage(m.chat, {
                interactiveMessage: {
                    title: helpText,
                    footer: "⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫",
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Cek Stok",
                                    url: "https://wa.me/6285726013874"
                                })
                            }
                        ]
                    }
                }
            }, { quoted: m });
        }

        const emailTujuan = args[0];
        const jumlah = parseInt(args[1]);
        const stokPath = path.join(__dirname, '../media/stok.txt');

        try {
            if (!fs.existsSync(stokPath)) return reply("❌ File stok.txt tidak ditemukan!");
            
            const data = fs.readFileSync(stokPath, 'utf8').split('\n').filter(line => line.trim() !== '');
            if (data.length < jumlah) return reply(`❌ Stok tidak cukup! (Sisa: ${data.length})`);

            await react(m.chat, "⏳");

            let terpilih = data.slice(0, jumlah);
            let sisa = data.slice(jumlah);
            fs.writeFileSync(stokPath, sisa.join('\n'));

            const transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: { user: GMAIL_USER, pass: GMAIL_PASS }
            });

            let htmlContent = `<div style="background-color: #000; color: #fff; padding: 20px; font-family: monospace;"><h3>NAKUNSTORE - ORDER SUCCESS</h3>`;
            terpilih.forEach((item, index) => {
                const [mail, pass] = item.split('|');
                htmlContent += `<div style="border: 1px solid #fff; margin: 10px 0; padding: 10px;"><b>AKUN #${index+1}</b><br>Email: ${mail}<br>Pass: ${pass}</div>`;
            });
            htmlContent += `</div>`;

            await transporter.sendMail({
                from: `"NAKUNSTORE" <${GMAIL_USER}>`,
                to: emailTujuan,
                subject: `Pesanan ${jumlah} Akun Berhasil`,
                html: htmlContent
            });

            await react(m.chat, "✅");
            const successText = `╭❰ PENGIRIMAN SELESAI ❱
│ ⟡ Status: Berhasil
│ ⟡ Tujuan: ${emailTujuan}
│ ⟡ Jumlah: ${jumlah} Akun
│
│ Pesanan telah berhasil terkirim!
│ Silahkan cek inbox/spam email.
╰────────────❱
©NakunStore`;

            await reply(successText);
        } catch (err) {
            console.error(err);
            reply("❌ Gagal mengirim email. Cek log console.");
        }
    }
};
