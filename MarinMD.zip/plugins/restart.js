const pm2api = require('../lib/pm2api');

module.exports = {
    command: ['restart', 'rst', 'restartbot'],
    execute: async (sock, m, { reply, react, args }) => {

        if (args && args.length > 0) {
            const nama = args[0];
            const from = m.key.remoteJid;

            if (nama.toLowerCase() === 'all') {
                try {
                    await react(from, '🔄');
                    const subbots = await pm2api.listBots();
                    if (subbots.length === 0) {
                        return await react(from, '❌');
                    }
                    await Promise.all(subbots.map(bot => pm2api.restartBot(bot.name)));
                    await react(from, '✅');
                } catch (error) {
                    console.error('[RESTARTALL ERROR]', error);
                    await react(from, '❌');
                }
            } else {
                try {
                    await react(from, '🔄');
                    await pm2api.restartBot(nama);
                    await react(from, '✅');
                } catch (error) {
                    console.error('[RESTARTBOT ERROR]', error);
                    await react(from, '❌');
                }
            }
        } else {
            await reply("Restarting main bot...");
            process.exit();
        }
    }
};
