const os = require('os');
const { performance } = require('perf_hooks');

module.exports = {
    command: 'ping',
    execute: async (sock, m, { performance: startPerf, runtime, reply, react }) => {
        await react(m.chat, "⚡");
        
        const start = performance.now();
        const end = performance.now();
        const latency = (end - startPerf).toFixed(4);
        
        const uptime = runtime(process.uptime());
        const RAM = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
        const totalRAM = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);

        let pingText = `*〔 MARIN STATUS 〕*

🚀 *Latency:* ${latency} ms
⏳ *Runtime:* ${uptime}
📉 *RAM Usage:* ${RAM} MB / ${totalRAM} GB
🖥️ *Platform:* ${os.platform()} (${os.release()})
📡 *Server:* Google Cloud / Linux`;

        await sock.sendMessage(m.chat, {
            interactiveMessage: {
                title: "SYSTEM PERFORMANCE\n\n" + pingText,
                footer: "⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫",
                nativeFlowMessage: {
                    buttons: [
                        {
                            name: "cta_url",
                            buttonParamsJson: JSON.stringify({
                                display_text: "Owner",
                                url: "https://wa.me/6285726013874"
                            })
                        },
                        {
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "Refresh",
                                id: ".ping"
                            })
                        }
                    ]
                }
            }
        }, { quoted: m });
    }
};
