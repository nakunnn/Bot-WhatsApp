const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'listpanel',
    description: 'Menampilkan daftar data panel yang tersimpan',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const dbFile = path.join(__dirname, '../database/data_panel.json');

        if (!fs.existsSync(dbFile)) {
            const teksKosong = `╭❰ LIST DATA PANEL ❱\n│ ⟡ Belum ada data panel yang disimpan.\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: teksKosong }, { quoted: msg });
        }

        let dataPanel = [];
        try {
            const rawData = fs.readFileSync(dbFile, 'utf8');
            if (rawData) {
                dataPanel = JSON.parse(rawData);
            }
        } catch (e) {
            const teksError = `╭❰ ERROR ❱\n│ ⟡ Gagal membaca database panel\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: teksError }, { quoted: msg });
        }

        if (dataPanel.length === 0) {
            const teksKosong = `╭❰ LIST DATA PANEL ❱\n│ ⟡ Belum ada data panel yang disimpan.\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: teksKosong }, { quoted: msg });
        }

        const listText = dataPanel.map((item, index) => {
            const statusStr = item.status ? ` [${item.status}]` : '';
            return `│ ⟡ ${index + 1}. ${item.username} (${item.tanggal || '-'})${statusStr}`;
        }).join('\n');

        const teks = `╭❰ LIST DATA PANEL ❱
${listText}
│ 
│ ⟡ Total Data: ${dataPanel.length}
│ ⟡ Keterangan:
│   on = terpakai
│   off = tidak terpakai
╰────────────❱
©NakunStore`;

        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
