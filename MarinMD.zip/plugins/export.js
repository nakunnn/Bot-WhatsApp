const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');
const { loadRevenue } = require('../lib/gsheets');

module.exports = {
    command: 'export',
    description: 'Ekspor data omzet dari Google Sheets ke file Excel (.xlsx) dan kirimkan',
    execute: async (sock, m, { reply, react }) => {
        const from = m.key.remoteJid;

        await react(m.chat, '⏳');
        await reply(`╭❰ EXPORT OMZET ❱\n│ ⟡ Sedang mengambil data dari Google Sheets...\n│ ⟡ Harap tunggu sebentar\n╰────────────❱\n©NakunStore`);

        // ── Ambil semua data dari Google Sheets ──────────────────
        const db = await loadRevenue();

        if (!db || db.length === 0) {
            await react(m.chat, '❌');
            return reply(`╭❰ EXPORT GAGAL ❱\n│ ⟡ Belum ada data omzet di Google Sheets\n│ ⟡ Gunakan .calc confirm untuk memasukkan data\n╰────────────❱\n©NakunStore`);
        }

        // ── Buat workbook Excel ───────────────────────────────────
        const workbook = new ExcelJS.Workbook();
        workbook.creator = 'NakunStore Bot';
        workbook.created = new Date();

        const worksheet = workbook.addWorksheet('Omzet', {
            pageSetup: { paperSize: 9, orientation: 'landscape' }
        });

        // ── Style header ──────────────────────────────────────────
        const headerFill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FF1A1A2E' }   // warna gelap seperti tema bot
        };
        const headerFont = { bold: true, color: { argb: 'FFFFD700' }, size: 11 }; // kuning emas
        const headerAlignment = { horizontal: 'center', vertical: 'middle' };
        const borderStyle = {
            top: { style: 'thin', color: { argb: 'FFFFD700' } },
            left: { style: 'thin', color: { argb: 'FFFFD700' } },
            bottom: { style: 'thin', color: { argb: 'FFFFD700' } },
            right: { style: 'thin', color: { argb: 'FFFFD700' } }
        };

        // ── Definisi kolom ────────────────────────────────────────
        worksheet.columns = [
            { header: 'No',                        key: 'no',               width: 5  },
            { header: 'Tanggal',                   key: 'tanggal',          width: 14 },
            { header: 'Waktu',                     key: 'waktu',            width: 10 },
            { header: 'Produk / Keterangan',       key: 'keterangan',       width: 30 },
            { header: 'Kategori',                  key: 'kategori',         width: 12 },
            { header: 'Uang Masuk (Rp)',           key: 'masuk',            width: 18 },
            { header: 'Untung Owner (Rp)',          key: 'untung_me',        width: 18 },
            { header: 'Untung Reseller (Rp)',      key: 'untung_reseller',  width: 20 },
            { header: 'Trx',                       key: 'trx',              width: 6  },
        ];

        // Style baris header
        const headerRow = worksheet.getRow(1);
        headerRow.height = 22;
        headerRow.eachCell((cell) => {
            cell.fill = headerFill;
            cell.font = headerFont;
            cell.alignment = headerAlignment;
            cell.border = borderStyle;
        });

        // ── Format angka rupiah ───────────────────────────────────
        const rpFormat = '#,##0';

        // ── Isi data ──────────────────────────────────────────────
        let totalMasuk = 0, totalMe = 0, totalReseller = 0, totalTrx = 0;

        db.forEach((item, idx) => {
            const row = worksheet.addRow({
                no:              idx + 1,
                tanggal:         item.tanggal,
                waktu:           item.waktu,
                keterangan:      item.keterangan,
                kategori:        item.kategori,
                masuk:           Number(item.masuk) || 0,
                untung_me:       Number(item.untung_me) || 0,
                untung_reseller: Number(item.untung_reseller) || 0,
                trx:             Number(item.trx) || 1,
            });

            // Alternating row color
            const bgColor = idx % 2 === 0 ? 'FFF5F5F5' : 'FFFFFFFF';
            row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                cell.border = {
                    top:    { style: 'hair' },
                    left:   { style: 'hair' },
                    bottom: { style: 'hair' },
                    right:  { style: 'hair' }
                };
                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgColor } };
                cell.alignment = { vertical: 'middle' };
            });

            // Format kolom rupiah
            ['masuk', 'untung_me', 'untung_reseller'].forEach(key => {
                const colIdx = worksheet.columns.findIndex(c => c.key === key) + 1;
                const cell = row.getCell(colIdx);
                cell.numFmt = rpFormat;
                cell.alignment = { horizontal: 'right', vertical: 'middle' };
            });

            // Kolom nomor & trx center
            row.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
            row.getCell(9).alignment = { horizontal: 'center', vertical: 'middle' };

            totalMasuk     += Number(item.masuk) || 0;
            totalMe        += Number(item.untung_me) || 0;
            totalReseller  += Number(item.untung_reseller) || 0;
            totalTrx       += Number(item.trx) || 1;
        });

        // ── Baris total ───────────────────────────────────────────
        const totalRow = worksheet.addRow({
            no:              '',
            tanggal:         'TOTAL',
            waktu:           '',
            keterangan:      `${db.length} entri`,
            kategori:        '',
            masuk:           totalMasuk,
            untung_me:       totalMe,
            untung_reseller: totalReseller,
            trx:             totalTrx,
        });
        totalRow.height = 20;
        totalRow.eachCell({ includeEmpty: true }, (cell, colNumber) => {
            cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1A1A2E' } };
            cell.border = borderStyle;
            cell.alignment = { vertical: 'middle' };
        });

        // Format angka di baris total
        ['masuk', 'untung_me', 'untung_reseller'].forEach(key => {
            const colIdx = worksheet.columns.findIndex(c => c.key === key) + 1;
            const cell = totalRow.getCell(colIdx);
            cell.numFmt = rpFormat;
            cell.alignment = { horizontal: 'right', vertical: 'middle' };
        });
        totalRow.getCell(2).alignment  = { horizontal: 'center', vertical: 'middle' };
        totalRow.getCell(9).alignment  = { horizontal: 'center', vertical: 'middle' };

        // ── Freeze pane header ────────────────────────────────────
        worksheet.views = [{ state: 'frozen', ySplit: 1 }];

        // ── Simpan file sementara ─────────────────────────────────
        const now        = new Date();
        const stamp      = now.toLocaleDateString('id-ID', {
            timeZone: 'Asia/Jakarta',
            day: '2-digit', month: '2-digit', year: 'numeric'
        }).replace(/\//g, '-');

        const tmpDir     = path.join(__dirname, '../temp_screenshots');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

        const fileName   = `Omzet_NakunStore_${stamp}.xlsx`;
        const filePath   = path.join(tmpDir, fileName);

        await workbook.xlsx.writeFile(filePath);

        // ── Kirim file ke WhatsApp ────────────────────────────────
        const fmt = (n) => Number(n).toLocaleString('id-ID');
        const caption = `╭❰ EXPORT OMZET ❱
│ ⟡ File   : ${fileName}
│ ⟡ Entri  : ${db.length} transaksi
│ ⟡ Total Trx       : ${totalTrx}
│ ⟡ Uang Masuk      : Rp ${fmt(totalMasuk)}
│ ⟡ Untung Owner    : Rp ${fmt(totalMe)}
│ ⟡ Untung Reseller : Rp ${fmt(totalReseller)}
╰────────────❱
©NakunStore`;

        await sock.sendMessage(
            from,
            {
                document: fs.readFileSync(filePath),
                fileName: fileName,
                caption: caption,
                mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            },
            { quoted: m }
        );

        await react(m.chat, '✅');

        // Hapus file temp setelah terkirim
        fs.unlink(filePath, () => {});
    }
};
