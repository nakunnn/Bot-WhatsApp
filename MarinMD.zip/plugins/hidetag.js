module.exports = {
    command: 'ht',
    execute: async (sock, m, { q, isGroup, isOwner, isAdmins, participants, reply, quoted }) => {
        if (!isGroup) return reply("Fitur ini hanya dapat digunakan di dalam grup!");
        if (!isAdmins && !isOwner) return reply("Fitur ini khusus untuk admin grup atau owner bot!");
        if (!q) return reply("Teks?");

        const mentions = participants.map(p => p.id);

        if (m.quoted) {
            sock.sendMessage(m.chat, {
                forward: m.quoted.fakeObj,
                mentions: mentions
            });
        } else {
            sock.sendMessage(m.chat, {
                text: q,
                mentions: mentions
            }, { quoted: quoted });
        }
    }
};
