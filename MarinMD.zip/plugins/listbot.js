// Plugin: listbot.js
// Alias dari status.js - memanggil execute status langsung

const statusPlugin = require('./status');

module.exports = {
    command: ['listbot', 'lb'],
    description: 'Tampilkan daftar bot yang berjalan di PM2',
    execute: (sock, msg, args) => statusPlugin.execute(sock, msg, args)
};
