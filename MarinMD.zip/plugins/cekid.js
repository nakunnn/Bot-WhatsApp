module.exports = {
    command: 'cekid',
    description: 'Cek ID Chat / Saluran / Group',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        
        let targetId = from;
        let type = 'Chat';

        if (from.endsWith('@g.us')) type = 'Group';
        if (from.endsWith('@newsletter')) type = 'Saluran (Newsletter)';

        // Cek jika mereply pesan
        const quoted = msg.message?.extendedTextMessage?.contextInfo;
        if (quoted?.quotedMessage) {
            // Cek jika yang direply adalah pesan dari saluran (newsletter)
            const newsletterInfo = quoted.quotedMessage.newsletterAdminMessage?.newsletterJid || 
                                 quoted.forwardedNewsletterMessageInfo?.newsletterJid;
            
            if (newsletterInfo) {
                targetId = newsletterInfo;
                type = 'Saluran (Newsletter) dari Reply';
            }
        }

        const teks = `╭❰ CEK ID ❱
│ ⟡ Tipe : ${type}
│ ⟡ ID   : ${targetId}
╰────────────❱
Gunakan ID ini di file konfigurasi plugin Anda.`;

        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
