const axios = require('axios');

module.exports = {
    command: 'dl',
    description: 'All-in-One Downloader tanpa token',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        
        // Mengambil nomor murni tanpa ID WhatsApp lengkap
        const senderNumber = sender.split('@')[0].split(':')[0];

        if (args.length === 0) {
            return sock.sendMessage(from, { text: 'Masukkan link yang ingin diunduh!\nContoh: .dl https://www.tiktok.com/@user/video/123' }, { quoted: msg });
        }

        const url = args[0];
        const apiUrl = `https://api.nexray.eu.cc/downloader/aio?url=${encodeURIComponent(url)}`;

        // Indikator loading
        await sock.sendMessage(from, { text: '⏳ Sedang memproses URL, mohon tunggu sebentar...' }, { quoted: msg });

        try {
            // Melakukan request ke API dengan batas waktu 30 detik
            const response = await axios.get(apiUrl, { timeout: 30000 });
            const data = response.data;

            // ==========================================
            // [!] SESUAIKAN PATH JSON RESPONSE DI SINI
            // Karena struktur API bervariasi, sesuaikan cara mengambil URL di bawah ini
            // ==========================================
            let mediaUrl = '';
            
            // Contoh struktur 1: { result: { url: "..." } }
            if (data?.result?.url) {
                mediaUrl = data.result.url;
            } 
            // Contoh struktur 2: { data: { media: "..." } }
            else if (data?.data?.media) {
                mediaUrl = data.data.media;
            } 
            // Contoh struktur 3: { url: "..." }
            else if (data?.url) {
                mediaUrl = data.url;
            } 
            // Jika struktur JSON dari API berbeda dari tebakan di atas, tambahkan log dan periksa:
            // console.log(JSON.stringify(data, null, 2));

            if (!mediaUrl) {
                return sock.sendMessage(from, { text: 'Gagal mengekstrak media. Struktur JSON API mungkin berubah atau URL media tidak ditemukan.' }, { quoted: msg });
            }

            // Template caption yang diminta
            const caption = `╭❰ NAKUN DOWNLOADER ❱
│ ⟡ Owner : 6285726013874
│ ⟡ Feature : AIO Downloader
╰────────────❱
╭❰ INFO ❱
│ ⟡ User : @${senderNumber} 
╰────────────❱

Media berhasil diunduh!`;

            // Tentukan tipe media secara sederhana dari ekstensi URL (opsional, sebagai tebakan awal)
            const isVideo = mediaUrl.toLowerCase().includes('.mp4') || mediaUrl.toLowerCase().includes('.webm');
            
            try {
                if (isVideo) {
                    await sock.sendMessage(from, { 
                        video: { url: mediaUrl }, 
                        caption: caption,
                        mentions: [sender]
                    }, { quoted: msg });
                } else {
                    // Jika ekstensi bukan video, kita coba jadikan image
                    // Karena URL AIO kadang menyembunyikan ekstensi, jika error kita akan gunakan blok catch
                    await sock.sendMessage(from, { 
                        image: { url: mediaUrl }, 
                        caption: caption,
                        mentions: [sender]
                    }, { quoted: msg });
                }
            } catch (mediaError) {
                // Jika Baileys gagal memprosesnya sebagai image/video spesifik (mismatch tipe), 
                // kita kirim menggunakan mode document (berlaku untuk semua tipe file)
                await sock.sendMessage(from, { 
                    document: { url: mediaUrl },
                    mimetype: 'application/octet-stream',
                    fileName: 'downloaded_media',
                    caption: caption,
                    mentions: [sender]
                }, { quoted: msg });
            }

        } catch (error) {
            console.error('[ERR] AIO Downloader Fetch:', error.message);
            await sock.sendMessage(from, { text: 'Terjadi kesalahan saat menghubungi server API (API Down / Timeout).' }, { quoted: msg });
        }
    }
};
