const { loadRevenue } = require('../lib/gsheets');

module.exports = {
    command: 'omzet',
    description: 'Menampilkan ringkasan omzet hari ini dan total dari Google Sheets',
    execute: async (sock, m, { reply, react }) => {
        await react(m.chat, '📊');

        // Ambil semua data dari Google Sheets
        const db = await loadRevenue();

        if (!db || db.length === 0) {
            return reply(`╭❰ DATA KOSONG ❱
│ ⟡ Belum ada data omzet
│ ⟡ Gunakan command .calc confirm
│   untuk memasukkan data
╰────────────❱
©NakunStore`);
        }

        // Tanggal hari ini dalam format dd/mm/yyyy (sesuai format yang disimpan)
        const hariIni = new Date().toLocaleDateString('id-ID', {
            timeZone: 'Asia/Jakarta',
            day: '2-digit', month: '2-digit', year: 'numeric'
        });

        let statHariIni = { masuk: 0, untung_me: 0, untung_reseller: 0, trx: 0 };
        let statTotal   = { masuk: 0, untung_me: 0, untung_reseller: 0, trx: 0 };

        for (const item of db) {
            const itemMasuk    = Number(item.masuk) || 0;
            const itemMe       = Number(item.untung_me) || 0;
            const itemReseller = Number(item.untung_reseller) || 0;
            const itemTrx      = Number(item.trx) || 1;

            statTotal.masuk            += itemMasuk;
            statTotal.untung_me        += itemMe;
            statTotal.untung_reseller  += itemReseller;
            statTotal.trx              += itemTrx;

            if (item.tanggal === hariIni) {
                statHariIni.masuk           += itemMasuk;
                statHariIni.untung_me       += itemMe;
                statHariIni.untung_reseller += itemReseller;
                statHariIni.trx            += itemTrx;
            }
        }

        const fmt = (n) => n.toLocaleString('id-ID');

        const templateLaporan = `╭❰ DATA OMZET ❱
│ ⟡ [ HARI INI — ${hariIni} ]
│ ⟡ Total Trx        : ${statHariIni.trx}
│ ⟡ Uang Masuk       : Rp ${fmt(statHariIni.masuk)}
│ ⟡ Untung Owner     : Rp ${fmt(statHariIni.untung_me)}
│ ⟡ Untung Reseller  : Rp ${fmt(statHariIni.untung_reseller)}
│
│ ⟡ [ TOTAL KESELURUHAN ]
│ ⟡ Total Trx        : ${statTotal.trx}
│ ⟡ Uang Masuk       : Rp ${fmt(statTotal.masuk)}
│ ⟡ Untung Owner     : Rp ${fmt(statTotal.untung_me)}
│ ⟡ Untung Reseller  : Rp ${fmt(statTotal.untung_reseller)}
╰────────────❱
©NakunStore`;

        await reply(templateLaporan);
    }
};
