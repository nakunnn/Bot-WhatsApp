const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'antibadword',
    description: 'Mengaktifkan atau menonaktifkan fitur anti kata kasar',
    execute: async (sock, m, { args, isAdmins, isOwner, reply, from, isGroup }) => {
        if (!isGroup) return reply("Fitur ini hanya dapat digunakan di dalam grup!");
        if (!isAdmins && !isOwner) return reply("Fitur ini hanya untuk Admin grup!");
        
        const filePath = path.join(__dirname, '../Connection/database/antibadword_off.json');
        if (!fs.existsSync(path.dirname(filePath))) {
            fs.mkdirSync(path.dirname(filePath), { recursive: true });
        }
        
        let db = [];
        if (fs.existsSync(filePath)) {
            db = JSON.parse(fs.readFileSync(filePath));
        }
        
        if (args[0] === 'on') {
            if (!db.includes(from)) return reply("Anti Badword sudah aktif (default).");
            db = db.filter(id => id !== from);
            fs.writeFileSync(filePath, JSON.stringify(db, null, 2));
            reply("✅ Anti Badword berhasil diaktifkan kembali!");
        } else if (args[0] === 'off') {
            if (db.includes(from)) return reply("Anti Badword sudah nonaktif di grup ini.");
            db.push(from);
            fs.writeFileSync(filePath, JSON.stringify(db, null, 2));
            reply("✅ Anti Badword berhasil dinonaktifkan!");
        } else if (args[0] === 'add') {
            if (!isOwner) return reply("Fitur menambah kata hanya untuk Owner!");
            if (!args[1]) return reply("Masukkan kata yang ingin dilarang!");
            const bwPath = path.join(__dirname, '../Connection/database/badwords.json');
            if (!fs.existsSync(path.dirname(bwPath))) fs.mkdirSync(path.dirname(bwPath), { recursive: true });
            let bw = fs.existsSync(bwPath) ? JSON.parse(fs.readFileSync(bwPath)) : [];
            if (bw.includes(args[1].toLowerCase())) return reply("Kata tersebut sudah ada dalam daftar.");
            bw.push(args[1].toLowerCase());
            fs.writeFileSync(bwPath, JSON.stringify(bw, null, 2));
            reply(`✅ Kata "${args[1]}" berhasil ditambahkan ke daftar hitam!`);
        } else if (args[0] === 'del') {
            if (!isOwner) return reply("Fitur menghapus kata hanya untuk Owner!");
            if (!args[1]) return reply("Masukkan kata yang ingin dihapus!");
            const bwPath = path.join(__dirname, '../Connection/database/badwords.json');
            if (!fs.existsSync(bwPath)) return reply("Daftar hitam masih kosong.");
            let bw = JSON.parse(fs.readFileSync(bwPath));
            if (!bw.includes(args[1].toLowerCase())) return reply("Kata tersebut tidak ada dalam daftar.");
            bw = bw.filter(w => w !== args[1].toLowerCase());
            fs.writeFileSync(bwPath, JSON.stringify(bw, null, 2));
            reply(`✅ Kata "${args[1]}" berhasil dihapus dari daftar hitam!`);
        } else {
            reply("Gunakan perintah:\n.antibadword on (Aktifkan)\n.antibadword off (Matikan)\n.antibadword add <kata> (Tambah kata)\n.antibadword del <kata> (Hapus kata)");
        }
    }
};
