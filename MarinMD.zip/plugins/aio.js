const axios = require('axios');

module.exports = {
    command: 'aio',
    description: 'All-in-One Downloader menggunakan Nexa API',
    execute: async (sock, msg, { args, reply, react, pushname }) => {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0].split(':')[0];

        if (!args || args.length === 0) {
            return reply('⚠️ Silakan masukkan URL video yang ingin diunduh!\nContoh: *.aio https://www.tiktok.com/@user/video/123*');
        }

        const targetUrl = args[0];
        if (!/^https?:\/\//i.test(targetUrl)) {
            return reply('❌ URL tidak valid! Pastikan URL diawali dengan http:// atau https://');
        }

        // Tampilkan reaksi loading
        await react(from, '⏳');
        const loadingMessage = await sock.sendMessage(from, { text: '🔄 *Sedang mengunduh media dari Nexa API...*' }, { quoted: msg });

        try {
            const apiUrl = `https://api.nexadev.my.id/api/aio?url=${encodeURIComponent(targetUrl)}`;
            const response = await axios.get(apiUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                timeout: 45000
            });

            const data = response.data;

            if (data.status === false) {
                await react(from, '❌');
                const errMsg = data.message || data.msg || 'Terjadi kesalahan pada API.';
                return sock.sendMessage(from, { text: `❌ *Gagal mengunduh:* ${errMsg}` }, { quoted: msg });
            }

            const mediaUrl = extractMediaUrl(data);
            if (!mediaUrl) {
                await react(from, '❌');
                return sock.sendMessage(from, { text: '❌ *Gagal:* URL media tidak ditemukan dalam respon API.' }, { quoted: msg });
            }

            const lowerUrl = mediaUrl.toLowerCase();
            const isVideo = lowerUrl.includes('.mp4') || lowerUrl.includes('.mov') || lowerUrl.includes('.webm') || lowerUrl.includes('.mkv') || lowerUrl.includes('video');
            const isImage = lowerUrl.includes('.jpg') || lowerUrl.includes('.jpeg') || lowerUrl.includes('.png') || lowerUrl.includes('.webp') || lowerUrl.includes('image');

            const caption = `╭──────❰ *NEXA AIO DOWNLOADER* ❱──────
│
│  ✧ *Fitur:* All-in-One Downloader
│  ✧ *Pengguna:* @${senderNumber} (${pushname})
│  ✧ *Platform:* ${detectPlatform(targetUrl)}
│
├────────────────────────────
│  ⚡ *Powered by Nexa API*
╰────────────────────────────`;

            try {
                if (isVideo) {
                    await sock.sendMessage(from, {
                        video: { url: mediaUrl },
                        caption: caption,
                        mentions: [sender]
                    }, { quoted: msg });
                } else if (isImage) {
                    await sock.sendMessage(from, {
                        image: { url: mediaUrl },
                        caption: caption,
                        mentions: [sender]
                    }, { quoted: msg });
                } else {
                    // Coba kirim sebagai video terlebih dahulu sebagai default untuk tipe media umum
                    await sock.sendMessage(from, {
                        video: { url: mediaUrl },
                        caption: caption,
                        mentions: [sender]
                    }, { quoted: msg });
                }
                await react(from, '✅');
            } catch (sendError) {
                // Fallback: kirim sebagai document (berlaku untuk semua jenis file)
                try {
                    await sock.sendMessage(from, {
                        document: { url: mediaUrl },
                        mimetype: 'application/octet-stream',
                        fileName: `nexa_download_${Date.now()}.${isVideo ? 'mp4' : isImage ? 'jpg' : 'bin'}`,
                        caption: caption,
                        mentions: [sender]
                    }, { quoted: msg });
                    await react(from, '✅');
                } catch (docError) {
                    console.error('[ERR] Failed to send document:', docError);
                    await react(from, '❌');
                    await reply(`❌ *Gagal mengirim media:* ${docError.message || docError}`);
                }
            }
        } catch (error) {
            console.error('[ERR] AIO Downloader error:', error);
            await react(from, '❌');
            const errDetail = error.response?.data?.message || error.response?.data?.msg || error.message;
            await sock.sendMessage(from, { text: `❌ *Error:* ${errDetail}` }, { quoted: msg });
        } finally {
            // Hapus pesan loading
            try {
                await sock.sendMessage(from, { delete: loadingMessage.key }).catch(() => {});
            } catch (_) {}
        }
    }
};

function extractMediaUrl(data) {
    if (!data) return null;
    if (typeof data === 'string' && data.startsWith('http')) return data;
    if (typeof data !== 'object') return null;

    if (data.result) {
        if (typeof data.result === 'string' && data.result.startsWith('http')) return data.result;
        if (data.result.url) return data.result.url;
        if (data.result.download) return data.result.download;
        if (data.result.video) return data.result.video;
        if (data.result.media) return data.result.media;
    }
    if (data.data) {
        if (typeof data.data === 'string' && data.data.startsWith('http')) return data.data;
        if (data.data.url) return data.data.url;
        if (data.data.download) return data.data.download;
        if (data.data.video) return data.data.video;
        if (data.data.media) return data.data.media;
    }
    if (data.url) return data.url;
    if (data.download) return data.download;
    if (data.video) return data.video;

    // Pencarian mendalam
    const queue = [data];
    while (queue.length > 0) {
        const current = queue.shift();
        for (const key in current) {
            if (Object.prototype.hasOwnProperty.call(current, key)) {
                if (typeof current[key] === 'string' && current[key].startsWith('http') && !current[key].includes('thumb') && !current[key].includes('cover')) {
                    return current[key];
                } else if (typeof current[key] === 'object' && current[key] !== null) {
                    queue.push(current[key]);
                }
            }
        }
    }
    return null;
}

function detectPlatform(url) {
    if (/tiktok\.com/i.test(url)) return 'TikTok';
    if (/instagram\.com/i.test(url)) return 'Instagram';
    if (/youtube\.com|youtu\.be/i.test(url)) return 'YouTube';
    if (/facebook\.com|fb\.watch/i.test(url)) return 'Facebook';
    if (/x\.com|twitter\.com/i.test(url)) return 'Twitter/X';
    return 'General';
}
