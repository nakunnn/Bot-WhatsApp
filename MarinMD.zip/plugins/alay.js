const axios = require('axios');
module.exports = {
    command: 'alay',
    description: 'Ubah teks jadi alay',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const text = args.join(' ');
        if (!text) return sock.sendMessage(from, { text: 'Masukkan teks!' }, { quoted: msg });
        try {
            const response = await axios.get(`https://api.nexray.eu.cc/fun/alay?text=${encodeURIComponent(text)}`);
            if (response.data && response.data.status) {
                await sock.sendMessage(from, { text: response.data.result }, { quoted: msg });
            }
        } catch (e) {}
    }
};
