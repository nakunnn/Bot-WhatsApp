const axios = require('axios');

module.exports = {
    command: 'asahotak',
    description: 'Game Asah Otak',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        
        if (global.games[from]) {
            return sock.sendMessage(from, { text: 'Selesaikan game sebelumnya dulu!' }, { quoted: msg });
        }

        try {
            const response = await axios.get('https://api.nexray.eu.cc/games/asahotak');
            if (response.data && response.data.status && response.data.result) {
                const { soal, jawaban } = response.data.result;
                global.games[from] = { jawaban };
                
                const teks = `╭❰ ASAH OTAK ❱\n│ ⟡ Soal: ${soal}\n╰────────────❱\nKetik jawabanmu sekarang!`;
                await sock.sendMessage(from, { text: teks }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: 'Gagal mendapatkan soal.' }, { quoted: msg });
            }
        } catch (error) {
            console.error('[ERR] Game Fetch:', error.message);
            await sock.sendMessage(from, { text: 'Terjadi kesalahan pada server game.' }, { quoted: msg });
        }
    }
};
