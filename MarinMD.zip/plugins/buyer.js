const { saveRevenue } = require('../lib/gsheets');

module.exports = {
    command: 'buyer',
    description: 'Menambahkan data pembeli ke omzet (Google Sheets)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;

        if (args.length < 2) {
            const petunjuk = `╭❰ FORMAT SALAH ❱
│ ⟡ Cara pakai: .buyer [masuk] [owner] [reseller] [ket]
│ ⟡ Contoh RETAIL   : .buyer 50000 40000
│ ⟡ Contoh RESELLER : .buyer 50000 40000 10000
│ ⟡ + Keterangan    : .buyer 50000 40000 0 Jasa Panel
│ ⟡ Ketik angka saja tanpa titik
╰────────────❱
©NakunStore`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        const nominalMasuk    = Number(args[0]);
        const untungOwner     = Number(args[1]);
        const untungReseller  = args[2] ? Number(args[2]) : 0;
        const kategori        = (args[2] && Number(args[2]) > 0) ? 'RESELLER' : 'RETAIL';
        // Keterangan opsional dari arg ke-4 dst
        const keterangan      = args.slice(3).join(' ') || '-';

        if (isNaN(nominalMasuk) || isNaN(untungOwner) || isNaN(untungReseller)) {
            return sock.sendMessage(from, {
                text: `╭❰ ERROR ❱\n│ ⟡ Nominal dan untung harus berupa angka\n╰────────────❱\n©NakunStore`
            }, { quoted: msg });
        }

        // Simpan ke Google Sheets
        const berhasil = await saveRevenue({
            masuk: nominalMasuk,
            untung_me: untungOwner,
            untung_reseller: untungReseller,
            keterangan: keterangan,
            kategori: kategori,
        });

        if (!berhasil) {
            return sock.sendMessage(from, {
                text: `╭❰ PERINGATAN ❱
│ ⟡ GAGAL tersimpan ke Google Sheets
│ ⟡ Cek koneksi internet / Spreadsheet ID
│ ⟡ Lihat log terminal untuk detail
╰────────────❱
©NakunStore`
            }, { quoted: msg });
        }

        const teksSukses = `╭❰ BUYER ADDED ❱
│ ⟡ Masuk          : Rp ${nominalMasuk.toLocaleString('id-ID')}
│ ⟡ Untung Owner   : Rp ${untungOwner.toLocaleString('id-ID')}
│ ⟡ Untung Reseller: Rp ${untungReseller.toLocaleString('id-ID')}
│ ⟡ Kategori       : ${kategori}
│ ⟡ Keterangan     : ${keterangan}
│
│ ✅ Data tersimpan ke Google Sheets!
╰────────────❱
©NakunStore`;

        await sock.sendMessage(from, { text: teksSukses }, { quoted: msg });
    }
};
