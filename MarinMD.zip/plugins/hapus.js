const pm2api = require('../lib/pm2api');
const fs = require('fs');
const path = require('path');

module.exports = {
    command: ['hapus', 'delete'],
    description: 'Menghapus proses subbot dari PM2 dan menghapus folder secara permanen',
    execute: async (sock, msg, { args, react }) => {
        const from = msg.key.remoteJid;
        if (args.length < 1) {
            return await react(from, '❌');
        }

        const nama = args[0];
        try {
            await react(from, '⏳');

            // 1. Matikan dan hapus proses dari PM2
            try {
                await pm2api.deleteBot(nama);
            } catch (err) {
                // Ignore if bot not found in PM2, proceed to delete folder
                console.log(`[HAPUSBOT] PM2 delete ignore: ${err.message}`);
            }

            // 2. Hapus folder subbot tersebut secara permanen
            // Folder name is now just 'nama' (e.g. s1, s2)
            const targetPath = path.join(__dirname, '../subbot', nama);

            if (fs.existsSync(targetPath)) {
                fs.rmSync(targetPath, { recursive: true, force: true });
            }

            await react(from, '✅');
        } catch (error) {
            console.error('[HAPUSBOT ERROR]', error);
            await react(from, '❌');
        }
    }
};
