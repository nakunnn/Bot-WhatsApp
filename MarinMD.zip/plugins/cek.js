const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'cek',
    description: 'Cek status fitur-fitur bot yang sedang aktif',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        
        // 1. Status Auto JPM
        const isJpmRunning = global.jpmState.isLooping || global.jpmState.intervalId;
        const jpmStatus = isJpmRunning ? "Aktif" : "Tidak Aktif";
        const jpmDelay = global.jpmState.delayMinutes || "Default (15m)";
        
        // 2. Cek AFK Users
        const afkFile = path.join(__dirname, '../afk.json');
        let activeAfkCount = 0;
        if (fs.existsSync(afkFile)) {
            try {
                const afkData = JSON.parse(fs.readFileSync(afkFile));
                activeAfkCount = Object.keys(afkData).length;
            } catch (e) {
                activeAfkCount = 0;
            }
        }

        // 3. Cek Status Auto Reply
        const dbPath = path.join(__dirname, '../database/autoreply.json');
        let replyStatus = "Tidak Aktif";
        if (fs.existsSync(dbPath)) {
            try {
                const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
                replyStatus = db.status ? "Aktif" : "Tidak Aktif";
            } catch (e) {
                replyStatus = "Error/Tidak Aktif";
            }
        }

        // 4. Total Fitur
        const pluginCount = fs.readdirSync(__dirname).filter(f => f.endsWith('.js')).length;

        const teks = `╭❰ STATUS FITUR ❱
│ ⟡ Auto JPM: ${jpmStatus}
│ ⟡ Jeda JPM: ${jpmDelay} Menit
│ ⟡ Auto Reply: ${replyStatus}
│ ⟡ AFK Aktif: ${activeAfkCount} User
│ ⟡ Total Fitur: ${pluginCount} Plugin
│ ⟡ Mode: Public (Target Group & PM)
╰────────────❱
©NakunStore`;

        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
