const pm2api = require('../lib/pm2api');

module.exports = {
    command: 'batas',
    description: 'Mengubah limitasi memori RAM subbot yang sudah berjalan',
    execute: async (sock, msg, { args, react }) => {
        const from = msg.key.remoteJid;
        if (args.length < 2) {
            return sock.sendMessage(from, { text: 'Format salah! Gunakan: .batas [nama_bot] [nominal_MB]' }, { quoted: msg });
        }
        
        const nama = args[0];
        const nominal = parseInt(args[1]);

        if (isNaN(nominal)) {
            return sock.sendMessage(from, { text: 'Nominal harus angka (dalam MB).' }, { quoted: msg });
        }
        
        try {
            await react(from, '⏳');
            await pm2api.updateLimit(nama, nominal);
            await react(from, '✅');
        } catch (error) {
            console.error('[BATAS ERROR]', error);
            await react(from, '❌');
            await sock.sendMessage(from, { text: `Gagal mengupdate bot ${nama}: ${error.message}` }, { quoted: msg });
        }
    }
};
