module.exports = {
    command: ['kickall', 'prankkick'],
    description: 'Prank member grup seolah-olah akan di-kick',
    execute: async (sock, msg, { isOwner, reply, react }) => {
        const from = msg.key.remoteJid;

        // Memastikan command ini hanya dijalankan di dalam grup
        if (!from.endsWith('@g.us')) {
            return reply('⚠️ Command ini hanya bisa digunakan di dalam grup!');
        }

        // (Opsional) Jika Anda ingin hanya owner/admin yang bisa iseng:
        // if (!isOwner) return reply('⚠️ Hanya Owner yang bisa menggunakan command ini!');

        // Memberikan reaction 😈 pada pesan command
        await react(from, '😈');

        // Mengirimkan notifikasi ancaman palsu
        const pesanAncaman = `⚠️ *SISTEM PEMBERSIHAN GRUP AKTIF* ⚠️

Semua member grup akan dikeluarkan secara massal dalam hitungan:
*5 Detik* dari sekarang!`;

        await sock.sendMessage(from, { text: pesanAncaman }, { quoted: msg });

        // Menunggu selama 5 detik
        setTimeout(async () => {
            const pesanPrank = `🎉 *SELAMAT KAMU KENA PRANK!* 🎉

Hahahahaha panik deckss?? 😜`;

            await sock.sendMessage(from, { text: pesanPrank });
        }, 5000);
    }
};
