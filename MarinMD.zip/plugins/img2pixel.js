const axios = require('axios');
const FormData = require('form-data');

module.exports = {
    command: ['img2pixel', 'pixelate', 'pixel'],
    description: 'Mengubah gambar menjadi efek pixelate',
    execute: async (sock, msg, { args, reply, react, pushname }) => {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0].split(':')[0];

        // Cari media image dari quote atau pesan langsung
        let mediaMsg = null;
        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (quotedMsg) {
            if (quotedMsg.imageMessage) mediaMsg = quotedMsg.imageMessage;
        }
        if (!mediaMsg) {
            if (msg.message?.imageMessage) mediaMsg = msg.message.imageMessage;
        }

        // Tentukan nilai pixel (default: 5)
        let pixelSize = 5;
        if (args && args.length > 0) {
            const parsed = parseInt(args[0]);
            if (!isNaN(parsed) && parsed > 0) {
                pixelSize = parsed;
            }
        }

        let imageUrl = '';

        if (mediaMsg) {
            await react(from, '⏳');
            const loadingMessage = await sock.sendMessage(from, { text: '🔄 *Sedang mengunduh dan memproses gambar Anda...*' }, { quoted: msg });

            try {
                // Download image
                const buffer = await sock.downloadMediaMessage(mediaMsg);
                if (!buffer || buffer.length === 0) {
                    await react(from, '❌');
                    try { await sock.sendMessage(from, { delete: loadingMessage.key }); } catch (_) {}
                    return reply('❌ Gagal mengunduh gambar dari WhatsApp.');
                }

                // Upload ke tmpfiles.org
                const mime = mediaMsg.mimetype || 'image/jpeg';
                const cleanMime = mime.split(';')[0].trim();
                const filename = `pixelate_${Date.now()}.jpg`;

                const form = new FormData();
                form.append('file', buffer, { filename, contentType: cleanMime });

                const uploadResponse = await axios.post('https://tmpfiles.org/api/v1/upload', form, {
                    headers: form.getHeaders(),
                    maxContentLength: Infinity,
                    maxBodyLength: Infinity,
                    timeout: 60000,
                });

                const uploadData = uploadResponse.data;
                if (uploadData && uploadData.status === 'success') {
                    const pageUrl = uploadData.data.url;
                    imageUrl = pageUrl.replace('https://tmpfiles.org/', 'https://tmpfiles.org/dl/');
                } else {
                    throw new Error('Gagal mengunggah berkas ke server penyimpanan sementara.');
                }

            } catch (err) {
                console.error('[IMG2PIXEL] Upload Error:', err);
                await react(from, '❌');
                try { await sock.sendMessage(from, { delete: loadingMessage.key }); } catch (_) {}
                return reply(`❌ *Error Upload:* ${err.message}`);
            }

            // Hapus pesan loading download/upload
            try { await sock.sendMessage(from, { delete: loadingMessage.key }).catch(() => {}); } catch (_) {}
        } else if (args && args.length > 0 && /^https?:\/\//i.test(args[0])) {
            imageUrl = args[0];
            // Jika argumen pertama URL, cek apakah ada argumen kedua untuk pixel size
            if (args[1]) {
                const parsed = parseInt(args[1]);
                if (!isNaN(parsed) && parsed > 0) {
                    pixelSize = parsed;
                }
            }
        } else {
            return reply('❌ Reply/quote gambar yang ingin diubah ke pixelate, atau kirim URL gambar langsung!\nContoh: Reply gambar dengan ketik *.img2pixel 8*');
        }

        // Jalankan proses pixelate
        await react(from, '⏳');
        const processingMessage = await sock.sendMessage(from, { text: '✨ *Sedang membuat efek pixelate...*' }, { quoted: msg });

        try {
            const apiUrl = `https://apii.nexadev.my.id/pixel?url=${encodeURIComponent(imageUrl)}&pixel=${pixelSize}`;
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                timeout: 60000
            });

            const contentType = response.headers['content-type'] || '';
            const dataBuffer = Buffer.from(response.data);

            // Periksa jika respon adalah JSON error
            if (contentType.includes('application/json') || dataBuffer[0] === 123) { // 123 is ASCII for '{'
                await react(from, '❌');
                try {
                    const jsonError = JSON.parse(dataBuffer.toString('utf8'));
                    const errMsg = jsonError.message || jsonError.msg || 'Gagal memproses gambar pada API.';
                    return sock.sendMessage(from, { text: `❌ *Gagal:* ${errMsg}` }, { quoted: msg });
                } catch (pe) {
                    return sock.sendMessage(from, { text: `❌ *Gagal memproses gambar.*` }, { quoted: msg });
                }
            }

            const caption = `╭───────❰ *IMG TO PIXEL* ❱───────
│
│  ✧ *Fitur:* Image Pixelate
│  ✧ *Pixel Size:* ${pixelSize}
│  ✧ *Pengguna:* @${senderNumber} (${pushname})
│
├────────────────────────────
│  ⚡ *Status:* Berhasil di-pixelate!
│  ❐ MarinMD | © NakunStore
╰────────────────────────────`;

            // Kirim gambar hasil pemrosesan
            await sock.sendMessage(from, {
                image: dataBuffer,
                caption: caption,
                mentions: [sender]
            }, { quoted: msg });

            await react(from, '✅');
        } catch (error) {
            console.error('[IMG2PIXEL] API Error:', error);
            await react(from, '❌');
            let errDetail = error.message;
            if (error.response?.data) {
                try {
                    const buf = Buffer.from(error.response.data);
                    const jsonErr = JSON.parse(buf.toString('utf8'));
                    errDetail = jsonErr.message || jsonErr.msg || errDetail;
                } catch (_) {}
            }
            await sock.sendMessage(from, { text: `❌ *Error:* ${errDetail}` }, { quoted: msg });
        } finally {
            try {
                await sock.sendMessage(from, { delete: processingMessage.key }).catch(() => {});
            } catch (_) {}
        }
    }
};
