module.exports = {
    command: 'formattopup',
    description: 'Menyusun format top-up untuk pelanggan',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;

        if (args.length < 2) {
            const petunjuk = `╭❰ FORMAT SALAH ❱\n│ ⟡ Gunakan: .formattopup [id_game] [jumlah_item]\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        const idGame = args[0];
        const jumlahItem = args.slice(1).join(" ");

        const teks = `╭❰ FORMAT TOP-UP ❱
│ ⟡ ID Tujuan: ${idGame}
│ ⟡ Jumlah: ${jumlahItem}
│ ⟡ Status: Berhasil Masuk
│ ⟡ Terima kasih sudah belanja!
╰────────────❱
©NakunStore`;

        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
