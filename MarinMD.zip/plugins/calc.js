const { saveRevenue } = require('../lib/gsheets');

module.exports = {
    command: 'calc',
    execute: async (sock, m, { args, reply, react }) => {
        const from = m.key.remoteJid;
        const fmt = (n) => n.toLocaleString('id-ID');

        if (!args[0]) {
            return reply(`╭❰ KALKULATOR 79/21 ❱
│ ⟡ Cara pakai: .calc <nominal>
│ ⟡ Contoh: .calc 10000
│ ⟡ Opsional: .calc 10000 Jasa Panel
╰────────────❱
©NakunStore`);
        }

        const nominal = parseInt(args[0].replace(/[^0-9]/g, ''));
        if (isNaN(nominal) || nominal <= 0) {
            return reply('❌ Masukkan angka yang valid!');
        }

        const keterangan = args.slice(1).join(' ') || '-';
        const bagian79 = nominal * 0.79;
        const bagian21 = nominal * 0.21;

        await react(from, '⏳');

        const berhasil = await saveRevenue({
            masuk: nominal,
            untung_me: bagian79,
            untung_reseller: bagian21,
            keterangan,
            kategori: 'RETAIL',
        });

        if (!berhasil) {
            await react(from, '⚠️');
            return reply(`╭❰ PERINGATAN ❱
│ ⟡ Kalkulasi berhasil dihitung
│ ⟡ Tapi GAGAL tersimpan ke Google Sheets
│ ⟡ Cek koneksi / Spreadsheet ID
╰────────────❱
©NakunStore`);
        }

        const tanggal = new Date().toLocaleDateString('id-ID', {
            timeZone: 'Asia/Jakarta',
            day: '2-digit', month: '2-digit', year: 'numeric'
        });

        await react(from, '✅');
        return reply(`╭❰ KALKULATOR 79/21 ❱
│ ⟡ Nominal       : Rp${fmt(nominal)}
│ ⟡ 79% (Owner)   : Rp${fmt(bagian79)}
│ ⟡ 21% (Reseller): Rp${fmt(bagian21)}
│ ⟡ Keterangan    : ${keterangan}
│
│ ✅ Tersimpan ke Google Sheets
│ 📅 Tanggal: ${tanggal}
╰────────────❱
©NakunStore`);
    }
};
