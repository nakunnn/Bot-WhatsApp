const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'bugmenu',
    execute: async (sock, m, { performance, runtime, quoted, react, prefix }) => {
        await react(m.chat, "🫪");
        
        let bugText = `\`ⓘ こんにちは、マリンです。お手伝いできるボットです。⚠︎\`

\`𠘰\` Author : Nakun
\`は\` Version : *15.0*
\`𠃮\` Prefix  : Multi
\`𠙖\` Speed  : *${(require('perf_hooks').performance.now() - performance).toFixed(5)} ms*
\`𠗖\` Runtime : *${runtime(process.uptime())}*

⏤ *[ 𝗕𝗨𝗧𝗧𝗢𝗡 𝗕𝗨𝗚 ]*
𖥂 ${prefix}marin-bug *Target*  
╰┈⌲ Bug Button Type Execute!!
       
⏤ *[ 𝗔𝗡𝗗𝗥𝗢 𝗕𝗨𝗚 ]*
𖥂 ${prefix}blank-notif *Target*     
𖥂 ${prefix}crash-ip *Target*   
𖥂 ${prefix}invisible-delay *Target*  
𖥂 ${prefix}delay-maker *Target*  

⏤ *[ 𝗕𝗨𝗚 𝗚𝗥𝗢𝗨𝗚 ]*
𖥂 ${prefix}out-group *Inplace Group*
𖖂 ${prefix}kill-group *Group Link*
`;

        await sock.sendMessage(m.chat, {
            interactiveMessage: {
                title: "MARIN BUG MENU\n\n" + bugText,
                footer: "⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫 | ©NakunStore",
                image: {
                    url: "./Connection/foto/banner.jpeg"
                },
                nativeFlowMessage: {
                    messageParamsJson: JSON.stringify({
                        limited_time_offer: {
                            text: "𝐍𝐀𝐊𝐔𝐍 𝐗 𝐌𝐀𝐑𝐈𝐍",
                            url: "https://wa.me/6285726013874",
                            copy_code: "MARINV15",
                            expiration_time: Date.now() + (24 * 60 * 60 * 1000)
                        },
                        bottom_sheet: {
                            in_thread_buttons_limit: 2,
                            divider_indices: [1],
                            list_title: "CLICK",
                            button_title: "⿻ 𝐌𝐚𝐫𝐢𝐧"
                        },
                        tap_isTarget_configuration: {
                            title: " X ",
                            description: "Kembali",
                            canonical_url: "",
                            domain: "",
                            button_index: 0
                        }
                    }),
                    buttons: [{
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Kembali ke Menu",
                            id: `${prefix}menu`
                        })
                    }]
                }
            },
            contextInfo: {
                externalAdReply: {
                    title: "Marin • Status",
                    body: `🛒 ${global.totalPlugins || 13} items\n❐ nakun\n© MARIN V15`,
                    thumbnailUrl: "https://files.catbox.moe/473n1z.jpeg",
                    sourceUrl: "https://wa.me/6285726013874",
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: m });
    }
}
