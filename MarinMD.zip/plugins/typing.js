const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'typing',
    description: 'Mengaktifkan fitur bot typing selamanya di grup',
    execute: async (sock, msg, { args, react, isOwner, reply }) => {
        const from = msg.key.remoteJid;
        const isMe = msg.key.fromMe;
        const dbPath = path.join(__dirname, '../database/typing.json');

        // "hanya bisa di aktifkan oleh nomor bot"
        // Kita cek apakah itu 'Me' (nomor bot sendiri) atau Owner
        if (!isMe && !isOwner) return;

        // Load existing database
        let typingDb = [];
        if (fs.existsSync(dbPath)) {
            try {
                typingDb = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
            } catch (e) {
                typingDb = [];
            }
        }

        if (args[0] === 'on') {
            if (global.typingState[from]) {
                return reply('Fitur typing selamanya sudah aktif di grup ini.');
            }

            await react(from, '⏳');
            
            // Save to DB if not already there
            if (!typingDb.includes(from)) {
                typingDb.push(from);
                fs.writeFileSync(dbPath, JSON.stringify(typingDb, null, 4));
            }

            // Kirim pertama kali
            await sock.sendPresenceUpdate('composing', from);
            
            // Set interval setiap 25 detik
            global.typingState[from] = setInterval(async () => {
                try {
                    await sock.sendPresenceUpdate('composing', from);
                } catch (e) {
                    console.error('[TYPING ERROR]', e);
                }
            }, 25000);

            await reply('✅ Fitur typing selamanya BERHASIL diaktifkan.');
            await react(from, '✅');
        } else if (args[0] === 'off') {
            if (!global.typingState[from]) {
                return reply('Fitur typing selamanya memang tidak aktif.');
            }

            // Remove from DB
            typingDb = typingDb.filter(jid => jid !== from);
            fs.writeFileSync(dbPath, JSON.stringify(typingDb, null, 4));

            clearInterval(global.typingState[from]);
            delete global.typingState[from];
            
            await sock.sendPresenceUpdate('paused', from);
            await reply('✅ Fitur typing selamanya BERHASIL dinonaktifkan.');
            await react(from, '✅');
        } else {
            reply('Format salah! Gunakan: .typing on atau .typing off');
        }
    }
};
