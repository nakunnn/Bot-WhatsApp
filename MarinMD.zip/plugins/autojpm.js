const { delay } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../database/autojpm.json');

// Helper untuk mengambil pesan yang tersimpan
function getSavedMessage() {
    if (fs.existsSync(configPath)) {
        try {
            const data = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            return data.message || '';
        } catch (e) {
            return '';
        }
    }
    return '';
}

// Helper untuk menyimpan pesan
function saveMessage(text) {
    const dir = path.dirname(configPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(configPath, JSON.stringify({ message: text }, null, 4));
}

async function doJpmBroadcast(sock, textMessage, callerId) {
    if (!textMessage || !callerId) return;
    
    try {
        const groups = await sock.groupFetchAllParticipating();
        const groupEntries = Object.entries(groups).filter(([jid]) => jid !== '120363405675223209@g.us');
        const totalGroups = groupEntries.length;
        let successCount = 0;
        let failedCount = 0;
        
        // START NOTIFICATION
        console.log(`Starting JPM Broadcast to ${totalGroups} groups...`);
        try {
            await sock.sendMessage(callerId, {
                text: `╭❰ INFO JPM ❱\n│ ⟡ Putaran JPM baru dimulai.\n│ ⟡ Target: ${totalGroups} Grup\n│ ⟡ Mohon tunggu sampai selesai.\n╰────────────❱\n©NakunStore`
            });
        } catch (e) {
            console.error(`Failed to send start notification:`, e.message);
        }
        for (const [jid, metadata] of groupEntries) {
            // CHECK STOP SIGNAL
            if (!global.jpmState.isLooping) {
                console.log("Broadcast stopped by signal.");
                break;
            }

            try {
                await sock.sendMessage(jid, { text: textMessage });
                successCount++;
                console.log(`Broadcast success to: ${jid}`);
            } catch (e) {
                failedCount++;
                console.error(`Broadcast failed for ${jid}:`, e.message);
            }
            await delay(4000); 
        }
        
        // Only send summary if broadcast actually happened or wasn't immediately stopped
        if (successCount > 0 || failedCount > 0) {
            try {
                const statusSuffix = global.jpmState.isLooping ? "telah selesai" : "dihentikan paksa";
                await sock.sendMessage(callerId, {
                    text: `╭❰ INFO JPM ❱\n│ ⟡ Putaran JPM ${statusSuffix}.\n│ ⟡ Total Grup: ${totalGroups}\n│ ⟡ Terbuka: ${successCount}\n│ ⟡ Tertutup: ${failedCount}\n╰────────────❱\n©NakunStore`
                });
            } catch (e) {
                console.error(`Failed to send completion notification:`, e.message);
            }
        }

        console.log(`JPM Broadcast finished/stopped. Success: ${successCount}, Failed: ${failedCount}`);
    } catch (err) {
        console.error('Failed to init groupFetchAllParticipating:', err);
    }
}

module.exports = {
    command: 'autojpm',
    description: 'Fetches all group JIDs and broadcasts a message safely',
    doJpmBroadcast,
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const subCommand = args[0] ? args[0].toLowerCase() : '';

        if (subCommand === 'off') {
            global.jpmState.isLooping = false; // Stop active loop
            if (global.jpmState.intervalId) {
                clearInterval(global.jpmState.intervalId);
                global.jpmState.intervalId = null;
                await sock.sendMessage(from, { text: '╭❰ AUTO JPM ❱\n│ ⟡ Auto JPM telah dimatikan.\n╰────────────❱\n©NakunStore' }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: '╭❰ AUTO JPM ❱\n│ ⟡ Auto JPM memang sedang tidak berjalan.\n╰────────────❱\n©NakunStore' }, { quoted: msg });
            }
            return;
        }

        if (subCommand === 'edit') {
            const text = args.slice(1).join(' ');
            if (!text) {
                await sock.sendMessage(from, { text: '╭❰ ERROR ❱\n│ ⟡ Pesan tidak boleh kosong.\n│ ⟡ Penggunaan: .autojpm edit <pesan>\n╰────────────❱\n©NakunStore' }, { quoted: msg });
                return;
            }
            saveMessage(text);
            global.jpmState.lastMessage = text;
            await sock.sendMessage(from, { text: '╭❰ SUCCESS ❱\n│ ⟡ Pesan JPM berhasil diperbarui dan disimpan!\n╰────────────❱\n©NakunStore' }, { quoted: msg });
            return;
        }

        if (subCommand === 'help') {
            const tutorialText = `╭❰ TUTORIAL AUTO JPM ❱
│
│ 1. *Set Pesan*: Gunakan *.autojpm edit [pesan]* 
│    untuk menyimpan pesan promosi Anda.
│
│ 2. *Set Jeda*: Gunakan *.autojpmdelay [menit]* 
│    untuk mengatur interval pengiriman.
│    (Contoh: .autojpmdelay 5)
│
│ 3. *Mulai JPM*: Gunakan *.autojpm on* 
│    untuk mengaktifkan pengiriman otomatis.
│
│ 4. *Cek Status*: Gunakan *.cserver* 
│    untuk melihat apakah fitur JPM aktif.
│
│ 5. *Matikan*: Gunakan *.autojpm off* 
│    untuk menghentikan pengiriman otomatis.
│
│ *Tips*: Pastikan bot sudah masuk ke 
│ grup-grup tujuan sebelum memulai.
╰────────────❱\n©NakunStore`;
            await sock.sendMessage(from, { text: tutorialText }, { quoted: msg });
            return;
        }

        if (subCommand === 'on') {
            let text = args.slice(1).join(' ');
            if (!text) {
                // Baca dari JSON jika tidak ada argumen pesan
                text = getSavedMessage();
            } else {
                // Simpan pesan baru jika disertakan setelah 'on'
                saveMessage(text);
            }

            if (!text) {
                await sock.sendMessage(from, { text: '╭❰ ERROR ❱\n│ ⟡ Belum ada pesan tersimpan.\n│ ⟡ Silakan gunakan: .autojpm edit <pesan>\n╰────────────❱\n©NakunStore' }, { quoted: msg });
                return;
            }

            if (global.jpmState.intervalId) {
                clearInterval(global.jpmState.intervalId);
            }

            global.jpmState.isLooping = true;
            global.jpmState.lastMessage = text;
            const minutes = global.jpmState.delayMinutes > 0 ? global.jpmState.delayMinutes : 5;
            global.jpmState.delayMinutes = minutes;
            const ms = minutes * 60 * 1000;

            global.jpmState.callerId = from;

            await sock.sendMessage(from, { text: `╭❰ AUTO JPM ❱\n│ ⟡ Mengaktifkan Auto JPM!\n│ ⟡ Broadcast akan berjalan setiap ${minutes} menit.\n╰────────────❱\n©NakunStore` }, { quoted: msg });
            
            await doJpmBroadcast(sock, text, from);

            global.jpmState.intervalId = setInterval(async () => {
                if (global.jpmState.isLooping) {
                    console.log(`[Interval loop triggered] Re-running background Auto JPM broadcast...`);
                    const freshText = getSavedMessage() || global.jpmState.lastMessage;
                    await doJpmBroadcast(sock, freshText, global.jpmState.callerId);
                }
            }, ms);
            return;
        }

        // Shortcut untuk kirim 1x (tetap bisa pakai argument langsung)
        const text = args.join(' ');
        if (!text && subCommand !== 'list') {
            await sock.sendMessage(from, { text: '╭❰ INFO COMMAND ❱\n│ ⟡ .autojpm help (Panduan Lengkap)\n│ ⟡ .autojpm edit <pesan> (Simpan pesan)\n│ ⟡ .autojpm on (Aktifkan JPM otomatis)\n│ ⟡ .autojpm off (Matikan JPM otomatis)\n│ ⟡ .autojpm <pesan> (Kirim 1x)\n╰────────────❱\n©NakunStore' }, { quoted: msg });
            return;
        }

        // Jika hanya .autojpm <text>, kirim 1x
        if (text) {
            global.jpmState.isLooping = true;
            global.jpmState.lastMessage = text;
            global.jpmState.callerId = from;
            await sock.sendMessage(from, { text: `╭❰ AUTO JPM ❱\n│ ⟡ Starting 1x Auto JPM broadcast...\n╰────────────❱\n©NakunStore` }, { quoted: msg });
            await doJpmBroadcast(sock, text, from);
            if (!global.jpmState.intervalId) {
                global.jpmState.isLooping = false; 
            }
            await sock.sendMessage(from, { text: `╭❰ AUTO JPM ❱\n│ ⟡ Auto JPM broadcast completed!\n│ ⟡ (Hanya 1x pengiriman)\n╰────────────❱\n©NakunStore` }, { quoted: msg });
        }
    }
};

