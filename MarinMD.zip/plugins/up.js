const axios = require('axios');
const FormData = require('form-data');

module.exports = {
    command: ['up', 'uguu', 'tourl3h', 'tempurl'],
    description: 'Mengunggah media ke hosting sementara Uguu (3 jam)',
    execute: async (sock, msg, { reply, react }) => {
        const from = msg.key.remoteJid;

        const mediaTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'];

        // Cari media: di quote dulu, fallback ke pesan sendiri
        let mediaMsg = null;
        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (quotedMsg) {
            for (const t of mediaTypes) {
                if (quotedMsg[t]) { mediaMsg = quotedMsg[t]; break; }
            }
        }
        if (!mediaMsg) {
            for (const t of mediaTypes) {
                if (msg.message?.[t]) { mediaMsg = msg.message[t]; break; }
            }
        }

        if (!mediaMsg) {
            return reply('❌ Reply/quote media (gambar/video/audio/file/stiker) yang ingin diubah menjadi link sementara!\n\nCara: Reply media lalu ketik *.up*');
        }

        const mime = mediaMsg.mimetype || 'application/octet-stream';
        await react(from, '⏳');
        const loadingMessage = await sock.sendMessage(from, { text: '🔄 *Sedang mengunggah media ke Uguu.se (3 Jam)...*' }, { quoted: msg });

        try {
            const buffer = await sock.downloadMediaMessage(mediaMsg);

            if (!buffer || buffer.length === 0) {
                await react(from, '❌');
                try { await sock.sendMessage(from, { delete: loadingMessage.key }); } catch (_) {}
                return reply('❌ Gagal mengunduh media dari WhatsApp.');
            }

            console.log(`[UGUU] Downloaded ${buffer.length} bytes, mime: ${mime}`);

            // Tentukan ekstensi
            const extMap = {
                'image/jpeg': 'jpg',
                'image/jpg': 'jpg',
                'image/png': 'png',
                'image/gif': 'gif',
                'image/webp': 'webp',
                'video/mp4': 'mp4',
                'video/3gpp': '3gp',
                'audio/mpeg': 'mp3',
                'audio/ogg; codecs=opus': 'ogg',
                'audio/ogg': 'ogg',
                'application/pdf': 'pdf',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
                'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
                'text/plain': 'txt',
            };

            const cleanMime = mime.split(';')[0].trim();
            const extension = extMap[cleanMime] || (mime.includes('/') ? cleanMime.split('/')[1] : 'bin');
            const filename = `marin_${Date.now()}.${extension}`;

            const form = new FormData();
            form.append('files[]', buffer, { filename, contentType: cleanMime });

            const response = await axios.post('https://uguu.se/upload', form, {
                headers: form.getHeaders(),
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
                timeout: 120000,
            });

            const data = response.data;

            if (data && data.success && data.files && data.files.length > 0) {
                const fileInfo = data.files[0];
                const resultUrl = fileInfo.url;

                await react(from, '✅');
                
                const caption = `╭──────❰ *UGUU TEMPORARY UPLOADER* ❱──────
│
│  ✧ *Status:* Berhasil Diunggah!
│  ✧ *Masa Aktif:* 3 Jam (Temporary)
│  ✧ *Nama File:* ${fileInfo.filename || filename}
│  ✧ *Tipe:* ${cleanMime}
│  ✧ *Ukuran:* ${(buffer.length / 1024).toFixed(1)} KB
│
├────────────────────────────
│  🔗 *Link:* ${resultUrl}
╰────────────────────────────`;

                await sock.sendMessage(from, { text: caption }, { quoted: msg });
            } else {
                throw new Error('Format respon API tidak valid.');
            }

        } catch (err) {
            console.error('[UGUU] Upload Error:', err);
            await react(from, '❌');
            await reply(`❌ *Gagal mengunggah ke Uguu.se:* ${err.message}`);
        } finally {
            try {
                await sock.sendMessage(from, { delete: loadingMessage.key }).catch(() => {});
            } catch (_) {}
        }
    }
};
