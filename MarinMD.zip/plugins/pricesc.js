module.exports = {
    command: 'pricesc',
    description: 'Menampilkan daftar harga source code bot',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const teks = `*PRICELIST SC NAKUNSTORE*

╭❰ PRICELIST SC  ❱
│ ⟡ JPM + PUSHKONTAK V1 — 5K
│ ⟡ JPM + PUSHKONTAK V10 — 20K
│ ⟡ JASA PASANG SC — 5K
│ ⟡ JASA SAMBUNG BOT KE WA — 5K
╰────────────❱

©NakunStore`;
        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
}
