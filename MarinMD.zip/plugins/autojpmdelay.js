const jpmPlugin = require('./autojpm');

module.exports = {
    command: 'autojpmdelay',
    description: 'Sets the background loop delay in minutes for the autojpm session',
    execute: async (sock, msg, args) => {
        const minutes = parseInt(args[0]);
        if (isNaN(minutes)) {
            await sock.sendMessage(msg.key.remoteJid, { text: '╭❰ ERROR ❱\n│ ⟡ Please provide a valid number of minutes.\n│ ⟡ Usage: .autojpmdelay <minutes>\n│ ⟡ Use 0 to stop the repeating loop.\n╰────────────❱\n©NakunStore' }, { quoted: msg });
            return;
        }

        // Clear existing interval
        if (global.jpmState.intervalId) {
            clearInterval(global.jpmState.intervalId);
            global.jpmState.intervalId = null;
        }

        if (minutes <= 0) {
            global.jpmState.delayMinutes = 0;
            await sock.sendMessage(msg.key.remoteJid, { text: '╭❰ AUTO JPM DELAY ❱\n│ ⟡ Auto JPM loop has been stopped.\n╰────────────❱\n©NakunStore' }, { quoted: msg });
            return;
        }

        if (!global.jpmState.lastMessage) {
            await sock.sendMessage(msg.key.remoteJid, { 
                text: '╭❰ ERROR ❱\n│ ⟡ No previous Auto JPM message found in memory.\n│ ⟡ Please run .autojpm <message> at least once.\n╰────────────❱\n©NakunStore' 
            }, { quoted: msg });
            return;
        }

        global.jpmState.delayMinutes = minutes;
        const ms = minutes * 60 * 1000;

        await sock.sendMessage(msg.key.remoteJid, { 
            text: `╭❰ AUTO JPM DELAY ❱\n│ ⟡ Loop set to repeat every ${minutes} minutes.\n│ ⟡ Bot will broadcast previously saved message.\n╰────────────❱\n©NakunStore` 
        }, { quoted: msg });

        // Start repeating interval
        global.jpmState.intervalId = setInterval(async () => {
            console.log(`[Interval loop triggered] Re-running background Auto JPM broadcast...`);
            await jpmPlugin.doJpmBroadcast(sock, global.jpmState.lastMessage, global.jpmState.callerId);
        }, ms);
    }
};
