const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'maintenance',
    description: 'Mengatur mode maintenance bot',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const dbPath = path.join(__dirname, '../database/maintenance.json');

        if (args.length < 1) {
            const petunjuk = `╭❰ FORMAT SALAH ❱\n│ ⟡ Gunakan: .maintenance on/off\n│ ⟡ Contoh: .maintenance on\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        const mode = args[0].toLowerCase();
        let db = { status: false };

        if (!fs.existsSync(path.dirname(dbPath))) {
            fs.mkdirSync(path.dirname(dbPath), { recursive: true });
        }

        if (fs.existsSync(dbPath)) {
            db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
        }

        if (mode === 'on') {
            db.status = true;
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 4));
            const teks = `╭❰ MAINTENANCE ❱\n│ ⟡ Mode Maintenance: AKTIF\n│ ⟡ Fitur bot telah dinonaktifkan.\n╰────────────❱\n©NakunStore`;
            await sock.sendMessage(from, { text: teks }, { quoted: msg });
        } else if (mode === 'off') {
            db.status = false;
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 4));
            const teks = `╭❰ MAINTENANCE ❱\n│ ⟡ Mode Maintenance: MATI\n│ ⟡ Bot kembali normal.\n╰────────────❱\n©NakunStore`;
            await sock.sendMessage(from, { text: teks }, { quoted: msg });
        } else {
            const petunjuk = `╭❰ FORMAT SALAH ❱\n│ ⟡ Pilih antara 'on' atau 'off'\n╰────────────❱\n©NakunStore`;
            await sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }
    }
};
