const axios = require('axios');

module.exports = {
    command: ['patrick', 'bratpatrick'],
    description: 'Generate gambar teks bergaya Brat dengan karakter Patrick Star',
    execute: async (sock, msg, { args, reply, react }) => {
        const from = msg.key.remoteJid;

        const text = args.join(' ');
        if (!text) {
            return reply('❌ *Format salah!*\nFormat: `.patrick [teks]`\nContoh: `.patrick halo gua nexa`');
        }

        // Ganti semua spasi dengan '+' untuk kompatibilitas API
        const formattedText = text.replace(/\s+/g, '+');

        await react(from, '⏳');

        try {
            const apiUrl = `https://apii.nexadev.my.id/bratpatrick?text=${encodeURIComponent(formattedText)}`;
            
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                timeout: 60000
            });

            const contentType = response.headers['content-type'] || '';
            const dataBuffer = Buffer.from(response.data);

            // Periksa jika respon adalah JSON error
            if (contentType.includes('application/json') || dataBuffer[0] === 123) { // 123 is ASCII for '{'
                await react(from, '❌');
                try {
                    const jsonError = JSON.parse(dataBuffer.toString('utf8'));
                    const errMsg = jsonError.message || jsonError.msg || 'Gagal memproses gambar pada API.';
                    return sock.sendMessage(from, { text: `❌ *Gagal:* ${errMsg}` }, { quoted: msg });
                } catch (pe) {
                    return sock.sendMessage(from, { text: `❌ *Gagal memproses gambar.*` }, { quoted: msg });
                }
            }

            // Kirim stiker hasil pemrosesan
            await sock.sendImageAsSticker(from, dataBuffer, msg, {
                packname: 'MarinMD',
                author: 'Nakun'
            });

            await react(from, '✅');

        } catch (error) {
            console.error('[PATRICK] Error:', error);
            await react(from, '❌');
            let errDetail = error.message;
            if (error.response?.data) {
                try {
                    const buf = Buffer.from(error.response.data);
                    const jsonErr = JSON.parse(buf.toString('utf8'));
                    errDetail = jsonErr.message || jsonErr.msg || errDetail;
                } catch (_) {}
            }
            await sock.sendMessage(from, { text: `❌ *Error:* ${errDetail}` }, { quoted: msg });
        }
    }
};
