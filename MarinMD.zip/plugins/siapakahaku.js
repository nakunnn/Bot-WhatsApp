const axios = require('axios');
module.exports = {
    command: 'siapakahaku',
    description: 'Game Siapakah Aku',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        if (global.games[from]) return sock.sendMessage(from, { text: 'Selesaikan game sebelumnya dulu!' }, { quoted: msg });
        try {
            const response = await axios.get('https://api.nexray.eu.cc/games/siapakahaku');
            if (response.data && response.data.status && response.data.result) {
                const { soal, jawaban } = response.data.result;
                global.games[from] = { jawaban };
                const teks = `╭❰ SIAPAKAH AKU? ❱\n│ ⟡ Soal: ${soal}\n╰────────────❱`;
                await sock.sendMessage(from, { text: teks }, { quoted: msg });
            }
        } catch (e) {}
    }
};
