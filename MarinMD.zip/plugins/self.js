module.exports = {
    command: 'self',
    execute: async (sock, m, { isOwner, reply, command }) => {
        if (!isOwner) return reply("Khusus Owner");
        sock.public = false;
        reply(`successfully changed to ${command}`);
    }
};
