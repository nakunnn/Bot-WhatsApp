const axios = require('axios');
module.exports = {
    command: 'livefunfact',
    description: 'Dapatkan fakta unik acak',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        try {
            const response = await axios.get('https://api.nexray.eu.cc/fun/livefunfact');
            if (response.data && response.data.status) {
                const teks = `╭❰ FUN FACT ❱\n│ ⟡ ${response.data.result}\n╰────────────❱`;
                await sock.sendMessage(from, { text: teks }, { quoted: msg });
            }
        } catch (e) {}
    }
};
