const fs = require('fs');

module.exports = {
    command: 'addowner',
    execute: async (sock, m, { args, q, prefix, command, isOwner, reply }) => {
        if (!isOwner) return reply("Fitur ini hanya dapat di akses oleh owner bot");
        if (!args[0]) return reply(`_*Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} 628×××`);
        
        let prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        let v82 = await sock.onWhatsApp(prrkek);
        if (v82.length == 0) return reply("*`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`*");
        
        let owner = JSON.parse(fs.readFileSync("./Connection/database/owner.json"));
        owner.push(prrkek);
        fs.writeFileSync("./Connection/database/owner.json", JSON.stringify(owner));
        reply(`*Nomor ${prrkek} Telah Menjadi Owner!*`);
    }
};
