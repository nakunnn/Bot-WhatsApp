const pm2api = require('../lib/pm2api');

module.exports = {
    command: 'start',
    description: 'Menyalakan kembali proses subbot di PM2',
    execute: async (sock, msg, { args, react }) => {
        const from = msg.key.remoteJid;
        if (args.length < 1) {
            return await react(from, '❌');
        }
        
        const nama = args[0];
        try {
            await react(from, '⏳');
            await pm2api.startStoppedBot(nama);
            await react(from, '✅');
        } catch (error) {
            console.error('[STARTBOT ERROR]', error);
            await react(from, '❌');
        }
    }
};
