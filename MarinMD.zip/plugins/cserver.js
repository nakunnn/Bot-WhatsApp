const osu = require('node-os-utils');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const targetGroup = "120363405675223209@g.us";

function formatRuntime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return `${hours} Jam ${minutes} Menit ${secs} Detik`;
}

function getBotRam() {
    const mem = process.memoryUsage();
    return (mem.rss / (1024 * 1024)).toFixed(2);
}

function getSystemStats() {
    const totalMem = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(2);
    const freeMem = (os.freemem() / (1024 * 1024 * 1024)).toFixed(2);
    const usedMem = (totalMem - freeMem).toFixed(2);
    const usedPercent = ((usedMem / totalMem) * 100).toFixed(1);
    return { totalMem, usedMem, usedPercent };
}

async function getStats() {
    const uptime = formatRuntime(process.uptime());
    const botRam = getBotRam();
    const system = getSystemStats();

    let diskUsage = "N/A";
    try {
        const drive = osu.drive;
        if (drive && typeof drive.info === 'function') {
            const info = await drive.info();
            diskUsage = `${info.usedGb}GB / ${info.totalGb}GB (${info.usedPercentage}%)`;
        } else {
            // Fallback pake command line jika library gagal
            const df = execSync('df -h / | tail -1').toString().trim().split(/\s+/);
            diskUsage = `${df[2]} / ${df[1]} (${df[4]})`;
        }
    } catch (e) {
        diskUsage = "Tidak tersedia";
    }

    const dbFile = path.join(__dirname, '../database/data_panel.json');
    let panelTotal = 0, panelOn = 0, panelOff = 0;
    if (fs.existsSync(dbFile)) {
        try {
            const data = JSON.parse(fs.readFileSync(dbFile));
            panelTotal = data.length;
            panelOn = data.filter(i => i.status === 'on').length;
            panelOff = data.filter(i => i.status === 'off').length;
        } catch (e) { }
    }

    const isJpmRunning = global.jpmState && (global.jpmState.isLooping || global.jpmState.intervalId);
    const jpmStatus = isJpmRunning ? "Aktif" : "Tidak Aktif";

    const afkFile = path.join(__dirname, '../afk.json');
    let afkCount = 0;
    if (fs.existsSync(afkFile)) {
        try {
            afkCount = Object.keys(JSON.parse(fs.readFileSync(afkFile))).length;
        } catch (e) { }
    }

    return { uptime, totalMem: system.totalMem, usedMem: system.usedMem, usedPercent: system.usedPercent, botRam, diskUsage, panelTotal, panelOn, panelOff, jpmStatus, afkCount };
}

async function sendScheduledReport() {
    const s = await getStats();
    const timeNow = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta", hour: "2-digit", minute: "2-digit" });

    const teks = `╭[ LAPORAN HARIAN ]
│ - Waktu: ${timeNow} WIB
│ - Runtime: ${s.uptime}
│ - Bot RAM: ${s.botRam} MB
│ - Server RAM: ${s.usedMem}GB / ${s.totalMem}GB (${s.usedPercent}%)
│ - Disk: ${s.diskUsage}
│ - Status: Hidup
│ 
│ --- DATA PANEL ---
│ - Total: ${s.panelTotal}
│ - Terpakai (on): ${s.panelOn}
│ - Tersedia (off): ${s.panelOff}
│ 
│ --- STATUS FITUR ---
│ - Auto JPM: ${s.jpmStatus}
│ - AFK Aktif: ${s.afkCount} User
╰────────────❱
©NakunStore`;

    if (global.sock) {
        await global.sock.sendMessage(targetGroup, { text: teks });
    }
}

module.exports = {
    command: 'cserver',
    description: 'Displays current server RAM, CPU, and Disk usage',
    execute: async (sock, msg, args) => {
        try {
            let cpuUsage = "N/A";
            try {
                const cpu = osu.cpu;
                if (cpu && typeof cpu.usage === 'function') {
                    cpuUsage = await cpu.usage();
                } else {
                    // Fallback pake Load Avg (1 min)
                    const load = os.loadavg();
                    cpuUsage = (load[0] * 100 / os.cpus().length).toFixed(1);
                }
            } catch (e) { 
                cpuUsage = "N/A";
            }

            const system = getSystemStats();
            const botRam = getBotRam();

            let diskUsage = "N/A";
            try {
                const drive = osu.drive;
                if (drive && typeof drive.info === 'function') {
                    const info = await drive.info();
                    diskUsage = `${info.usedPercentage}% of ${info.totalGb}GB`;
                } else {
                    const df = execSync('df -h / | tail -1').toString().trim().split(/\s+/);
                    diskUsage = `${df[4]} of ${df[1]}`;
                }
            } catch (e) { }

            const cseverText = `╭❰ SERVER STATUS ❱\n` +
                               `│ ⟡ Runtime: ${formatRuntime(process.uptime())}\n` +
                               `│ ⟡ CPU Load: ${cpuUsage}%\n` +
                               `│ ⟡ RAM System: ${system.usedMem}GB / ${system.totalMem}GB (${system.usedPercent}%)\n` +
                               `│ ⟡ RAM Bot: ${botRam}MB\n` +
                               `│ ⟡ Disk Usage: ${diskUsage}\n` +
                               `╰────────────❱\n©NakunStore`;

            await sock.sendMessage(msg.key.remoteJid, { text: cseverText }, { quoted: msg });
        } catch (err) {
            console.error(err);
            await sock.sendMessage(msg.key.remoteJid, { text: '╭❰ ERROR ❱\n│ ⟡ Gagal mengambil statistik server.\n╰────────────❱\n©NakunStore' }, { quoted: msg });
        }
    },
    startReporting: () => {
        if (!global.reportInterval) {
            global.reportInterval = setInterval(() => {
                const now = new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta", hour12: false });
                const dateObj = new Date(now);
                const hour = dateObj.getHours();
                const minute = dateObj.getMinutes();

                if ((hour === 0 || hour === 12) && minute === 0) {
                    sendScheduledReport();
                }
            }, 60000);
            console.log('[AUTO] Background reporting task initialized (cserver.js)');
        }
    }
};
