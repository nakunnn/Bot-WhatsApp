const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'kirimfile',
    description: 'Mengirimkan file fisik dari brankas ke pengguna',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;

        if (args.length < 1) {
            const petunjuk = `╭❰ FORMAT SALAH ❱\n│ ⟡ Gunakan: .kirimfile [nama_file_beserta_ekstensinya]\n│ ⟡ Contoh: .kirimfile script_auto.zip\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        const namaFile = args.join(" ");
        const filePath = path.join(__dirname, '../brankasfile', namaFile);

        if (!fs.existsSync(filePath)) {
            const brankasPath = path.join(__dirname, '../brankasfile');
            const files = fs.existsSync(brankasPath) ? fs.readdirSync(brankasPath) : [];
            const listFiles = files.filter(f => !f.startsWith('.')).map(f => `│ ⟡ ${f}`).join('\n');
            
            const warning = `╭❰ FILE TIDAK TERSEDIA ❱
│ ⟡ File "${namaFile}" tidak ditemukan.
╰────────────❱
╭❰ DAFTAR FILE TERSEDIA ❱
${listFiles || "│ (Kosong)"}
╰────────────❱
©NakunStore`;
            return sock.sendMessage(from, { text: warning }, { quoted: msg });
        }

        await sock.sendMessage(from, { text: `╭❰ PENGIRIMAN FILE ❱\n│ ⟡ Proses mengirim harap tunggu...\n╰────────────❱\n©NakunStore` }, { quoted: msg });

        const captionTeks = `╭❰ PENGIRIMAN FILE ❱
│ ⟡ Nama File: ${namaFile}
│ ⟡ Status: Aman / Tested
│ ⟡ Info: Harap ekstrak/baca panduan
│ ⟡ Terima kasih sudah order!
╰────────────❱
©NakunStore`;

        await sock.sendMessage(from, { 
            document: { url: filePath }, 
            fileName: namaFile, 
            caption: captionTeks,
            mimetype: 'application/octet-stream'
        }, { quoted: msg });
    }
};
