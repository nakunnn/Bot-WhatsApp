const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'reply',
    description: 'Mengaktifkan atau menonaktifkan auto-reply PM',
    execute: async (sock, m, { args, reply, isOwner }) => {
        if (!isOwner) return reply(global.mess.owner);
        
        const dbPath = path.join(__dirname, '../database/autoreply.json');
        const dbDir = path.dirname(dbPath);
        if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

        let db = { status: false, message: 'Halo! Pesan kamu sudah diterima.\nMohon tunggu balasan dari admin.\n\n©NakunStore' };
        if (fs.existsSync(dbPath)) {
            try {
                db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
            } catch (e) {}
        }

        if (args[0] === 'on') {
            db.status = true;
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 4));
            reply('✅ Auto-reply PM telah diaktifkan.');
        } else if (args[0] === 'off') {
            db.status = false;
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 4));
            reply('❌ Auto-reply PM telah dinonaktifkan.');
        } else if (args.length > 0) {
            db.message = args.join(' ');
            db.status = true;
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 4));
            reply('✅ Pesan auto-reply telah diperbarui dan diaktifkan.');
        } else {
            reply(`╭❰ AUTO REPLY ❱
│ ⟡ Status: ${db.status ? 'Aktif' : 'Tidak Aktif'}
│ ⟡ Pesan: ${db.message}
╰────────────❱

*Cara Penggunaan:*
- .reply on (Aktifkan)
- .reply off (Matikan)
- .reply [teks] (Set pesan)`);
        }
    },

    handlePM: async (sock, m) => {
        const from = m.key.remoteJid;
        const dbPath = path.join(__dirname, '../database/autoreply.json');
        
        // Skip if not PM
        if (from.endsWith('@g.us')) return;

        // Anti-spam: Only reply if the message is from the other person
        if (m.key.fromMe) return;

        // Get text and skip if it's a command
        let text = m.message.conversation || m.message.extendedTextMessage?.text || m.message.imageMessage?.caption || "";
        if (text.startsWith('.')) return; 

        if (!fs.existsSync(dbPath)) return;

        let db;
        try {
            db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
        } catch (e) { return; }

        if (!db.status) return;

        // Banner from user request
        const bannerUrl = "https://files.catbox.moe/473n1z.jpeg";
        
        // Style from menu.js and photo
        const message = {
            interactiveMessage: {
                title: db.message,
                footer: "⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫 | ©NakunStore",
                image: { url: bannerUrl },
                nativeFlowMessage: {
                    messageParamsJson: JSON.stringify({
                        limited_time_offer: {
                            text: "𝐍𝐀𝐊𝐔𝐍 𝐗 𝐌𝐀𝐑𝐈𝐍",
                            url: "https://wa.me/6285726013874",
                            copy_code: "MARINV15",
                            expiration_time: Date.now() + (24 * 60 * 60 * 1000)
                        },
                        bottom_sheet: {
                            in_thread_buttons_limit: 2,
                            divider_indices: [1],
                            list_title: "LIST",
                            button_title: "⿻ 𝐌𝐚𝐫𝐢𝐧"
                        }
                    }),
                    buttons: [{
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Daftar Menu",
                            id: ".menu"
                        })
                    }]
                }
            },
            contextInfo: {
                externalAdReply: {
                    title: "NAKUN STORE • AUTO REPLY",
                    body: "Silakan tunggu respon admin",
                    thumbnailUrl: bannerUrl,
                    sourceUrl: "https://wa.me/6285726013874",
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    showAdAttribution: true
                }
            }
        };

        await sock.sendMessage(from, message, { quoted: m });
    }
};
