const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'link',
    description: 'Menampilkan list txt atau isi dari file txt di folder link',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const linkDir = path.join(__dirname, '..', 'link');

        if (!fs.existsSync(linkDir)) {
            fs.mkdirSync(linkDir, { recursive: true });
        }

        if (args.length === 0) {
            // Tampilkan menu list file txt
            const files = fs.readdirSync(linkDir).filter(f => f.endsWith('.txt'));
            if (files.length === 0) {
                await sock.sendMessage(from, { text: "📂 Tidak ada file txt di folder link." }, { quoted: msg });
                return;
            }

            let teks = "📂 *DAFTAR FILE TXT*\n\n";
            files.forEach((file, index) => {
                teks += `${index + 1}. ${file}\n`;
            });
            teks += "\nKetik *.link namafile.txt* atau *.link namafile* untuk melihat isinya.";

            await sock.sendMessage(from, { text: teks }, { quoted: msg });
            return;
        }

        // Tampilkan isi file
        let fileName = args[0];
        if (!fileName.endsWith('.txt')) {
            fileName += '.txt';
        }

        const filePath = path.join(linkDir, fileName);

        if (fs.existsSync(filePath)) {
            const isi = fs.readFileSync(filePath, 'utf8');
            await sock.sendMessage(from, { text: isi }, { quoted: msg });
        } else {
            await sock.sendMessage(from, { text: `⚠️ File *${fileName}* tidak ditemukan.` }, { quoted: msg });
        }
    }
};
