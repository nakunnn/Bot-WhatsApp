const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'ctxt',
    description: 'Membuat file txt baru di folder link',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const linkDir = path.join(__dirname, '..', 'link');

        if (!fs.existsSync(linkDir)) {
            fs.mkdirSync(linkDir, { recursive: true });
        }

        if (args.length < 2) {
            await sock.sendMessage(from, { text: "⚠️ Format salah! Gunakan: *.ctxt nama isi*" }, { quoted: msg });
            return;
        }

        let fileName = args[0];
        if (!fileName.endsWith('.txt')) {
            fileName += '.txt';
        }

        const isi = args.slice(1).join(' ');
        const filePath = path.join(linkDir, fileName);

        fs.writeFileSync(filePath, isi, 'utf8');
        await sock.sendMessage(from, { text: `✅ File *${fileName}* berhasil dibuat!\n\nIsi: ${isi}` }, { quoted: msg });
    }
};
