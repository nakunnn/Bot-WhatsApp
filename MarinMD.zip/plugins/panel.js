const axios = require('axios');
const fs = require('fs');

module.exports = {
    command: ['panel', '1gb', '2gb', '3gb', '4gb', '5gb', '6gb', '7gb', '8gb', '9gb', '10gb', 'unli', 'unlimited'],
    execute: async (sock, m, { args, q, command, isOwner, isReseller, reply }) => {
        let checkReseller = isReseller;
        if (checkReseller === undefined) {
            try {
                const reseller = JSON.parse(fs.readFileSync("./Connection/database/reseller.json"));
                checkReseller = reseller.includes(m.sender) || isOwner;
            } catch (e) {
                checkReseller = isOwner;
            }
        }

        if (!isOwner && !checkReseller) return reply("Fitur ini khusus untuk Owner atau Reseller!");

        let spek, username;
        if (command === 'panel') {
            if (args.length < 2) return reply("⚠️ Format: .panel [spek] [username]\nContoh: .panel 5gb nakun");
            spek = args[0].toLowerCase();
            username = args[1].toLowerCase();
        } else {
            if (!args.length) return reply(`Masukkan username!\nContoh: .${command} nakun`);
            spek = command;
            username = args[0].toLowerCase();
        }

        let memory, disk, cpu;
        if (spek === "1gb") { memory = "1000"; disk = "1000"; cpu = "40"; }
        else if (spek === "2gb") { memory = "2000"; disk = "1000"; cpu = "60"; }
        else if (spek === "3gb") { memory = "3000"; disk = "2000"; cpu = "80"; }
        else if (spek === "4gb") { memory = "4000"; disk = "2000"; cpu = "100"; }
        else if (spek === "5gb") { memory = "5000"; disk = "3000"; cpu = "120"; }
        else if (spek === "6gb") { memory = "6000"; disk = "3000"; cpu = "140"; }
        else if (spek === "7gb") { memory = "7000"; disk = "4000"; cpu = "160"; }
        else if (spek === "8gb") { memory = "8000"; disk = "4000"; cpu = "180"; }
        else if (spek === "9gb") { memory = "9000"; disk = "5000"; cpu = "200"; }
        else if (spek === "10gb") { memory = "10000"; disk = "5000"; cpu = "220"; }
        else if (spek === "unli" || spek === "unlimited") { memory = "0"; disk = "0"; cpu = "0"; }
        else {
            return reply("⚠️ Spesifikasi tidak didukung!\nPilih salah satu: 1gb, 2gb, 3gb, 4gb, 5gb, 6gb, 7gb, 8gb, 9gb, 10gb, unli");
        }

        const email = `${username}@gmail.com`;
        const name = `${username.charAt(0).toUpperCase() + username.slice(1)} Server`;
        
        // Format password: nakunstr + angka acak 1-999
        const randomNum = Math.floor(Math.random() * 999) + 1;
        const password = `nakunstr${randomNum}`;

        if (!global.domain) {
            return reply("❌ Hubungi admin, domain panel belum dikonfigurasi di config.js.");
        }

        // Bersihkan domain dari trailing slash '/' agar tidak double-slash di URL
        let domain = global.domain.trim();
        if (domain.endsWith('/')) {
            domain = domain.slice(0, -1);
        }

        // Ambil semua API Keys (baik yang array maupun single fallback) untuk redundansi
        let keys = [];
        if (Array.isArray(global.capikeys)) {
            keys = [...global.capikeys];
        }
        const singleKey = global.capikey || global.apikey;
        if (singleKey && !keys.includes(singleKey)) {
            keys.push(singleKey);
        }

        if (keys.length === 0) {
            return reply("❌ Hubungi admin, apikey panel belum dikonfigurasi di config.js.");
        }

        // Helper function untuk melakukan request Axios dengan rotasi API Key jika unauthenticated (401)
        async function requestWithRetry(method, url, data = null) {
            let lastErr;
            for (let i = 0; i < keys.length; i++) {
                const activeKey = keys[i];
                try {
                    const config = {
                        method: method,
                        url: url,
                        headers: {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": `Bearer ${activeKey}`
                        }
                    };
                    if (data) config.data = data;
                    
                    const res = await axios(config);
                    return { data: res.data, workingKey: activeKey };
                } catch (err) {
                    lastErr = err;
                    // Hanya rotasi/lanjut ke key berikutnya jika statusnya 401 (Unauthenticated)
                    if (err.response && err.response.status === 401) {
                        console.log(`[PTLA ROTATION] Key index ${i} failed with 401, trying next key...`);
                        continue;
                    }
                    // Jika error lain (seperti 404, 422, dll), langsung throw karena key-nya benar tapi inputnya salah
                    throw err;
                }
            }
            throw lastErr;
        }

        try {
            // 1. Create User (dengan rotasi API Key)
            let userRes = await requestWithRetry('POST', `${domain}/api/application/users`, {
                email: email,
                username: username,
                first_name: name,
                last_name: "Server",
                language: "en",
                password: password
            });
            let userData = userRes.data;
            let userId = userData.attributes.id;
            const successfulKey = userRes.workingKey; // Gunakan key yang terbukti aktif untuk request selanjutnya

            // 2. Get Egg Startup
            let eggRes = await axios.get(`${domain}/api/application/nests/${global.nestid}/eggs/${global.egg}`, {
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${successfulKey}`
                }
            });
            let eggData = eggRes.data;
            let startup = eggData.attributes.startup;

            // 3. Create Server
            let serverRes = await axios.post(`${domain}/api/application/servers`, {
                name: name,
                description: "Created by Marin Bot",
                user: userId,
                egg: parseInt(global.egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
                startup: startup,
                environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                limits: { memory: parseInt(memory), swap: 0, disk: parseInt(disk), io: 500, cpu: parseInt(cpu) },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(global.loc)], dedicated_ip: false, port_range: [] }
            }, {
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${successfulKey}`
                }
            });
            let serverData = serverRes.data;
            let attributes = serverData.attributes;
            let target = m.isGroup ? m.sender : m.chat;
            
            if (m.isGroup) reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat");

            let resultText = `╭❰ AKUN PANEL DIBUAT ❱
│ ⟡ ID Server : ${attributes.id}
│ ⟡ Nama      : ${name}
│ ⟡ Username  : ${userData.attributes.username}
│ ⟡ Password  : ${password}
│ ⟡ RAM       : ${memory === "0" ? "Unlimited" : memory + " MB"}
│ ⟡ CPU       : ${cpu === "0" ? "Unlimited" : cpu + "%"}
│ ⟡ Disk      : ${disk === "0" ? "Unlimited" : disk + " MB"}
│ ⟡ Login     : ${domain}
╰────────────❱
©NakunStore`;

            await sock.sendMessage(target, { text: resultText }, { quoted: m });

        } catch (err) {
            if (err.response) {
                if (err.response.status === 401) {
                    return reply(`❌ *Error 401: Unauthenticated*
Semua (${keys.length}) API Key yang dikonfigurasi di config.js ditolak oleh panel Anda. Silakan periksa kembali apakah key tersebut aktif.`);
                }
                if (err.response.status === 404) {
                    return reply(`❌ *Error 404: Not Found*
Kemungkinan penyebab:
1. ID Nest (${global.nestid}) atau ID Egg (${global.egg}) di config.js tidak terdaftar di panel Anda.
2. URL domain panel di config.js salah.`);
                }
                if (err.response.data && err.response.data.errors) {
                    return reply(`❌ *Error Panel:*
${JSON.stringify(err.response.data.errors[0].detail || err.response.data.errors[0].message || err.response.data.errors[0], null, 2)}`);
                }
            }
            console.error(err);
            reply(`❌ Terjadi kesalahan: ${err.message}`);
        }
    }
};
