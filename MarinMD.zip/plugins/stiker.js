module.exports = {
    command: ['s', 'sticker', 'stiker'],
    execute: async (sock, m, { prefix, command, reply }) => {
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || "";
        
        if (/image/.test(mime)) {
            let media = await quoted.download();
            await sock.sendImageAsSticker(m.chat, media, m, {
                packname: global.packname,
                author: global.author
            });
        } else if (/video/.test(mime)) {
            if ((quoted.msg || quoted).seconds > 11) {
                return reply(`Reply Gambar Dengan Keterangan/Caption ${prefix + command}\nJika Media Yang Ingin Dijadikan Sticker Adalah Video, Batas Maksimal Durasi Video 1-9 Detik`);
            }
            let media = await quoted.download();
            await sock.sendVideoAsSticker(m.chat, media, m, {
                packname: global.packname,
                author: global.author
            });
        } else {
            reply(`Reply Gambar Dengan Keterangan/Caption ${prefix + command}\nDurasi Video 1-9 Detik`);
        }
    }
};
