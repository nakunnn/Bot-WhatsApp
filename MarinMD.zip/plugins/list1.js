module.exports = {
    command: 'price',
    description: 'Menampilkan menu harga (panel, file, top-up, sc)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const teks = `.sendd edit ⚜️ *NAKUNSTORE — FILE & UNCEK*

📍 *Order Hubungi :*
*Admin :* _085879673319_

*GAMEBOOSTER VIP : 5K*

*WEB BUG 10K/15K/20K*

*🔰[ UNCHEK GG ]*
*💌 5 UNCHEK - 4K* ~7k~
*💌 15 UNCHEK - 8K* ~15k~
*💌 25 UNCHEK - 18K* ~25k~
*💌 40 UNCHEK - 28K* ~35k~
*💌 100 UNCHEK - 38K* ~45k~
*💌 150 UNCHEK - 48K* ~100k~

*🔰[ UNCHECK PREMIUM ]*
*🎁 20 UNCHEK - 14K* ~20k~
*🎁 30 UNCHEK - 19K* ~29k~
*🎁 40 UNCHEK - 24K* ~35k~
*🎁 50 UNCHEK - 29K* ~39k~
*🎁 100 UNCHEK - 49K* ~70k~
*BELI DI ATAS 50K PASTI DAPET POLOSAN SG*

*🔰[ UNCHECK VVIP ]*
*🎁 20 UNCHEK - 19K* ~30k~
*🎁 30 UNCHEK - 29K* ~35k~
*🎁 40 UNCHEK - 39K* ~40k~
*🎁 50 UNCHEK - 49K* ~45k~
*🎁 100 UNCHEK - 69K* ~80k~
*BELI DIATAS 50K PASTI DAPET AKUN OLD S1 S2 S3 S4*

*🔰[ UNCHECK ANTI ZONK ]*
*⚜️ 10 UNCHEK - 29K* ~50k~
*⚜️ 20 UNCHEK - 39K* ~70k~
*⚜️ 25 UNCHEK - 49K* ~90k~
*⚜️ 30 UNCHEK - 59K* ~100k~
*⚜️ 60 UNCHEK - 99K* ~150k~
*UNCHECK ANTI ZONK 100%*
*GADAPET? DIGANTI*

✨ *KENAPA HARUS DI SINI?*
✅ *600+ Testimoni Terpercaya*
✅ *Proses Instant & Aman*
✅ *Support All Payment*

📍 *Order Hubungi :*
*Admin :* _085879673319_`;
        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
