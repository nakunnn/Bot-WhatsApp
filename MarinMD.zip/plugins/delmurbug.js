const fs = require('fs');

module.exports = {
    command: 'delmurbug',
    execute: async (sock, m, { args, q, prefix, command, isOwner, reply }) => {
        if (!isOwner) return reply("Fitur ini hanya dapat di akses oleh owner bot");
        if (!args[0]) return reply(`Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} 6285726013874`);
        
        let bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        let premium = JSON.parse(fs.readFileSync("./Connection/database/premium.json"));
        let unp = premium.indexOf(bro);
        if (unp === -1) return reply("Nomor tersebut tidak terdaftar sebagai murbug.");
        
        premium.splice(unp, 1);
        fs.writeFileSync("./Connection/database/premium.json", JSON.stringify(premium));
        reply(`Nomor ${bro} Telah Di Hapus Murbug!`);
    }
};
