const axios = require('axios');

module.exports = {
    command: ['nglspam', 'ngl'],
    description: 'Mengirim pesan spam ke link NGL',
    execute: async (sock, msg, { args, reply, react, pushname }) => {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0].split(':')[0];

        if (args.length < 3) {
            return reply('❌ *Format salah!*\nFormat: `.nglspam [url/username] [jumlah] [pesan]`\nContoh: `.nglspam https://ngl.link/nakun 5 Halo Kak`');
        }

        let targetUrl = args[0];
        // Jika hanya memasukkan username, ubah otomatis jadi full URL ngl.link
        if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
            targetUrl = `https://ngl.link/${targetUrl}`;
        }

        const jumlah = parseInt(args[1]);
        if (isNaN(jumlah) || jumlah <= 0) {
            return reply('❌ Jumlah spam harus berupa angka positif.');
        }

        if (jumlah > 100) {
            return reply('❌ Jumlah maksimal spam adalah 100 pesan.');
        }

        const pesan = args.slice(2).join(' ');

        await react(from, '⏳');
        const processingMessage = await sock.sendMessage(from, { text: `🚀 *Sedang mengirim ${jumlah} pesan NGL ke ${targetUrl}...*` }, { quoted: msg });

        try {
            const apiUrl = `https://api.nexadev.my.id/tools/nglspam/?url=${encodeURIComponent(targetUrl)}&jumlah=${jumlah}&pesan=${encodeURIComponent(pesan)}`;
            
            const response = await axios.get(apiUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                timeout: 120000 // NGL spam can take some time if the count is high
            });

            const data = response.data;

            if (data.status) {
                const caption = `╭───────❰ *NGL SPAMMER* ❱───────
│
│  ✧ *Target:* ${targetUrl}
│  ✧ *Jumlah:* ${jumlah} Pesan
│  ✧ *Pesan :* "${pesan}"
│  ✧ *Pengguna:* @${senderNumber} (${pushname})
│
├────────────────────────────
│  ⚡ *Status:* ${data.result || 'Berhasil terkirim!'}
│  ❐ MarinMD | © NakunStore
╰────────────────────────────`;

                await sock.sendMessage(from, {
                    text: caption,
                    mentions: [sender]
                }, { quoted: msg });

                await react(from, '✅');
            } else {
                await react(from, '❌');
                await sock.sendMessage(from, { text: `❌ *Gagal:* ${data.result || 'Terjadi kesalahan dari API.'}` }, { quoted: msg });
            }

        } catch (error) {
            console.error('[NGLSPAM] Error:', error);
            await react(from, '❌');
            let errDetail = error.message;
            if (error.response?.data) {
                try {
                    const jsonErr = error.response.data;
                    errDetail = jsonErr.result || jsonErr.message || errDetail;
                } catch (_) {}
            }
            await sock.sendMessage(from, { text: `❌ *Error:* ${errDetail}` }, { quoted: msg });
        } finally {
            try {
                await sock.sendMessage(from, { delete: processingMessage.key }).catch(() => {});
            } catch (_) {}
        }
    }
};
