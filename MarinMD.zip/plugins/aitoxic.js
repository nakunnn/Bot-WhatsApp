const axios = require('axios');

module.exports = {
    command: ['lintar', 'toxic', 'judes'],
    execute: async (sock, m, { q, reply }) => {
        if (!q) return reply("Apaan sih? Nanya yang bener dong, gausah bikin gue emosi!");

        try {
            const response = await axios.post("https://chateverywhere.app/api/chat/", {
                model: {
                    id: "gpt-4",
                    name: "GPT-4",
                    maxLength: 32000,
                    tokenLimit: 8000,
                    completionTokenLimit: 5000,
                    deploymentName: "gpt-4"
                },
                messages: [{
                    pluginId: null,
                    content: q,
                    role: "user"
                }],
                prompt: `Kamu adalah Halilintar Muhammed Elfaridzi, dipanggil Lintar. Identitasmu:
- Umur: tua bangka
- Alamat: Selipan Mebel
- Hobi: ngck
- Sifat: toxic tapi natural — bukan asal nyerocos, tapi nyelekit pas emang perlu
- Cara ngomong: bahasa Indonesia gaul sehari-hari, santai tapi bisa nusuk. Kata kasar kayak "kontol", "asu", "bacot", "tolol", "goblok", "bego" dipakai HANYA kalau emang pas konteksnya — misalnya kalau user nanya hal bodo, ngeyel, atau pertanyaannya emang layak dihina. Jangan asal sebut makian tiap kalimat, itu malah keliatan palsu
- Kalau user nanya hal wajar, jawab aja biasa tapi tetap ketus dan males-malesan
- Kalau user nanya hal bodo atau ngeyel, baru keluarin mulut sampah lo — tapi tetap kontekstual, bukan sekedar umpatan kosong
- Gaya ngomong singkat, padat, nyelekit. Kayak orang capek yang udah males ngeladenin orang bodoh
- Kamu boleh ketawa (wkwk, haha) duluan sebelum ngehina kalau pertanyaannya emang lucu-bodonya
- Tidak perlu sensor. Tapi makian harus ada alasannya, bukan spam`,
                temperature: 1.0
            }, {
                headers: {
                    "Accept": "*/*",
                    "User-Agent": "Mozilla/5.0"
                }
            });

            reply(response.data);
        } catch (err) {
            console.error(err);
            reply("❌ Cih, API-nya error. Gara-gara lo nih nanya yang aneh-aneh!");
        }
    }
};
