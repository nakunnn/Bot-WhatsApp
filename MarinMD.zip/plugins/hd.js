const axios = require('axios');
const FormData = require('form-data');

module.exports = {
    command: ['hd', 'remini', 'upscale'],
    description: 'Meningkatkan kualitas gambar menjadi HD',
    execute: async (sock, msg, { args, reply, react, pushname }) => {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0].split(':')[0];

        // Cari media image dari quote atau pesan langsung
        let mediaMsg = null;
        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (quotedMsg) {
            if (quotedMsg.imageMessage) mediaMsg = quotedMsg.imageMessage;
        }
        if (!mediaMsg) {
            if (msg.message?.imageMessage) mediaMsg = msg.message.imageMessage;
        }

        let imageUrl = '';

        if (mediaMsg) {
            await react(from, '⏳');
            const loadingMessage = await sock.sendMessage(from, { text: '🔄 *Sedang mengunduh dan memproses gambar Anda...*' }, { quoted: msg });

            try {
                // Download image
                const buffer = await sock.downloadMediaMessage(mediaMsg);
                if (!buffer || buffer.length === 0) {
                    await react(from, '❌');
                    try { await sock.sendMessage(from, { delete: loadingMessage.key }); } catch (_) {}
                    return reply('❌ Gagal mengunduh gambar dari WhatsApp.');
                }

                // Upload ke Catbox
                const mime = mediaMsg.mimetype || 'image/jpeg';
                const cleanMime = mime.split(';')[0].trim();
                const filename = `hd_${Date.now()}.jpg`;

                const form = new FormData();
                form.append('reqtype', 'fileupload');
                form.append('fileToUpload', buffer, { filename, contentType: cleanMime });

                const uploadResponse = await axios.post('https://catbox.moe/user/api.php', form, {
                    headers: form.getHeaders(),
                    maxContentLength: Infinity,
                    maxBodyLength: Infinity,
                    timeout: 60000,
                });

                const uploadedUrl = (uploadResponse.data || '').toString().trim();
                if (!uploadedUrl.startsWith('https://')) {
                    throw new Error('Gagal mengunggah gambar ke server penyimpanan sementara.');
                }

                imageUrl = uploadedUrl;
            } catch (err) {
                console.error('[HD] Upload Error:', err);
                await react(from, '❌');
                try { await sock.sendMessage(from, { delete: loadingMessage.key }); } catch (_) {}
                return reply(`❌ *Error Upload:* ${err.message}`);
            }

            // Hapus pesan loading download/upload
            try { await sock.sendMessage(from, { delete: loadingMessage.key }).catch(() => {}); } catch (_) {}
        } else if (args && args.length > 0 && /^https?:\/\//i.test(args[0])) {
            imageUrl = args[0];
        } else {
            return reply('❌ Reply/quote gambar yang ingin ditingkatkan kualitasnya, atau kirim URL gambar langsung!\nContoh: Reply gambar dengan ketik *.hd*');
        }

        // Jalankan proses HD enhancer
        await react(from, '⏳');
        const enhancingMessage = await sock.sendMessage(from, { text: '✨ *Sedang meningkatkan resolusi gambar (Upscaling HD)...*' }, { quoted: msg });

        try {
            const apiUrl = `http://api.nexadev.my.id/tools/hd/?image=${encodeURIComponent(imageUrl)}`;
            const response = await axios.get(apiUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                timeout: 60000
            });

            const data = response.data;

            if (data.status === false || !data.result?.image_upscaled) {
                await react(from, '❌');
                const errMsg = data.message || data.msg || 'Gagal memproses gambar HD pada API.';
                return sock.sendMessage(from, { text: `❌ *Gagal HD:* ${errMsg}` }, { quoted: msg });
            }

            const hdUrl = data.result.image_upscaled;

            const caption = `╭──────❰ *NEXADEV HD ENHANCER* ❱──────
│
│  ✧ *Fitur:* HD Image Upscaler (Remini)
│  ✧ *Pengguna:* @${senderNumber} (${pushname})
│
├────────────────────────────
│  ⚡ *Status:* Sukses ditingkatkan!
╰────────────────────────────`;

            await sock.sendMessage(from, {
                image: { url: hdUrl },
                caption: caption,
                mentions: [sender]
            }, { quoted: msg });

            await react(from, '✅');
        } catch (error) {
            console.error('[HD] API Enhancer Error:', error);
            await react(from, '❌');
            const errDetail = error.response?.data?.message || error.response?.data?.msg || error.message;
            await sock.sendMessage(from, { text: `❌ *Error Enhancer:* ${errDetail}` }, { quoted: msg });
        } finally {
            try {
                await sock.sendMessage(from, { delete: enhancingMessage.key }).catch(() => {});
            } catch (_) {}
        }
    }
};
