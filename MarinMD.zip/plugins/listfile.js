const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'listfile',
    description: 'Menampilkan daftar file dalam brankas',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const folderPath = path.join(__dirname, '../brankasfile');

        if (!fs.existsSync(folderPath)) {
            const petunjuk = `╭❰ BRANKAS KOSONG ❱\n│ ⟡ Folder belum tersedia\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        const files = fs.readdirSync(folderPath);

        if (files.length === 0) {
            const petunjuk = `╭❰ BRANKAS KOSONG ❱\n│ ⟡ Tidak ada file tersimpan\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        const hasilMapping = files.map(file => `│ ⟡ ${file}`).join('\n');

        const teks = `╭❰ LIST FILE BRANKAS ❱
${hasilMapping}
│ ⟡ KETERANGAN:
│ ⟡ dhs : Drag HS
│ ⟡ ed : Easy Drag
│ ⟡ Stab : stabilizer
│ ⟡ bl : Bodylock
│ ⟡ gbv : GameboosterVVIP
╰────────────❱\n©NakunStore`;

        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
