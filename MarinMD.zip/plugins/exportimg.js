const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');
const { loadRevenue } = require('../lib/gsheets');

// ── Helper format rupiah ──────────────────────────────────────────────
const fmt = (n) => Number(n).toLocaleString('id-ID');

// ── Generate HTML tabel omzet ─────────────────────────────────────────
function buildHTML(db, tanggalGenerate) {
    let totalMasuk = 0, totalMe = 0, totalReseller = 0, totalTrx = 0;

    const rows = db.map((item, idx) => {
        totalMasuk    += Number(item.masuk) || 0;
        totalMe       += Number(item.untung_me) || 0;
        totalReseller += Number(item.untung_reseller) || 0;
        totalTrx      += Number(item.trx) || 1;

        const bg = idx % 2 === 0 ? '#1e1e3a' : '#16162b';
        return `
        <tr style="background:${bg}">
            <td class="center">${idx + 1}</td>
            <td class="center">${item.tanggal || '-'}</td>
            <td class="center">${item.waktu || '-'}</td>
            <td>${item.keterangan || '-'}</td>
            <td class="center badge">${item.kategori || 'RETAIL'}</td>
            <td class="right">Rp ${fmt(item.masuk)}</td>
            <td class="right">Rp ${fmt(item.untung_me)}</td>
            <td class="right">Rp ${fmt(item.untung_reseller)}</td>
            <td class="center">${item.trx || 1}</td>
        </tr>`;
    }).join('');

    return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #0d0d1a;
    padding: 28px;
    min-width: 900px;
  }

  /* ── Header kartu ── */
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: linear-gradient(135deg, #1a1a3e 0%, #0d0d1a 100%);
    border: 1px solid #ffd700;
    border-radius: 14px;
    padding: 18px 28px;
    margin-bottom: 20px;
  }
  .header .logo {
    font-size: 26px;
    font-weight: 800;
    color: #ffd700;
    letter-spacing: 1px;
  }
  .header .logo span { color: #fff; }
  .header .meta {
    text-align: right;
    color: #aaa;
    font-size: 13px;
    line-height: 1.6;
  }
  .header .meta strong { color: #ffd700; }

  /* ── Stat card row ── */
  .stats {
    display: flex;
    gap: 14px;
    margin-bottom: 20px;
  }
  .stat-card {
    flex: 1;
    background: linear-gradient(135deg, #1e1e3a, #16162b);
    border: 1px solid #333366;
    border-radius: 10px;
    padding: 14px 18px;
  }
  .stat-card .label { font-size: 11px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; }
  .stat-card .value { font-size: 18px; font-weight: 700; color: #ffd700; }
  .stat-card .value.white { color: #fff; }

  /* ── Tabel ── */
  table {
    width: 100%;
    border-collapse: collapse;
    border-radius: 12px;
    overflow: hidden;
    font-size: 13px;
  }
  thead tr {
    background: linear-gradient(90deg, #ffd700 0%, #ffaa00 100%);
  }
  thead th {
    padding: 11px 10px;
    color: #0d0d1a;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
  }
  tbody td {
    padding: 9px 10px;
    color: #ddd;
    border-bottom: 1px solid #1a1a30;
  }
  .center { text-align: center; }
  .right  { text-align: right; font-variant-numeric: tabular-nums; }

  .badge {
    font-size: 10px;
    font-weight: 700;
    background: #ffd70022;
    color: #ffd700;
    border: 1px solid #ffd70055;
    border-radius: 20px;
    padding: 2px 8px;
  }

  /* ── Baris total ── */
  .total-row td {
    background: linear-gradient(90deg, #ffd700 0%, #ffaa00 100%);
    color: #0d0d1a !important;
    font-weight: 800;
    font-size: 13px;
    padding: 11px 10px;
    border: none !important;
  }

  /* ── Footer ── */
  .footer {
    margin-top: 14px;
    text-align: center;
    font-size: 11px;
    color: #555;
    letter-spacing: 0.5px;
  }
</style>
</head>
<body>

  <!-- Header -->
  <div class="header">
    <div class="logo">Nakun<span>Store</span></div>
    <div class="meta">
      <strong>Laporan Omzet</strong><br>
      Digenerate: ${tanggalGenerate}<br>
      Total Entri: ${db.length} transaksi
    </div>
  </div>

  <!-- Stat cards -->
  <div class="stats">
    <div class="stat-card">
      <div class="label">Total Trx</div>
      <div class="value white">${totalTrx}</div>
    </div>
    <div class="stat-card">
      <div class="label">Uang Masuk</div>
      <div class="value">Rp ${fmt(totalMasuk)}</div>
    </div>
    <div class="stat-card">
      <div class="label">Untung Owner</div>
      <div class="value">Rp ${fmt(totalMe)}</div>
    </div>
    <div class="stat-card">
      <div class="label">Untung Reseller</div>
      <div class="value">Rp ${fmt(totalReseller)}</div>
    </div>
  </div>

  <!-- Tabel -->
  <table>
    <thead>
      <tr>
        <th style="width:40px">No</th>
        <th>Tanggal</th>
        <th>Waktu</th>
        <th>Produk / Keterangan</th>
        <th>Kategori</th>
        <th>Uang Masuk</th>
        <th>Untung Owner</th>
        <th>Untung Reseller</th>
        <th style="width:40px">Trx</th>
      </tr>
    </thead>
    <tbody>
      ${rows}
      <tr class="total-row">
        <td class="center" colspan="5">TOTAL KESELURUHAN</td>
        <td class="right">Rp ${fmt(totalMasuk)}</td>
        <td class="right">Rp ${fmt(totalMe)}</td>
        <td class="right">Rp ${fmt(totalReseller)}</td>
        <td class="center">${totalTrx}</td>
      </tr>
    </tbody>
  </table>

  <div class="footer">©NakunStore — Auto-generated by MarinBot</div>

</body>
</html>`;
}

// ── Plugin ────────────────────────────────────────────────────────────
module.exports = {
    command: 'exportimg',
    description: 'Ekspor data omzet dari Google Sheets sebagai foto (PNG)',
    execute: async (sock, m, { reply, react }) => {
        const from = m.key.remoteJid;

        await react(m.chat, '⏳');
        await reply(`╭❰ EXPORT FOTO OMZET ❱\n│ ⟡ Sedang mengambil data & membuat gambar...\n│ ⟡ Harap tunggu sebentar\n╰────────────❱\n©NakunStore`);

        // Ambil data
        const db = await loadRevenue();

        if (!db || db.length === 0) {
            await react(m.chat, '❌');
            return reply(`╭❰ EXPORT GAGAL ❱\n│ ⟡ Belum ada data omzet di Google Sheets\n│ ⟡ Gunakan .calc confirm untuk memasukkan data\n╰────────────❱\n©NakunStore`);
        }

        const tanggalGenerate = new Date().toLocaleString('id-ID', {
            timeZone: 'Asia/Jakarta',
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });

        // Buat direktori temp jika belum ada
        const tmpDir = path.join(__dirname, '../temp_screenshots');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

        const stamp    = tanggalGenerate.replace(/[/:, ]/g, '-').replace(/-+/g, '-');
        const fileName = `Omzet_NakunStore_${stamp}.png`;
        const filePath = path.join(tmpDir, fileName);

        // Screenshot dengan puppeteer
        let browser;
        try {
            browser = await puppeteer.launch({
                headless: 'new',
                args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu']
            });

            const page = await browser.newPage();
            const html = buildHTML(db, tanggalGenerate);

            await page.setContent(html, { waitUntil: 'networkidle0' });

            // Ukur tinggi konten sesungguhnya agar tidak terpotong
            const bodyHeight = await page.evaluate(() => document.body.scrollHeight);
            await page.setViewport({ width: 1000, height: bodyHeight, deviceScaleFactor: 2 });

            await page.screenshot({ path: filePath, fullPage: true });
        } catch (err) {
            if (browser) await browser.close();
            await react(m.chat, '❌');
            console.error('[exportimg] Puppeteer error:', err.message);
            return reply(`╭❰ ERROR ❱\n│ ⟡ Gagal membuat gambar\n│ ⟡ ${err.message}\n╰────────────❱\n©NakunStore`);
        } finally {
            if (browser) await browser.close();
        }

        // Hitung total untuk caption
        let totalMasuk = 0, totalMe = 0, totalReseller = 0, totalTrx = 0;
        for (const item of db) {
            totalMasuk    += Number(item.masuk) || 0;
            totalMe       += Number(item.untung_me) || 0;
            totalReseller += Number(item.untung_reseller) || 0;
            totalTrx      += Number(item.trx) || 1;
        }

        const caption = `╭❰ EXPORT FOTO OMZET ❱
│ ⟡ Entri  : ${db.length} transaksi
│ ⟡ Total Trx       : ${totalTrx}
│ ⟡ Uang Masuk      : Rp ${fmt(totalMasuk)}
│ ⟡ Untung Owner    : Rp ${fmt(totalMe)}
│ ⟡ Untung Reseller : Rp ${fmt(totalReseller)}
╰────────────❱
©NakunStore`;

        // Kirim sebagai foto
        await sock.sendMessage(
            from,
            {
                image: fs.readFileSync(filePath),
                caption: caption
            },
            { quoted: m }
        );

        await react(m.chat, '✅');

        // Hapus file temp
        fs.unlink(filePath, () => {});
    }
};
