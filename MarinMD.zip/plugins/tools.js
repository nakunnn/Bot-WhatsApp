const axios = require('axios');

module.exports = {
    command: ['ttstalk', 'cekidch', 'getcode', 'trackip', 'sertifikattolol', 'kisahnabi', 'muslimai'],
    execute: async (sock, m, { q, command, prefix, reply }) => {
        switch (command) {
            case 'ttstalk':
                if (!q) return reply("Masukkan username TikTok!");
                let stalk = await axios.get(`https://api.neoxr.eu/api/ttstalk?username=${q}&apikey=JPwFgM`);
                if (!stalk.data.status) return reply("Gagal mengambil data.");
                let s = stalk.data.data;
                let cap = `👤 *TIKTOK STALK*\n- Name: ${s.name}\n- Followers: ${s.followers}\n- Bio: ${s.bio}`;
                sock.sendMessage(m.chat, { image: { url: s.photo }, caption: cap }, { quoted: m });
                break;
                
            case 'cekidch':
                if (!q || !q.includes("channel/")) return reply("Link channel?");
                let id = q.split("channel/")[1];
                let meta = await sock.newsletterMetadata("invite", id);
                reply(`*ID:* ${meta.id}\n*Nama:* ${meta.name}\n*Followers:* ${meta.subscribers}`);
                break;

            case 'trackip':
                if (!q) return reply("Masukkan IP!");
                let ipRes = await axios.get(`https://ipwhois.app/json/${q}`);
                let ip = ipRes.data;
                reply(`📍 *IP Results*\n- Country: ${ip.country}\n- ISP: ${ip.isp}`);
                break;
                
            // ... more cases ...
        }
    }
};

