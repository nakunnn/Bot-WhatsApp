const fs = require('fs');

module.exports = {
    command: 'allmenu',
    execute: async (sock, m, { performance, runtime, quoted, react, prefix }) => {
        await react(m.chat, "🫪");
        
        let allMenuText = `\`ⓘ こんにちは、マリンです。お手伝いできるボットです。⚠︎\`

\`𠘰\` Author : Nakun
\`は\` Version : *15.0*
\`𠃮\` Prefix  : Multi
\`𠙖\` Speed  : *${(require('perf_hooks').performance.now() - performance).toFixed(5)} ms*
\`𠗖\` Runtime : *${runtime(process.uptime())}*

⏤ *〔 OWNER 〕*
${prefix}addowner <owner tambahan>
${prefix}delowner <owner tambahan>
${prefix}addmurbug <add access>
${prefix}delmurbug <del access>
${prefix}self
${prefix}public
${prefix}restart
${prefix}hidetag

⏤ *〔 FEATURES 〕*
${prefix}ektp <name>
${prefix}cekkhodam <name>
${prefix}cekkontol <name>
${prefix}cekidch <link channel>
${prefix}stiker <reply image>
${prefix}hd <reply image>
${prefix}nobg <reply image>
${prefix}img2pixel <reply image>
${prefix}nglspam <url> <jumlah> <pesan>
${prefix}wmp1 <teks>
${prefix}wmp2 <teks>
${prefix}nokia <teks> <tanggal> <waktu>
${prefix}patrick <teks>
${prefix}tiktok <link video>
${prefix}aio <link video/media>
${prefix}play <nama musik>
${prefix}bocilwindah <name>
${prefix}iqc <prompt>
${prefix}brat <prompt>
${prefix}getcode <link web>
${prefix}tourl <reply image>
${prefix}up <reply media>
${prefix}cekganteng <name>
${prefix}trackip <ip>
${prefix}quotesgalau
${prefix}dread <prompt>
${prefix}lintar <prompt>
${prefix}sertifikattolol <name>
${prefix}muslimai <prompt>
${prefix}kisahnabi <nama nabi>
${prefix}qc <prompt>
${prefix}swgrup <reply image/video>
${prefix}coding <prompt>
${prefix}ig <link instagram>
${prefix}antibadword <on/off>


⏤ *〔 PANEL 〕*
${prefix}1gb <username>
${prefix}2gb <username>
${prefix}3gb <username>
${prefix}4gb <username>
${prefix}5gb <username>
${prefix}6gb <username>
${prefix}7gb <username>
${prefix}8gb <username>
${prefix}9gb <username>
${prefix}10gb <username>
${prefix}unli <username>
${prefix}cadmin <username>
${prefix}delpanel <id server>
${prefix}deladmin <id server>
${prefix}listpanel
${prefix}listadmin
${prefix}addres <akses panel>
${prefix}delres <hapus akses panel>

⏤ *〔 STORE TOOLS 〕*
${prefix}calc <nominal>
${prefix}omzet
${prefix}min <nominal>
${prefix}unce <email> <jumlah>

⏤ *〔 BUG MENU 〕*
${prefix}marin-bug <target>
${prefix}blank-notif <target>
${prefix}crash-ip <target>
${prefix}invisible-delay <target>
${prefix}delay-maker <target>
${prefix}out-group
${prefix}kill-group <link>

⏤ *〔 NSFW 〕*
${prefix}nsfw
${prefix}asupan
${prefix}hentai
${prefix}18+
`;

        await sock.sendMessage(m.chat, {
            interactiveMessage: {
                title: "MARIN ALL FEATURES\n\n" + allMenuText,
                footer: "⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫 | ©NakunStore",
                image: {
                    url: "./Connection/foto/banner.jpeg"
                },
                nativeFlowMessage: {
                    messageParamsJson: JSON.stringify({
                        limited_time_offer: {
                            text: "𝐍𝐀𝐊𝐔𝐍 𝐗 𝐌𝐀𝐑𝐈𝐍",
                            url: "https://wa.me/6285726013874",
                            copy_code: "MARINV15",
                            expiration_time: Date.now() + (24 * 60 * 60 * 1000)
                        },
                        bottom_sheet: {
                            in_thread_buttons_limit: 2,
                            divider_indices: [1],
                            list_title: "CLICK",
                            button_title: "⿻ 𝐌𝐚𝐫𝐢𝐧"
                        },
                        tap_isTarget_configuration: {
                            title: " X ",
                            description: "Kembali",
                            canonical_url: "",
                            domain: "",
                            button_index: 0
                        }
                    }),
                    buttons: [{
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Kembali ke Menu",
                            id: `${prefix}menu`
                        })
                    }]
                }
            },
            contextInfo: {
                externalAdReply: {
                    title: "Marin • Status",
                    body: `🛒 ${global.totalPlugins || 13} items\n❐ nakun\n© MARIN V15`,
                    thumbnailUrl: "https://files.catbox.moe/473n1z.jpeg",
                    sourceUrl: "https://wa.me/6285726013874",
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: m });
    }
}
