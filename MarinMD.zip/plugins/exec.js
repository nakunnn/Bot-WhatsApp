// Plugin: exec.js
// Eksekusi perintah shell menggunakan child_process.exec

const terminal = require('./terminal');

module.exports = {
    command: 'exec',
    description: 'Execute shell command via exec',
    execute: async (sock, msg, args) => {
        await terminal.handleExec(sock, msg, args);
    }
};
