const axios = require('axios');

module.exports = {
    command: 'play',
    execute: async (sock, m, { q, reply }) => {
        if (!q) return reply("Masukkan judul lagu!\n\nContoh: .play Bertaut");
        
        try {
            const apiUrl = `https://api.vreden.my.id/api/v1/download/play/audio?query=${encodeURIComponent(q)}`;
            const { data } = await axios.get(apiUrl);
            
            if (!data.status) return reply("Lagu tidak ditemukan!");
            
            const meta = data.result.metadata;
            const dl = data.result.download;
            
            let caption = `乂 *MARIN PLAY*\n\n`;
            caption += `📌 *Judul:* ${meta.title}\n`;
            caption += `🎤 *Artis:* ${meta.author.name}\n`;
            caption += `⏱️ *Durasi:* ${meta.duration.timestamp}\n`;
            caption += `👀 *Views:* ${meta.views.toLocaleString()}\n`;
            caption += `📎 *Link:* ${meta.url}\n\n`;
            caption += `> 🎧 Audio sedang dikirim...`;
            
            await sock.sendMessage(m.chat, { image: { url: meta.thumbnail }, caption: caption }, { quoted: m });
            await sock.sendMessage(m.chat, { audio: { url: dl.url }, mimetype: 'audio/mpeg', fileName: dl.filename }, { quoted: m });
            
        } catch (err) {
            console.error(err);
            reply("❌ Terjadi kesalahan saat memutar lagu.");
        }
    }
};
