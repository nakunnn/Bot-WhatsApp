module.exports = {
    command: 'testi',
    description: 'Menampilkan link testimoni NakunStore',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const teks = `⌯⌲ *TESTI NAKUNSTORE*

~https://whatsapp.com/channel/0029VbC3DioDeONBPSW8hH3n~`;
        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
