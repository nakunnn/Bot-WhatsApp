'use strict';

/**
 * spotify.js — NakunBot
 * Metode  : Spotify oEmbed (gratis, tanpa API Key) + yt-dlp lokal (.m4a)
 * Support : Single Track & Playlist
 */

const fs         = require('fs');
const path       = require('path');
const https      = require('https');
const http       = require('http');
const { execFile } = require('child_process');
const { promisify } = require('util');

const execFileAsync = promisify(execFile);
const MEDIA_DIR     = path.join(__dirname, '..', 'media');
const YT_DLP_PATH   = path.join(__dirname, '..', 'yt-dlp'); // Path yt-dlp lokal
const MAX_PLAYLIST  = 10;

if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });

// ─── Hapus file sementara ───────────────────────────────────────
function safeDelete(filePath) {
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (_) {}
}

// ─── GET request sederhana, kembalikan string ───────────────────
function httpGet(url) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        client.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                return httpGet(res.headers.location).then(resolve).catch(reject);
            }
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
            res.on('error', reject);
        }).on('error', reject);
    });
}

// ─── Ambil metadata track via Spotify oEmbed (GRATIS, tanpa API) ─
async function getTrackMeta(trackUrl) {
    const oembedUrl = `https://open.spotify.com/oembed?url=${encodeURIComponent(trackUrl)}`;
    const raw = await httpGet(oembedUrl);
    const data = JSON.parse(raw);

    let artist = '';
    try {
        const html = await httpGet(trackUrl);
        const match = html.match(/<meta\s+name="description"\s+content="([^"]+)"/i)
                   || html.match(/<meta\s+property="og:description"\s+content="([^"]+)"/i);
        if (match) {
            const desc = match[1];
            const parts = desc.split(' · ');
            if (parts.length >= 2) artist = parts[1].trim();
        }
    } catch (_) {}

    return {
        title:     data.title || 'Unknown',
        artist:    artist     || 'Unknown',
        thumbnail: data.thumbnail_url || '',
    };
}

// ─── Ambil daftar track URL dari playlist via scrape HTML ────────
async function getPlaylistTracks(playlistUrl) {
    const tracks = [];
    try {
        const html = await httpGet(playlistUrl);
        const trackRegex = /https:\/\/open\.spotify\.com\/track\/[A-Za-z0-9]+/g;
        const found = [...new Set(html.match(trackRegex) || [])];
        tracks.push(...found);
    } catch (_) {}
    return tracks;
}

// ─── Download audio via yt-dlp lokal ─────────────────────────────
async function downloadAudioLocal(title, artist, outputTemplate) {
    const query = `${artist} ${title} audio`.trim();

    // Pastikan pakai yt-dlp yang kita download di folder helper
    const ytdlPath = fs.existsSync(YT_DLP_PATH) ? YT_DLP_PATH : 'yt-dlp';

    const args = [
        `ytsearch1:${query}`,
        '-f', 'bestaudio[ext=m4a]/bestaudio', // Tidak butuh ffmpeg
        '--output', outputTemplate,
        '--no-playlist',
        '--quiet',
        '--no-warnings',
        '--socket-timeout', '30',
        '--no-check-certificates'
    ];

    await execFileAsync(ytdlPath, args, { timeout: 120_000 });
}

// ─── Cari nama file sebenarnya (bisa .m4a atau .webm) ───────────
function findAudioFile(baseTemplate) {
    const baseName = baseTemplate.replace('.%(ext)s', '');
    const exts = ['.m4a', '.webm', '.opus', '.mp3'];
    for (const ext of exts) {
        if (fs.existsSync(baseName + ext)) return baseName + ext;
    }
    return null;
}

// ─── Proses & kirim satu track ───────────────────────────────────
async function processTrack(sock, from, msg, trackUrl) {
    let title = 'Unknown';
    let artist = 'Unknown';
    let thumbnail = '';
    try {
        const meta = await getTrackMeta(trackUrl);
        title     = meta.title;
        artist    = meta.artist;
        thumbnail = meta.thumbnail;
    } catch (_) {
        const id = trackUrl.split('/track/')[1]?.split('?')[0] || 'track';
        title = id;
    }

    const safeName = `${artist} - ${title}`.replace(/[\\/:*?"<>|]/g, '_').substring(0, 80);
    const outTemplate = path.join(MEDIA_DIR, `${safeName}_${Date.now()}.%(ext)s`);

    await sock.sendMessage(from, {
        text: `Mendownload: ${title} - ${artist}`
    }, { quoted: msg });

    // Download via yt-dlp
    await downloadAudioLocal(title, artist, outTemplate);

    const actualFile = findAudioFile(outTemplate);
    if (!actualFile) {
        throw new Error(`Gagal memproses file audio. Pastikan server memiliki akses internet yang baik.`);
    }

    // Kirim thumbnail jika ada
    if (thumbnail) {
        try {
            const imgBuf = await new Promise((resolve, reject) => {
                const client = thumbnail.startsWith('https') ? https : http;
                client.get(thumbnail, (res) => {
                    const chunks = [];
                    res.on('data', c => chunks.push(c));
                    res.on('end', () => resolve(Buffer.concat(chunks)));
                    res.on('error', reject);
                }).on('error', reject);
            });
            await sock.sendMessage(from, {
                image: imgBuf,
                caption: `${title}\n${artist}\n\n©NakunStore`
            }, { quoted: msg });
        } catch (_) {}
    }

    // Kirim audio
    await sock.sendMessage(from, {
        audio: fs.readFileSync(actualFile),
        mimetype: actualFile.endsWith('.m4a') ? 'audio/mp4' : 'audio/webm',
        fileName: path.basename(actualFile),
        ptt: false,
    }, { quoted: msg });

    safeDelete(actualFile);
}

// ─── Export Plugin ───────────────────────────────────────────────
module.exports = {
    command: 'spotify',
    description: 'Download lagu/playlist dari Spotify',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const url  = (args[0] || '').trim();

        if (!url || !url.includes('spotify.com')) {
            return sock.sendMessage(from, {
                text: `Kirim link Spotify yang valid.\n\nContoh:\n.spotify https://open.spotify.com/track/...\n.spotify https://open.spotify.com/playlist/...`
            }, { quoted: msg });
        }

        const cleanUrl = url.split('?')[0];

        try {
            if (cleanUrl.includes('/playlist/')) {
                await sock.sendMessage(from, { text: 'Playlist terdeteksi. Mengambil daftar lagu...' }, { quoted: msg });

                const tracks = await getPlaylistTracks(cleanUrl);

                if (!tracks.length) {
                    return sock.sendMessage(from, {
                        text: 'Tidak dapat membaca daftar lagu. Pastikan playlist bersifat publik.'
                    }, { quoted: msg });
                }

                const limit = Math.min(tracks.length, MAX_PLAYLIST);
                await sock.sendMessage(from, {
                    text: `Ditemukan ${tracks.length} lagu. Mendownload ${limit} lagu pertama...`
                }, { quoted: msg });

                let sukses = 0, gagal = 0;
                for (let i = 0; i < limit; i++) {
                    try {
                        await processTrack(sock, from, msg, tracks[i]);
                        sukses++;
                        if (i < limit - 1) await new Promise(r => setTimeout(r, 2000));
                    } catch (e) {
                        gagal++;
                        console.error(`[ERR] Spotify playlist track[${i}]: ${e.message}`);
                    }
                }

                return sock.sendMessage(from, {
                    text: `Selesai. Berhasil: ${sukses}, Gagal: ${gagal}`
                }, { quoted: msg });
            }

            await processTrack(sock, from, msg, cleanUrl);

        } catch (err) {
            console.error('[ERR] .spotify:', err.message);

            try {
                fs.readdirSync(MEDIA_DIR)
                  .filter(f => /\.(mp3|webm|m4a|opus)$/.test(f))
                  .forEach(f => {
                      const fp = path.join(MEDIA_DIR, f);
                      if (Date.now() - fs.statSync(fp).mtimeMs > 600_000) safeDelete(fp);
                  });
            } catch (_) {}

            return sock.sendMessage(from, {
                text: `Gagal: ${err.message}`
            }, { quoted: msg });
        }
    }
};
