const axios = require('axios');
const FormData = require('form-data');

module.exports = {
    command: 'tourl',
    execute: async (sock, m, { reply, react }) => {
        const from = m.key.remoteJid;

        const mediaTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'];

        // Cari media: di quote dulu, fallback ke pesan sendiri
        let mediaMsg = null;
        const quotedMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (quotedMsg) {
            for (const t of mediaTypes) {
                if (quotedMsg[t]) { mediaMsg = quotedMsg[t]; break; }
            }
        }
        if (!mediaMsg) {
            for (const t of mediaTypes) {
                if (m.message?.[t]) { mediaMsg = m.message[t]; break; }
            }
        }

        if (!mediaMsg) {
            return reply('❌ Reply/quote media (gambar/video/audio/file/stiker) yang ingin diubah jadi URL!\n\nCara: Reply media lalu ketik .tourl');
        }

        const mime = mediaMsg.mimetype || 'application/octet-stream';
        await react(from, '⏳');

        try {
            // sock.downloadMediaMessage (custom dari index.js) menerima objek mediaMsg langsung
            // dan menggunakan downloadContentFromMessage dari Baileys
            const buffer = await sock.downloadMediaMessage(mediaMsg);

            if (!buffer || buffer.length === 0) {
                await react(from, '❌');
                return reply('❌ Gagal mendownload media. Pastikan media masih tersedia.');
            }

            console.log(`[TOURL] Downloaded ${buffer.length} bytes, mime: ${mime}`);

            // Tentukan ekstensi dari mimetype
            const extMap = {
                'image/jpeg': 'jpg',
                'image/jpg': 'jpg',
                'image/png': 'png',
                'image/gif': 'gif',
                'image/webp': 'webp',
                'video/mp4': 'mp4',
                'video/3gpp': '3gp',
                'audio/mpeg': 'mp3',
                'audio/ogg; codecs=opus': 'ogg',
                'audio/ogg': 'ogg',
                'application/pdf': 'pdf',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
                'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
                'text/plain': 'txt',
            };

            const cleanMime = mime.split(';')[0].trim();
            const extension = extMap[cleanMime] || (mime.includes('/') ? cleanMime.split('/')[1] : 'bin');
            const filename = `marin_${Date.now()}.${extension}`;

            // Upload ke Catbox (anonymous upload = tidak kirim userhash)
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('fileToUpload', buffer, { filename, contentType: cleanMime });

            const response = await axios.post('https://catbox.moe/user/api.php', form, {
                headers: form.getHeaders(),
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
                timeout: 120000,
            });

            const resultUrl = (response.data || '').toString().trim();
            console.log(`[TOURL] Catbox response: ${resultUrl}`);

            if (resultUrl.startsWith('https://')) {
                await react(from, '✅');
                return reply(`✅ *Berhasil diunggah!*\n\n📎 *URL:* ${resultUrl}\n📂 *Tipe:* ${cleanMime}\n📦 *Ukuran:* ${(buffer.length / 1024).toFixed(1)} KB`);
            } else {
                throw new Error(`Catbox: ${resultUrl || 'Response tidak valid'}`);
            }

        } catch (err) {
            console.error('[TOURL] Error:', err.message);
            await react(from, '❌');
            return reply(`❌ *Gagal.*\n\n*Error:* ${err.message}`);
        }
    }
};
