module.exports = {
    command: 'pricepanel',
    description: 'Menampilkan daftar harga panel',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const teks = `*Harga Panel*
        
╭❰ HARGA PANEL ❱
│ ⟡ RAM 1GB : Rp 1.000
│ ⟡ RAM 2GB : Rp 2.000
│ ⟡ RAM 3GB : Rp 3.000
│ ⟡ RAM 4GB : Rp 4.000
│ ⟡ RAM 5GB : Rp 5.000
│ ⟡ RAM 6GB : Rp 6.000
│ ⟡ RAM 7GB : Rp 7.000
│ ⟡ RAM 8GB : Rp 8.000
│ ⟡ RAM 9GB : Rp 9.000
│ ⟡ RAM 10GB : Rp 10.000
│ ⟡ UNLIMITED : Rp 15.000
╰────────────❱

©NakunStore`;
        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
}
