module.exports = {
    command: 'public',
    execute: async (sock, m, { isOwner, reply, command }) => {
        if (!isOwner) return reply("Khusus Owner");
        sock.public = true;
        reply(`successfully changed to ${command}`);
    }
};
