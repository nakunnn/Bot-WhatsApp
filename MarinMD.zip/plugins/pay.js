const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');

// Base QRIS Statis Nakunn Store
const BASE_QRIS = '00020101021126610014COM.GO-JEK.WWW01189360091432020329020210G2020329020303UMI51440014ID.CO.QRIS.WWW0215ID10253744258390303UMI5204581653033605802ID5912Nakunn store6008MAGELANG61055651262070703A016304C5DB';

function crc16_ccitt_false(str) {
    let crc = 0xFFFF;
    for (let i = 0; i < str.length; i++) {
        crc ^= str.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            if ((crc & 0x8000) > 0) {
                crc = (crc << 1) ^ 0x1021;
            } else {
                crc = (crc << 1);
            }
        }
    }
    return (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
}

function generateDynamicQRIS(baseQris, amount) {
    const amountStr = amount.toString();
    const amountLength = amountStr.length.toString().padStart(2, '0');
    const tag54 = `54${amountLength}${amountStr}`;
    const modifiedQris = baseQris.replace('5802ID', tag54 + '5802ID');
    const qrisWithoutCRC = modifiedQris.slice(0, -4);
    const newCRC = crc16_ccitt_false(qrisWithoutCRC);
    return qrisWithoutCRC + newCRC;
}

function formatRupiah(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(amount);
}

async function buildQRImage(qrisString) {
    const framePath = path.join(__dirname, '../media/frame.png');

    const qrBuffer = await QRCode.toBuffer(qrisString, {
        margin: 2,
        scale: 8,
        color: { dark: '#000000', light: '#FFFFFF' }
    });

    if (fs.existsSync(framePath)) {
        try {
            const sharp = require('sharp');
            const frameMeta = await sharp(framePath).metadata();
            const frameW = frameMeta.width;
            const frameH = frameMeta.height;

            // Ukuran QR fixed sesuai area bingkai: 500x500px di posisi x=84, y=216
            const qrSize = 500;
            const qrResized = await sharp(qrBuffer)
                .resize(qrSize, qrSize, { fit: 'fill' })
                .toBuffer();

            const left = 84;
            const top = 216;

            const result = await sharp({
                create: {
                    width: frameW,
                    height: frameH,
                    channels: 4,
                    background: { r: 255, g: 255, b: 255, alpha: 1 }
                }
            })
                .composite([
                    { input: qrResized, top, left },
                    { input: framePath, top: 0, left: 0 }
                ])
                .png()
                .toBuffer();

            return result;
        } catch (err) {
            console.error('[WARN] Gagal apply bingkai, kirim QR polos:', err.message);
            return qrBuffer;
        }
    }

    return qrBuffer;
}

module.exports = {
    command: 'pay',
    description: 'Menampilkan QRIS pembayaran (statis atau dinamis dengan nominal)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;

        // Jika ada nominal → generate QRIS dinamis
        if (args && args.length > 0) {
            const rawInput = args[0].toLowerCase().replace(/[.,\s]/g, '').replace(/^rp/i, '');
            const amount = parseInt(rawInput);

            if (isNaN(amount) || amount <= 0) {
                return sock.sendMessage(from, {
                    text: `╭❰ ERROR ❱\n│ ⟡ Nominal tidak valid!\n│ ⟡ Contoh: .pay 10000\n╰────────────❱\n©NakunStore`
                }, { quoted: msg });
            }
            if (amount < 100) {
                return sock.sendMessage(from, {
                    text: `╭❰ ERROR ❱\n│ ⟡ Nominal minimal Rp 100\n╰────────────❱\n©NakunStore`
                }, { quoted: msg });
            }
            if (amount > 10000000) {
                return sock.sendMessage(from, {
                    text: `╭❰ ERROR ❱\n│ ⟡ Nominal maksimal Rp 10.000.000\n╰────────────❱\n©NakunStore`
                }, { quoted: msg });
            }

            const processingMsg = await sock.sendMessage(from, {
                text: `⏳ Memproses QRIS untuk ${formatRupiah(amount)}...`
            }, { quoted: msg });

            try {
                const dynamicQRIS = generateDynamicQRIS(BASE_QRIS, amount);
                const imageBuffer = await buildQRImage(dynamicQRIS);

                const caption = `╭❰ PAYMENT ❱
│ ⟡ Nominal : ${formatRupiah(amount)}
│ ⟡ Nama   : Nakun Store
│ ⟡ Kirim bukti TF ke admin
╰────────────❱

©NakunStore`;

                await sock.sendMessage(from, { image: imageBuffer, caption }, { quoted: msg });
                await sock.sendMessage(from, { delete: processingMsg.key });

            } catch (err) {
                console.error('[ERR] PAY QRIS:', err.message);
                await sock.sendMessage(from, { delete: processingMsg.key }).catch(() => { });
                await sock.sendMessage(from, {
                    text: `╭❰ ERROR ❱\n│ ⟡ Gagal generate QR Code\n│ ⟡ Coba lagi beberapa saat\n╰────────────❱\n©NakunStore`
                }, { quoted: msg });
            }

        } else {
            // Tanpa nominal → kirim QRIS statis dari file
            const pathImg = path.join(__dirname, '../media/qris.png');
            if (fs.existsSync(pathImg)) {
                await sock.sendMessage(from, {
                    image: fs.readFileSync(pathImg),
                    caption: `╭❰ PEMBAYARAN ❱\n│ ⟡ Scan QRIS di atas\n│ ⟡ Kirim bukti ke Admin\n│\n│ 💡 Tip: .pay <nominal>\n│ ⟡ Untuk QRIS sesuai nominal\n╰────────────❱\n©NakunStore`
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: `╭❰ PEMBAYARAN ❱\n│ ⟡ Gunakan: .pay <nominal>\n│ ⟡ Contoh : .pay 10000\n╰────────────❱\n©NakunStore`
                }, { quoted: msg });
            }
        }
    }
};
