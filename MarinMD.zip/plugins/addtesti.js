const { downloadMediaMessage } = require('@whiskeysockets/baileys');

// CONFIGURATION: Masukkan JID Saluran (Newsletter) Anda di sini
// Cara dapat JID Saluran: Bisa menggunakan command .cek atau lihat log saat bot menerima pesan dari saluran
const channelJid = "120363425454088709@newsletter";

module.exports = {
    command: 'addtesti',
    description: 'Kirim testimoni dengan foto ke saluran',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;

        // Deteksi apakah pesan adalah gambar atau mereply gambar
        const isQuotedImage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;
        const isImage = msg.message?.imageMessage;

        if (!isImage && !isQuotedImage) {
            return sock.sendMessage(from, { text: 'Mohon reply sebuah gambar atau kirim gambar dengan caption .addtesti' }, { quoted: msg });
        }

        if (args.length < 2) {
            return sock.sendMessage(from, {
                text: 'Format salah!\nFormat: .addtesti [Produk] [Harga]\nContoh: .addtesti BotJPM 10000'
            }, { quoted: msg });
        }

        const produk = args[0];
        let hargaRaw = args.slice(1).join(' ');

        // Format harga: jika user ketik 10000, otomatis jadi 10.000
        const harga = /^\d+$/.test(hargaRaw)
            ? hargaRaw.replace(/\B(?=(\d{3})+(?!\d))/g, ".")
            : hargaRaw;


        // React: sedang memproses
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        try {
            // Download Media
            const targetMsg = isQuotedImage ? { message: msg.message.extendedTextMessage.contextInfo.quotedMessage } : msg;
            const buffer = await downloadMediaMessage(
                targetMsg,
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );

            // Format Pesan
            const caption = `🛍️ Testimoni - NakunStore
            
📦 Produk: ${produk}
💵 Harga : ${harga}

❐ NakunBOT | © MARIN V15`;

            // Kirim ke Saluran
            await sock.sendMessage(channelJid, {
                image: buffer,
                caption: caption
            });

            // React: selesai
            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

        } catch (err) {
            console.error('[ERR] addtesti:', err);
            await sock.sendMessage(from, { text: 'Gagal mengirim testimoni. Pastikan bot adalah admin di saluran tersebut dan JID Saluran benar.' }, { quoted: msg });
        }
    }
};
