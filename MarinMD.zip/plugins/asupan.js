const fs = require('fs');

module.exports = {
    command: 'asupan',
    execute: async (sock, m, { isPremium, isOwner, reply }) => {
        if (!isPremium && !isOwner) return reply("*DASAR CABUL!!!* FITUR KHUSUS PREMIUM TAU:v");
        
        const captions = ["Asupan hari ini sayangg🥵💦", "mana tahan🥵", "pulen bgtt🥵💦", "enak banget🥰", "andai aku disitu😋", "tete padet😳", "jadi sagne💦"];
        const caption = captions[Math.floor(Math.random() * captions.length)];
        
        m.react("⏱️");
        reply("*Sebentar ya mas..😘*");
        
        try {
            const data = JSON.parse(fs.readFileSync("./Connection/database/anuu.json", "utf8"));
            const videoUrl = data.videos[Math.floor(Math.random() * data.videos.length)];
            
            const sentMsg = await sock.sendMessage(m.chat, { 
                video: { url: videoUrl }, 
                caption: caption,
                viewOnce: true 
            }, { quoted: m });
            
            await sock.sendMessage(m.chat, { text: caption }, { quoted: sentMsg });
        } catch (err) {
            console.error(err);
            reply("⚠️ Terjadi kesalahan saat ambil video.");
        }
    }
};
