module.exports = {
    command: 'price',
    description: 'Menampilkan menu harga (panel, file, top-up, sc)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const teks = `.send edit ⚜️ *NAKUNSTORE — FILE & UNCEK*

📍 *Order Hubungi :*
*Admin :* _085879673319_

*FFKIPAS 5K*

*WEB BUG WA: 15K*

*GAMEBOOSTER VIP : 5K*

*FF V7A : 3K*
🔥 *FILE & CHEAT FF*
🔰*[ BASIC TOOLS ]*
🛠️ *FF V7A* — 3.000
🛠️ *Panel Remote* — 10.000
🧹 *Penghapus File* — 5.000

🔰 *[ AIM & DRAG ]*
🎯 *Aimlock 70% - 89%* — _5k - 10k_
🎯 *Aimlock V1 - VVIP* — _10k - 20k_
🕹️ *Easy Drag V1 - 95%* — _5k - 20k_
🕹️ *Drag HS 70% - 83%* — _10k - 40k_
_full pricelist chat admin_

🔰 *[ COMBO STABILIZER ]*
⚡ *HS 75% + Stab* — _10.000_
⚡ *HS 83% + Stab* — _15.000_
⚡ *HS 85% + Stab* — _20.000_
⚡ *HS 90% + Stab* — _35.000_

✨ *KENAPA HARUS DI SINI?*
✅ *600+ Testimoni Terpercaya*
✅ *Proses Instant & Aman*
✅ *Support All Payment*

📍 *Order Hubungi :*
*Admin :* _085879673319_`;
        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
