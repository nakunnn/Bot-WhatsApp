module.exports = {
    command: ['kick', 'kik', 'dor', 'tagall', 'open', 'buka', 'close', 'tutup'],
    execute: async (sock, m, { q, command, isGroup, isOwner, isAdmins, participants, reply, quoted, pushname }) => {
        if (!isGroup) return reply("Fitur ini hanya dapat digunakan di dalam grup!");
        
        switch (command) {
            case 'kick':
            case 'kik':
            case 'dor':
                if (!isAdmins && !isOwner) return reply("Khusus Admin!");
                let target = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
                await sock.groupParticipantsUpdate(m.chat, [target], "remove");
                break;
                
            case 'tagall':
                if (!isAdmins && !isOwner) return reply("Khusus Admin!");
                let text = `${q || 'Tag All'}\n\n`;
                for (let mem of participants) {
                    text += `@${mem.id.split('@')[0]}\n`;
                }
                sock.sendMessage(m.chat, { text: text, mentions: participants.map(a => a.id) }, { quoted: m });
                break;
                
            case 'open':
            case 'buka':
                if (!isAdmins && !isOwner) return reply("Khusus Admin!");
                await sock.groupSettingUpdate(m.chat, "not_announcement");
                reply("Grup dibuka!");
                break;
                
            case 'close':
            case 'tutup':
                if (!isAdmins && !isOwner) return reply("Khusus Admin!");
                await sock.groupSettingUpdate(m.chat, "announcement");
                reply("Grup ditutup!");
                break;
        }
    }
};
