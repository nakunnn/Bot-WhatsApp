const axios = require('axios');

module.exports = {
    command: 'chatgpt',
    description: 'Chat dengan AI ChatGPT',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0].split(':')[0];

        const text = args.join(' ');
        if (!text) {
            return sock.sendMessage(from, { text: 'Masukkan pesan untuk ChatGPT!\nContoh: .chatgpt apa itu coding?' }, { quoted: msg });
        }

        try {
            const apiUrl = `https://api.nexray.eu.cc/ai/chatgpt?text=${encodeURIComponent(text)}`;
            const response = await axios.get(apiUrl, { timeout: 300000 });
            
            if (response.data && response.data.status && response.data.result) {
                const replyText = `╭❰ CHATGPT ❱
│ ⟡ Model : GPT-4
╰────────────❱
╭❰ INFO ❱
│ ⟡ User : @${senderNumber} 
╰────────────❱

${response.data.result}`;

                await sock.sendMessage(from, { text: replyText, mentions: [sender] }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: 'Gagal mendapatkan respons dari server AI.' }, { quoted: msg });
            }
        } catch (error) {
            console.error('[ERR] ChatGPT Fetch:', error.message);
            await sock.sendMessage(from, { text: 'Terjadi kesalahan saat menghubungi server AI.' }, { quoted: msg });
        }
    }
};
