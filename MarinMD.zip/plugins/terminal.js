// ============================================================
//  PLUGIN: terminal.js
//  Library : @whiskeysockets/baileys
//  Fitur   : Remote CLI Terminal, Screenshot Desktop,
//            System & PM2 Monitor (per-jam otomatis)
//
//  Perintah (wajib prefix .):
//    .exec <cmd>   - Jalankan perintah via child_process.exec
//    .spawn <cmd>  - Jalankan perintah via child_process.spawn
//    .ss           - Screenshot desktop (auto-delete 10 detik)
//    .status       - Laporan sistem + PM2 on-demand
//
//  Keamanan:
//    Hanya nomor ADMIN_NUMBER yang dapat menggunakan perintah.
//    Semua pesan dari nomor lain diabaikan tanpa respons.
//
//  Instalasi dependensi tambahan:
//    npm install screenshot-desktop pm2
//    sudo apt install -y scrot   (Linux - backend screenshot)
// ============================================================

'use strict';

const { exec, spawn } = require('child_process');
const fs              = require('fs');
const os              = require('os');
const path            = require('path');

// ---- Dependensi opsional (graceful jika tidak terinstall) ----
let screenshot = null;
try { screenshot = require('screenshot-desktop'); } catch (_) {}

let pm2 = null;
try { pm2 = require('pm2'); } catch (_) {}

// ============================================================
//  KONFIGURASI
// ============================================================

// Ganti dengan nomor WhatsApp kamu (format internasional, tanpa +)
const ADMIN_NUMBER = '6285xxxxxxxxx';    // <-- GANTI INI

const EXEC_TIMEOUT            = 30 * 1000;   // 30 detik
const MAX_OUTPUT_LENGTH       = 3800;         // max karakter output terminal
const SCREENSHOT_DELETE_DELAY = 10 * 1000;   // 10 detik sebelum file dihapus
const MONITOR_INTERVAL        = 60 * 60 * 1000; // 60 menit (laporan otomatis)

const SCREENSHOT_DIR = path.join(__dirname, '../temp_screenshots');
if (!fs.existsSync(SCREENSHOT_DIR)) fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });

// ============================================================
//  AUTH HELPER
// ============================================================

/**
 * Kembalikan true jika pengirim adalah admin.
 * JID format: 628xxx@s.whatsapp.net atau 628xxx@lid
 */
function isAdmin(msg) {
    const jid = msg.key.participant || msg.key.remoteJid || '';
    return jid.startsWith(ADMIN_NUMBER + '@') || jid === ADMIN_NUMBER;
}

// ============================================================
//  FORMAT HELPER
// ============================================================

function padR(str, len) {
    return String(str).padEnd(len);
}

function formatUptime(ms) {
    const totalSec = Math.floor(ms / 1000);
    const d = Math.floor(totalSec / 86400);
    const h = Math.floor((totalSec % 86400) / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    if (d > 0) return `${d}d ${h}h ${m}m`;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

function formatOutput(text) {
    if (!text || !text.trim()) return '(no output)';
    const t = text.trim();
    return t.length > MAX_OUTPUT_LENGTH
        ? t.substring(0, MAX_OUTPUT_LENGTH) + '\n\n... [OUTPUT TRUNCATED]'
        : t;
}

function nowWIB() {
    return new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
}

// ============================================================
//  TERMINAL EXECUTION
// ============================================================

function runExec(command) {
    return new Promise((resolve) => {
        exec(command, { timeout: EXEC_TIMEOUT, maxBuffer: 1024 * 1024 * 5 }, (err, stdout, stderr) => {
            resolve({
                stdout:   stdout   || '',
                stderr:   stderr   || '',
                exitCode: err ? (err.code || 1) : 0,
                timedOut: err ? (err.killed || false) : false,
            });
        });
    });
}

function runSpawn(command) {
    return new Promise((resolve) => {
        const child = spawn('bash', ['-c', command]);
        let output = '';
        let timedOut = false;

        const timer = setTimeout(() => {
            timedOut = true;
            child.kill('SIGTERM');
        }, EXEC_TIMEOUT);

        child.stdout.on('data', (d) => { output += d.toString(); });
        child.stderr.on('data', (d) => { output += d.toString(); });

        child.on('close', (code) => {
            clearTimeout(timer);
            resolve({ output, exitCode: code, timedOut });
        });

        child.on('error', (err) => {
            clearTimeout(timer);
            resolve({ output: `Error: ${err.message}`, exitCode: 1, timedOut: false });
        });
    });
}

// ============================================================
//  SCREENSHOT
// ============================================================

async function takeScreenshot() {
    if (!screenshot) {
        throw new Error('screenshot-desktop not installed. Run: npm install screenshot-desktop');
    }
    const filepath = path.join(SCREENSHOT_DIR, `ss_${Date.now()}.png`);
    const buffer = await screenshot({ format: 'png' });
    fs.writeFileSync(filepath, buffer);
    return filepath;
}

function scheduleDelete(filepath) {
    setTimeout(() => {
        fs.unlink(filepath, (err) => {
            if (!err) console.log(`[System] File deleted: ${path.basename(filepath)}`);
        });
    }, SCREENSHOT_DELETE_DELAY);
}

// ============================================================
//  PM2 MONITORING
// ============================================================

async function getPm2List() {
    try {
        const pm2api = require('../lib/pm2api');
        const list = await pm2api.listBots();
        return list.map((p) => ({
            name:     p.name,
            status:   p.pm2_env.status,
            memory:   (p.monit.memory / 1024 / 1024).toFixed(1),
            cpu:      p.monit.cpu,
            uptime:   p.pm2_env.pm_uptime
                        ? formatUptime(Date.now() - p.pm2_env.pm_uptime)
                        : 'N/A',
            restarts: p.pm2_env.restart_time,
        }));
    } catch (e) {
        return [];
    }
}

async function buildSystemReport() {
    const procs    = await getPm2List();
    const totalMem = (os.totalmem() / 1024 ** 3).toFixed(2);
    const freeMem  = (os.freemem()  / 1024 ** 3).toFixed(2);
    const usedMem  = ((os.totalmem() - os.freemem()) / 1024 ** 3).toFixed(2);
    const loadAvg  = os.loadavg().map((l) => l.toFixed(2)).join(' | ');
    const sysUp    = formatUptime(os.uptime() * 1000);
    const botUp    = formatUptime(process.uptime() * 1000);
    const botRam   = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);

    let r = '';
    r += `\`\`\`\n`;
    r += `=== SYSTEM REPORT ===\n`;
    r += `Time   : ${nowWIB()}\n`;
    r += `---------------------\n`;
    r += `Host   : ${os.hostname()}\n`;
    r += `OS     : ${os.platform()} ${os.arch()}\n`;
    r += `Uptime : ${sysUp}\n`;
    r += `Load   : ${loadAvg}\n`;
    r += `RAM    : ${usedMem} GB / ${totalMem} GB (free: ${freeMem} GB)\n`;
    r += `---------------------\n`;
    r += `Process: NakunBot\n`;
    r += `Memory : ${botRam} MB\n`;
    r += `BotUp  : ${botUp}\n`;

    if (procs.length > 0) {
        r += `=====================\n`;
        r += `PM2 Processes (${procs.length})\n`;
        r += `---------------------\n`;
        r += `${padR('NAME', 14)}${padR('RAM(MB)', 9)}${padR('CPU%', 6)}${padR('STATUS', 9)}UPTIME\n`;
        r += `${'-'.repeat(48)}\n`;
        for (const p of procs) {
            r += `${padR(p.name, 14)}${padR(p.memory, 9)}${padR(p.cpu, 6)}${padR(p.status, 9)}${p.uptime}\n`;
        }
    } else {
        r += `=====================\n`;
        r += `PM2  : No processes found.\n`;
    }

    r += `=====================\n`;
    r += `\`\`\``;
    return r;
}

// ============================================================
//  SEND HELPERS
// ============================================================

async function sendText(sock, jid, text, quotedMsg) {
    const opts = quotedMsg ? { quoted: quotedMsg } : {};
    await sock.sendMessage(jid, { text }, opts);
}

async function sendImage(sock, jid, filePath, caption, quotedMsg) {
    const opts = quotedMsg ? { quoted: quotedMsg } : {};
    await sock.sendMessage(jid, {
        image:    fs.readFileSync(filePath),
        caption:  caption || '',
        mimetype: 'image/png',
    }, opts);
}

// ============================================================
//  CORE: RUN COMMAND & SEND RESULT
// ============================================================

async function runAndSend(sock, jid, command, mode, quotedMsg) {
    console.log(`[System] Command received: ${command}`);

    // Jalankan perintah
    let result;
    if (mode === 'spawn') {
        result = await runSpawn(command);
        result.stdout = result.output;
    } else {
        result = await runExec(command);
    }

    const output    = result.stdout || result.stderr || result.output || '';
    const formatted = formatOutput(output);
    const status    = result.exitCode === 0 ? 'OK' : `FAIL (exit ${result.exitCode})`;
    const timeout   = (result.timedOut) ? '\nNote: Command timed out.' : '';

    // Format output monospaced
    const resultText =
        `\`\`\`\n` +
        `--- EXEC RESULT ---\n` +
        `Mode   : ${mode.toUpperCase()}\n` +
        `Status : ${status}${timeout}\n` +
        `Command: ${command}\n` +
        `-------------------\n` +
        `${formatted}\n` +
        `-------------------\n` +
        `\`\`\``;

    // 1. Kirim teks hasil terminal terlebih dahulu
    await sendText(sock, jid, resultText, quotedMsg);
    console.log('[System] Command executed.');

    // 2. Ambil dan kirim screenshot
    let ssPath = null;
    try {
        ssPath = await takeScreenshot();
    } catch (e) {
        console.log(`[System] Screenshot skipped: ${e.message}`);
    }

    if (ssPath) {
        await sendImage(sock, jid, ssPath, '[System] Screenshot captured.', quotedMsg);
        console.log('[System] Screenshot sent.');
        scheduleDelete(ssPath);
    }
}

// ============================================================
//  MONITORING OTOMATIS (setiap MONITOR_INTERVAL ms)
// ============================================================

let _monitorStarted = false;

function startAutoMonitor(sock, targetJid) {
    if (_monitorStarted) return;
    _monitorStarted = true;

    console.log(`[System] Auto-monitor started. Interval: ${MONITOR_INTERVAL / 60000} min. Target: ${targetJid}`);

    // Laporan pertama 10 detik setelah connect
    setTimeout(async () => {
        try {
            await sock.sendMessage(targetJid, { text: await buildSystemReport() });
            console.log('[System] Initial monitor report sent.');
        } catch (e) { console.error(`[System] Monitor error: ${e.message}`); }
    }, 10000);

    // Laporan rutin
    setInterval(async () => {
        try {
            if (global.sock) {
                await global.sock.sendMessage(targetJid, { text: await buildSystemReport() });
                console.log('[System] Scheduled monitor report sent.');
            }
        } catch (e) { console.error(`[System] Monitor error: ${e.message}`); }
    }, MONITOR_INTERVAL);
}

// ============================================================
//  EXPORT PLUGIN
// ============================================================

module.exports = {

    // ---- .exec (dipanggil dari plugins/exec.js) ----
    handleExec: async (sock, msg, args) => {
        const jid     = msg.key.remoteJid;
        const command = args.join(' ').trim();
        if (!command) {
            return sendText(sock, jid,
                '```\n[Error] Usage: .exec <command>\n```', msg);
        }
        await runAndSend(sock, jid, command, 'exec', msg);
    },

    // ---- .spawn (dipanggil dari plugins/spawn.js) ----
    handleSpawn: async (sock, msg, args) => {
        const jid     = msg.key.remoteJid;
        const command = args.join(' ').trim();
        if (!command) {
            return sendText(sock, jid,
                '```\n[Error] Usage: .spawn <command>\n```', msg);
        }
        await runAndSend(sock, jid, command, 'spawn', msg);
    },

    // ---- .ss (dipanggil dari plugins/ss.js) ----
    handleSS: async (sock, msg) => {
        const jid = msg.key.remoteJid;
        try {
            await sendText(sock, jid, '```\n[System] Capturing screenshot...\n```', msg);
            const fp = await takeScreenshot();
            await sendImage(sock, jid, fp, '[System] Screenshot sent.', msg);
            console.log('[System] Screenshot sent.');
            scheduleDelete(fp);
        } catch (e) {
            await sendText(sock, jid, `\`\`\`\n[Error] Screenshot failed: ${e.message}\n\`\`\``, msg);
        }
    },

    // ---- .status (dipanggil dari plugins/status.js) ----
    handleStatus: async (sock, msg) => {
        const jid = msg.key.remoteJid;
        await sendText(sock, jid, '```\n[System] Fetching system report...\n```', msg);
        await sendText(sock, jid, await buildSystemReport(), msg);
    },

    // ---- Auto-monitor (dipanggil saat bot connect) ----
    startAutoMonitor,
    buildSystemReport,
    isAdmin,
};
