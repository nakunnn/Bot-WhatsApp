// ============================================================
// Plugin: rvo.js
// Fungsi: Read View Once (RVO) - Baca & kirim ulang media
//         viewOnceMessageV2 (foto/video) sebagai pesan biasa.
// Kompatibel dengan: @whiskeysockets/baileys
// ============================================================

const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ─── KONSTANTA ───────────────────────────────────────────────
const RVO_TAG = '[RVO]';

/**
 * Deteksi apakah pesan adalah viewOnceMessageV2
 * @param {object} msg - Objek pesan Baileys
 * @returns {{ isViewOnce: boolean, innerMsg: object|null, mediaType: string|null }}
 */
function detectViewOnce(msg) {
    const message = msg?.message;
    if (!message) return { isViewOnce: false, innerMsg: null, mediaType: null };

    // Struktur utama: viewOnceMessageV2
    const viewOnceWrapper = message.viewOnceMessageV2;
    if (!viewOnceWrapper) return { isViewOnce: false, innerMsg: null, mediaType: null };

    const innerMsg = viewOnceWrapper.message;
    if (!innerMsg) return { isViewOnce: false, innerMsg: null, mediaType: null };

    // Deteksi tipe media di dalam wrapper
    if (innerMsg.imageMessage) {
        return { isViewOnce: true, innerMsg: innerMsg.imageMessage, mediaType: 'image' };
    }
    if (innerMsg.videoMessage) {
        return { isViewOnce: true, innerMsg: innerMsg.videoMessage, mediaType: 'video' };
    }

    return { isViewOnce: false, innerMsg: null, mediaType: null };
}

/**
 * Download buffer dari media viewOnce menggunakan downloadContentFromMessage
 * @param {object} innerMsg - imageMessage atau videoMessage
 * @param {'image'|'video'} mediaType - Tipe media
 * @returns {Promise<Buffer|null>} - Buffer media atau null jika gagal
 */
async function downloadViewOnceBuffer(innerMsg, mediaType) {
    try {
        const stream = await downloadContentFromMessage(innerMsg, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        if (chunks.length === 0) return null;
        return Buffer.concat(chunks);
    } catch (err) {
        console.error(`${RVO_TAG} Gagal download buffer: ${err.message}`);
        return null;
    }
}

/**
 * Handler utama RVO — dipanggil dari messages.upsert
 * Langkah:
 *   1. Deteksi viewOnceMessageV2
 *   2. Download buffer media
 *   3. Kirim ulang sebagai pesan biasa (quoted ke pesan asli)
 *
 * @param {object} sock - Instance Baileys socket
 * @param {object} msg  - Objek pesan dari messages.upsert
 * @returns {Promise<boolean>} - true jika berhasil di-RVO, false jika bukan viewOnce / gagal
 */
async function handleRVO(sock, msg) {
    // 1. Deteksi
    const { isViewOnce, innerMsg, mediaType } = detectViewOnce(msg);
    if (!isViewOnce) return false;

    const from = msg.key.remoteJid;
    const senderName = msg.pushName || msg.key.participant || from;
    console.log(`${RVO_TAG} ViewOnce terdeteksi dari ${senderName} (${mediaType})`);

    // 2. Download buffer
    const buffer = await downloadViewOnceBuffer(innerMsg, mediaType);
    if (!buffer) {
        console.error(`${RVO_TAG} Buffer kosong, skip RVO.`);
        // Kirim notif error agar tidak crash diam-diam
        await sock.sendMessage(from, {
            text: `╭❰ RVO GAGAL ❱\n│ ⟡ Tidak bisa membuka media.\n│ ⟡ Buffer kosong / media kedaluwarsa.\n╰────────────❱\n©NakunStore`
        }, { quoted: msg }).catch(() => {});
        return false;
    }

    // 3. Kirim ulang sebagai pesan biasa
    const caption = `╭❰ READ VIEW ONCE ❱\n│ ⟡ Dari  : ${senderName}\n│ ⟡ Tipe  : ${mediaType === 'image' ? '🖼️ Foto' : '🎬 Video'}\n│ ⟡ Info  : Media ini adalah ViewOnce\n╰────────────❱\n©NakunStore`;

    try {
        if (mediaType === 'image') {
            await sock.sendMessage(from, {
                image: buffer,
                caption,
                mimetype: innerMsg.mimetype || 'image/jpeg'
            }, { quoted: msg });
        } else if (mediaType === 'video') {
            await sock.sendMessage(from, {
                video: buffer,
                caption,
                mimetype: innerMsg.mimetype || 'video/mp4'
            }, { quoted: msg });
        }

        console.log(`${RVO_TAG} Berhasil kirim ulang media (${mediaType}) dari ${senderName}`);
        return true;
    } catch (err) {
        console.error(`${RVO_TAG} Gagal kirim ulang: ${err.message}`);
        return false;
    }
}

/**
 * Handler dot-command: .rvo
 * Cara pakai: Quote pesan viewOnce lalu ketik ".rvo"
 * Bot akan download & kirim ulang media tersebut sebagai pesan biasa.
 *
 * @param {object} sock - Instance Baileys socket
 * @param {object} msg  - Pesan yang mengandung .rvo
 * @param {string[]} args - Argumen (tidak dipakai)
 */
async function execute(sock, msg, args) {
    const from = msg.key.remoteJid;

    // Ambil konteks quoted message
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant
        || msg.message?.extendedTextMessage?.contextInfo?.remoteJid
        || from;

    if (!quoted) {
        return sock.sendMessage(from, {
            text: `╭❰ RVO ❱\n│ ⟡ Reply/quote pesan viewOnce dulu,\n│ ⟡ lalu ketik .rvo\n╰────────────❱\n©NakunStore`
        }, { quoted: msg });
    }

    // Bangun objek msg semu dari quoted untuk detectViewOnce
    const fakeMsg = { message: quoted };
    const { isViewOnce, innerMsg, mediaType } = detectViewOnce(fakeMsg);

    if (!isViewOnce) {
        return sock.sendMessage(from, {
            text: `╭❰ RVO ❱\n│ ⟡ Pesan yang di-quote bukan ViewOnce.\n│ ⟡ Pastikan kamu reply pesan viewOnce.\n╰────────────❱\n©NakunStore`
        }, { quoted: msg });
    }

    console.log(`[RVO] Command .rvo dari ${msg.pushName || from} (${mediaType})`);

    // Download buffer
    const buffer = await downloadViewOnceBuffer(innerMsg, mediaType);
    if (!buffer) {
        return sock.sendMessage(from, {
            text: `╭❰ RVO GAGAL ❱\n│ ⟡ Tidak bisa membuka media.\n│ ⟡ Buffer kosong / media sudah kedaluwarsa.\n╰────────────❱\n©NakunStore`
        }, { quoted: msg });
    }

    // Nama pengirim asli viewOnce
    const senderName = quotedParticipant.split('@')[0] || '?';
    const caption = `╭❰ READ VIEW ONCE ❱\n│ ⟡ Dari  : ${senderName}\n│ ⟡ Tipe  : ${mediaType === 'image' ? '🖼️ Foto' : '🎬 Video'}\n│ ⟡ Info  : Media ini adalah ViewOnce\n╰────────────❱\n©NakunStore`;

    if (mediaType === 'image') {
        await sock.sendMessage(from, {
            image: buffer,
            caption,
            mimetype: innerMsg.mimetype || 'image/jpeg'
        }, { quoted: msg });
    } else {
        await sock.sendMessage(from, {
            video: buffer,
            caption,
            mimetype: innerMsg.mimetype || 'video/mp4'
        }, { quoted: msg });
    }

    console.log(`[RVO] Berhasil kirim ulang (${mediaType}) dari ${senderName}`);
}

module.exports = {
    command: 'rvo',
    description: 'Buka & kirim ulang media ViewOnce. Cara: reply viewOnce lalu ketik .rvo',
    execute,
    handleRVO,
    detectViewOnce
};
