const axios = require('axios');
const moment = require('moment-timezone');

module.exports = {
    command: ['nokia'],
    description: 'Generate gambar mockup pesan Nokia jadul',
    execute: async (sock, msg, { args, reply, react }) => {
        const from = msg.key.remoteJid;

        if (args.length < 1) {
            return reply('❌ *Format salah!*\nFormat: `.nokia [text] [tanggal (optional)] [waktu (optional)]`\nContoh: `.nokia Halo Hari Ini 12/06/2026 18:30`');
        }

        // Tentukan default date & time dari zona waktu Jakarta
        const now = moment().tz('Asia/Jakarta');
        let date = now.format('DD/MM/YYYY');
        let time = now.format('HH:mm');
        let textParts = [...args];

        // Parsing waktu di argumen terakhir jika formatnya cocok (contoh: 18:30 atau 18.30)
        if (textParts.length > 0) {
            const lastArg = textParts[textParts.length - 1];
            if (/^\d{1,2}[:.]\d{2}$/.test(lastArg)) {
                time = lastArg.replace('.', ':');
                textParts.pop();
            }
        }

        // Parsing tanggal di argumen terakhir setelah waktu dipotong jika formatnya cocok (contoh: 12/06/2026 atau 12-06-2026)
        if (textParts.length > 0) {
            const lastArg = textParts[textParts.length - 1];
            if (/^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}$/.test(lastArg)) {
                date = lastArg.replace(/-/g, '/');
                textParts.pop();
            }
        }

        const text = textParts.join(' ');
        if (!text.trim()) {
            return reply('❌ Pesan Nokia tidak boleh kosong.');
        }

        // Form selalu isi: Nakun
        const senderName = 'Nakun';
        // Title selalu isi: MarinMD
        const contactTitle = 'MarinMD';

        await react(from, '⏳');

        try {
            const apiUrl = `https://apii.nexadev.my.id/nokia?text=${encodeURIComponent(text)}&from=${encodeURIComponent(senderName)}&date=${encodeURIComponent(date)}&time=${encodeURIComponent(time)}&title=${encodeURIComponent(contactTitle)}`;
            
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                timeout: 60000
            });

            const contentType = response.headers['content-type'] || '';
            const dataBuffer = Buffer.from(response.data);

            // Periksa jika respon adalah JSON error
            if (contentType.includes('application/json') || dataBuffer[0] === 123) { // 123 is ASCII for '{'
                await react(from, '❌');
                try {
                    const jsonError = JSON.parse(dataBuffer.toString('utf8'));
                    const errMsg = jsonError.message || jsonError.msg || 'Gagal memproses gambar pada API.';
                    return sock.sendMessage(from, { text: `❌ *Gagal:* ${errMsg}` }, { quoted: msg });
                } catch (pe) {
                    return sock.sendMessage(from, { text: `❌ *Gagal memproses gambar.*` }, { quoted: msg });
                }
            }

            // Kirim stiker hasil pemrosesan
            await sock.sendImageAsSticker(from, dataBuffer, msg, {
                packname: 'MarinMD',
                author: 'Nakun'
            });

            await react(from, '✅');

        } catch (error) {
            console.error('[NOKIA] Error:', error);
            await react(from, '❌');
            let errDetail = error.message;
            if (error.response?.data) {
                try {
                    const buf = Buffer.from(error.response.data);
                    const jsonErr = JSON.parse(buf.toString('utf8'));
                    errDetail = jsonErr.message || jsonErr.msg || errDetail;
                } catch (_) {}
            }
            await sock.sendMessage(from, { text: `❌ *Error:* ${errDetail}` }, { quoted: msg });
        }
    }
};
