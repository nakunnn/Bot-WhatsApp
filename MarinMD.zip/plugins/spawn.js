// Plugin: spawn.js
// Eksekusi perintah shell menggunakan spawn (streaming output)

const terminal = require('./terminal');

module.exports = {
    command: 'spawn',
    description: 'Eksekusi perintah terminal via spawn (streaming)',
    execute: async (sock, msg, args) => {
        await terminal.handleSpawn(sock, msg, args);
    }
};
