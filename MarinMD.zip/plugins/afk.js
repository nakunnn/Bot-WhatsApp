const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'afk',
    description: 'Mengaktifkan mode AFK (Away From Keyboard)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const afkFile = path.join(__dirname, '../afk.json');
        
        if (!fs.existsSync(afkFile)) {
            fs.writeFileSync(afkFile, JSON.stringify({}));
        }
        let afkData = JSON.parse(fs.readFileSync(afkFile));

        let reason = args.join(" ");
        
        if (!reason) {
            const petunjuk = `╭❰ AFK ❱\n│ ⟡ Silakan masukkan alasan AFK\n│ ⟡ Contoh: .afk tidur\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        afkData[sender] = {
            reason: reason,
            time: Date.now()
        };

        fs.writeFileSync(afkFile, JSON.stringify(afkData, null, 2));

        const teks = `╭❰ AFK SYSTEM ❱\n│ ⟡ Kamu sekarang AFK!\n│ ⟡ Alasan: ${reason}\n│ ⟡ Waktu: ${new Date().toLocaleTimeString('id-ID')}\n╰────────────❱\n©NakunStore`;
        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
