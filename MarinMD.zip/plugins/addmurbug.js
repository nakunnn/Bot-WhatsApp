const fs = require('fs');

module.exports = {
    command: 'addmurbug',
    execute: async (sock, m, { args, q, prefix, command, isOwner, reply }) => {
        if (!isOwner) return reply("Khusus Owner");
        if (!args[0]) return reply(`Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} 6285726013874`);
        
        let prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        let v352 = await sock.onWhatsApp(prrkek);
        if (v352.length == 0) return reply("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
        
        let premium = JSON.parse(fs.readFileSync("./Connection/database/premium.json"));
        premium.push(prrkek);
        fs.writeFileSync("./Connection/database/premium.json", JSON.stringify(premium));
        reply(`Nomor ${prrkek} Telah Menjadi Murbug`);
    }
};
