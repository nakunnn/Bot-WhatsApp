const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

module.exports = {
    command: 'brat',
    execute: async (sock, m, { q, prefix, command, reply, react }) => {
        if (!q) return reply(`*Cara Penggunaan* \n${prefix + command} Nakun`);
        
        const from = m.key.remoteJid || m.chat;
        await react(from, "⏳");

        try {
            const url = `https://api.nexadev.my.id/api/canvas/brat?text=${encodeURIComponent(q)}`;
            const response = await axios.get(url, {
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                timeout: 60000
            });
            
            const dataBuffer = Buffer.from(response.data);
            
            await sock.sendImageAsSticker(from, dataBuffer, m, {
                packname: 'MarinMD',
                author: 'Nakun'
            });
            
            await react(from, "✅");
        } catch (err) {
            console.error('[BRAT] Error:', err);
            await react(from, "❌");
            let errDetail = err.message;
            if (err.response?.data) {
                try {
                    const buf = Buffer.from(err.response.data);
                    const jsonErr = JSON.parse(buf.toString('utf8'));
                    errDetail = jsonErr.message || jsonErr.msg || errDetail;
                } catch (_) {}
            }
            await sock.sendMessage(from, { text: `❌ *Error:* ${errDetail}` }, { quoted: m });
        }
    }
};
