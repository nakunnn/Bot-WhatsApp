// Plugin: status.js
// Tampilkan laporan monitoring sistem + PM2 (live report)

const os = require('os');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

const pm2api = require('../lib/pm2api');

function formatUptime(ms) {
    const totalSec = Math.floor(ms / 1000);
    const d = Math.floor(totalSec / 86400);
    const h = Math.floor((totalSec % 86400) / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    if (d > 0) return `${d}d ${h}h ${m}m`;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

async function getPm2List() {
    try {
        const list = await pm2api.listBots();
        return list.map((p) => {
            const st = p.pm2_env.status;
            const emoji = st === 'online' ? '🟢' : st === 'stopped' ? '🔴' : '🟡';
            return {
                name:     p.name || 'unknown',
                status:   st,
                emoji:    emoji,
                memory:   (p.monit.memory / 1024 / 1024).toFixed(1),
                cpu:      p.monit.cpu,
                uptime:   p.pm2_env.pm_uptime
                            ? formatUptime(Date.now() - p.pm2_env.pm_uptime)
                            : 'N/A',
            };
        });
    } catch (e) {
        return [];
    }
}

module.exports = {
    command: 'status',
    description: 'Laporan monitoring sistem, RAM, CPU, dan proses PM2',
    execute: async (sock, msg, args) => {
        const jid = msg.key.remoteJid;
        await sock.sendMessage(jid, { text: '```\n[System] Fetching system report...\n```' }, { quoted: msg });

        // Build stats
        const totalRam = (os.totalmem() / 1024 ** 3).toFixed(1) + 'GB';
        const usedRam = ((os.totalmem() - os.freemem()) / 1024 ** 3).toFixed(1) + 'GB';
        const cpuCore = os.cpus().length;
        const load = os.loadavg()[0];
        const cpuUsage = Math.min(((load / cpuCore) * 100), 100).toFixed(1);
        const uptime = formatUptime(os.uptime() * 1000);

        let usedSwap = '0GB';
        let totalSwap = '0GB';
        try {
            const { stdout } = await execPromise('free -m');
            const lines = stdout.split('\n');
            const swapLine = lines.find(l => l.startsWith('Swap:'));
            if (swapLine) {
                const parts = swapLine.trim().split(/\s+/);
                totalSwap = (parseInt(parts[1]) / 1024).toFixed(1) + 'GB';
                usedSwap = (parseInt(parts[2]) / 1024).toFixed(1) + 'GB';
            }
        } catch(e) {}

        let usedDisk = '0GB';
        let totalDisk = '0GB';
        try {
            const { stdout } = await execPromise('df -h /');
            const lines = stdout.split('\n');
            if (lines.length > 1) {
                const parts = lines[1].trim().split(/\s+/).filter(Boolean);
                totalDisk = parts[1];
                usedDisk = parts[2];
            }
        } catch(e) {}

        let netSpeed = '0.00';
        let totalBandwidth = 'N/A';
        try {
            const { stdout } = await execPromise('vnstat --oneline');
            const parts = stdout.split(';');
            if (parts.length > 5) {
                totalBandwidth = parts[5].trim();
            }
        } catch(e) {}

        const pm2List = await getPm2List();

        let status = "```" + `
┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓
      *SYSTEM MONITOR*      
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛
----------------------------
RAM  : ${usedRam}/${totalRam}
SWAP : ${usedSwap}/${totalSwap}
DISK : ${usedDisk}/${totalDisk}
CPU  : ${cpuUsage}%
CORE : ${cpuCore} Core
TIME : ${uptime}

SPED : ${netSpeed} Mbps
BAND : ${totalBandwidth}
----------------------------

┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓
      *BOT LIST [PM2]*      
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛
${pm2List.length === 0 ? '----------------------------\nTidak ada bot aktif' : pm2List.map(bot => `----------------------------
${bot.emoji} ${bot.name} [${bot.status.toUpperCase()}]
CPU  : ${bot.cpu}%
RAM  : ${bot.memory} MB
TIME : ${bot.uptime}
`).join('')}----------------------------
` + "```";

        await sock.sendMessage(jid, { text: status }, { quoted: msg });
    }
};
