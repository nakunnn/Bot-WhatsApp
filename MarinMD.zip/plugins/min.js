const { saveRevenue } = require('../lib/gsheets');

module.exports = {
    command: 'min',
    description: 'Mengurangi data omzet jika ada kesalahan input (Google Sheets)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;

        if (args.length < 1) {
            const petunjuk = `╭❰ FORMAT SALAH ❱
│ ⟡ Cara pakai: .min [masuk] [owner] [reseller]
│ ⟡ Contoh kurangi masuk saja : .min 50000
│ ⟡ Contoh kurangi semua     : .min 50000 40000 10000
│ ⟡ Ketik angka saja tanpa titik
╰────────────❱
©NakunStore`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        const nominalMasuk   = Number(args[0]);
        const untungOwner    = args[1] ? Number(args[1]) : 0;
        const untungReseller = args[2] ? Number(args[2]) : 0;

        if (isNaN(nominalMasuk) || isNaN(untungOwner) || isNaN(untungReseller)) {
            return sock.sendMessage(from, {
                text: `╭❰ ERROR ❱\n│ ⟡ Nominal harus berupa angka\n╰────────────❱\n©NakunStore`
            }, { quoted: msg });
        }

        // Simpan sebagai nilai NEGATIF ke Google Sheets dengan kategori PENGURANGAN
        const berhasil = await saveRevenue({
            masuk: -Math.abs(nominalMasuk),
            untung_me: -Math.abs(untungOwner),
            untung_reseller: -Math.abs(untungReseller),
            keterangan: 'KOREKSI / PENGURANGAN',
            kategori: 'PENGURANGAN',
        });

        if (!berhasil) {
            return sock.sendMessage(from, {
                text: `╭❰ PERINGATAN ❱
│ ⟡ GAGAL tersimpan ke Google Sheets
│ ⟡ Cek koneksi internet / Spreadsheet ID
│ ⟡ Lihat log terminal untuk detail
╰────────────❱
©NakunStore`
            }, { quoted: msg });
        }

        const teksSukses = `╭❰ OMZET DIKURANGI ❱
│ ⟡ Minus Masuk    : Rp ${Math.abs(nominalMasuk).toLocaleString('id-ID')}
│ ⟡ Minus Owner    : Rp ${Math.abs(untungOwner).toLocaleString('id-ID')}
│ ⟡ Minus Reseller : Rp ${Math.abs(untungReseller).toLocaleString('id-ID')}
│
│ ✅ Koreksi tersimpan ke Google Sheets!
╰────────────❱
©NakunStore`;

        await sock.sendMessage(from, { text: teksSukses }, { quoted: msg });
    }
};
