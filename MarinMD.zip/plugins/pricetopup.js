module.exports = {
    command: 'pricetopup',
    description: 'Menampilkan daftar harga top-up game',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const teks = `*TOP UP ML, FF, PUBG, ROBLOX, HOK, VALORANT REGION INDO*

*HARGA DAPAT BERUBAH SEWAKTU-WAKTU*

[ ROBLOX ]
 ⟡ 1000 RBX — 100.000
 ⟡ 2000 RBX — 199.000
*harga robux 5 hari/via gp

[ FREE FIRE ]
 ⟡ 5 DM — 3.000
 ⟡ 10 DM — 4.000
 ⟡ 20 DM — 6.000
 ⟡ 30 DM — 8.000
 ⟡ 50 DM — 10.000
 ⟡ 70 DM — 12.000
 ⟡ 80 DM — 14.000
 ⟡ 90 DM — 17.000
 ⟡ 100 DM — 18.000
 ⟡ 120 DM — 19.000

[MOBILE LEGEND]
 ⟡ 20 DM — 7.000
 ⟡ 30 DM — 9.000
 ⟡ 40 DM — 13.000
 ⟡ 50 DM — 15.000
 ⟡ 60 DM — 17.000
 ⟡ 70 DM — 20.000
 ⟡ 80 DM — 22.000
 ⟡ 90 DM — 25.000
 ⟡ 100 DM — 27.000

[PUBG MOBILE]
 ⟡ 300+25 UC — 75.000
 ⟡ 360+25 UC — 95.000
 ⟡ 600+60 UC — 150.000
 ⟡ 660+60 UC — 169.000
 ⟡ 720+60 UC — 185.000
 ⟡ 780+60 UC — 105.000

[HOK]
 ⟡ 16 TOKENS — 4.000
 ⟡ 80 TOKENS — 15.000
 ⟡ 240 TOKENS — 45.000
 ⟡ 400 TOKENS — 74.000
 ⟡ 560 TOKENS — 100.000
 ⟡ 800+30 TOKENS — 145.000

[BLOODSTRIKE]
 ⟡ 100+5 GOLD — 13.000
 ⟡ 300+20 GOLD — 36.000
 ⟡ 500+40 GOLD — 60.000
 ⟡ 600+65 GOLD — 72.000
 ⟡ 800+60 GOLD — 100.000
 ⟡ 1000+100 GOLD — 120.000

[VALORANT]
 ⟡ 475 POINS — 50.000
 ⟡ 1000 POINS — 100.000
 ⟡ 1475 POINS — 150.000
 ⟡ 2050 POINS — 200.000
 ⟡ 2525 POINS — 245.000
 ⟡ 3050 POINS — 300.000

©NakunStore`;
        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
}
