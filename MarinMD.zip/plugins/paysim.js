const fs = require('fs');
const path = require('path');
const https = require('https');
const QRCode = require('qrcode');

// ─── KONFIGURASI PAKASIR ───────────────────────────────────────────────────────
const PAKASIR_API_KEY = process.env.PAKASIR;
const PAKASIR_SLUG = process.env.PAKASIR_SLUG;

// ─── PATH FRAME QRIS ──────────────────────────────────────────────────────────
const FRAME_PATH = path.join(__dirname, '..', 'media', 'frame.png');

// ─── HELPER: Format Rupiah ─────────────────────────────────────────────────────
function formatRupiah(angka) {
    return 'Rp ' + Number(angka).toLocaleString('id-ID');
}

// ─── HELPER: Buat transaksi QRIS ke Pakasir ───────────────────────────────────
function createPakasirTransaction(slug, amount, orderId, apiKey) {
    return new Promise((resolve) => {
        const payload = JSON.stringify({
            project: slug,
            order_id: orderId,
            amount: amount,
            api_key: apiKey
        });
        const options = {
            hostname: 'app.pakasir.com',
            path: '/api/transactioncreate/qris',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(payload)
            }
        };
        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => { data += chunk; });
            res.on('end', () => {
                try { resolve(JSON.parse(data)); }
                catch (e) { resolve(null); }
            });
        });
        req.on('error', () => resolve(null));
        req.write(payload);
        req.end();
    });
}

// ─── HELPER: Cek status transaksi Pakasir ─────────────────────────────────────
function fetchPakasirStatus(slug, amount, orderId, apiKey) {
    return new Promise((resolve) => {
        const url = `https://app.pakasir.com/api/transactiondetail?project=${slug}&amount=${amount}&order_id=${orderId}&api_key=${apiKey}`;
        https.get(url, (res) => {
            let data = '';
            res.on('data', (chunk) => { data += chunk; });
            res.on('end', () => {
                try { resolve(JSON.parse(data)); }
                catch (e) { resolve(null); }
            });
        }).on('error', () => resolve(null));
    });
}

// ─── HELPER: Build gambar QR + overlay frame.png ──────────────────────────────
async function buildQRImage(qrisString) {
    const qrBuffer = await QRCode.toBuffer(qrisString, {
        margin: 2,
        scale: 8,
        color: { dark: '#000000', light: '#FFFFFF' }
    });

    if (fs.existsSync(FRAME_PATH)) {
        try {
            const sharp = require('sharp');
            const frameMeta = await sharp(FRAME_PATH).metadata();
            const qrResized = await sharp(qrBuffer)
                .resize(500, 500, { fit: 'fill' })
                .toBuffer();
            return await sharp({
                create: {
                    width: frameMeta.width,
                    height: frameMeta.height,
                    channels: 4,
                    background: { r: 255, g: 255, b: 255, alpha: 1 }
                }
            }).composite([
                { input: qrResized, top: 216, left: 84 },
                { input: FRAME_PATH, top: 0, left: 0 }
            ]).png().toBuffer();
        } catch (e) {
            console.error('[PAYSIM] sharp error:', e.message);
            return qrBuffer;
        }
    }
    return qrBuffer;
}

// ─── HELPER: Hapus pesan ──────────────────────────────────────────────────────
async function deleteMessage(sock, from, sentMsg) {
    try {
        await sock.sendMessage(from, { delete: sentMsg.key });
    } catch (e) { /* abaikan jika gagal */ }
}

// ─── PLUGIN UTAMA ─────────────────────────────────────────────────────────────
module.exports = {
    command: 'paysim',
    description: 'Buat invoice QRIS via Pakasir | .paysim <nominal> [keterangan]',

    execute: async (sock, msg, { args, reply }) => {
        const from = msg.key.remoteJid;

        // ── Cek Konfigurasi .env ─────────────────────────────────────────────
        if (!PAKASIR_API_KEY || !PAKASIR_SLUG) {
            return reply(`  ◆ ERROR KONFIGURASI ◆
───────────────────────────
  API Pakasir belum dikonfigurasi!
  Harap isi PAKASIR & PAKASIR_SLUG di file .env.
───────────────────────────
  NakunStore`);
        }

        // ── Validasi argumen ─────────────────────────────────────────────────
        if (args.length < 1) {
            return reply(`  ◆ FORMAT SALAH ◆
───────────────────────────
  Cara pakai:
  .paysim <nominal>
  .paysim <nominal> <keterangan>

  Contoh:
  .paysim 50000
  .paysim 75000 Panel 2GB

  Nominal: angka saja (tanpa titik/koma)
───────────────────────────
  NakunStore`);
        }

        const nominal = parseInt(args[0].replace(/\D/g, ''));
        if (isNaN(nominal) || nominal < 1000) {
            return reply(`  ◆ ERROR ◆
───────────────────────────
  Nominal tidak valid.
  Minimal transaksi: Rp 1.000
───────────────────────────
  NakunStore`);
        }

        const keterangan = args.slice(1).join(' ') || '-';
        const orderId = `NS-${Date.now()}`;
        const rawPaymentUrl = `https://app.pakasir.com/pay/${PAKASIR_SLUG}/${nominal}?order_id=${orderId}&qris_only=1`;

        // ── Loading (React) ──────────────────────────────────────────────────
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } }).catch(() => { });

        try {
            // ── Buat transaksi ke Pakasir ────────────────────────────────────
            const result = await createPakasirTransaction(PAKASIR_SLUG, nominal, orderId, PAKASIR_API_KEY);
            const paymentUrl = rawPaymentUrl;

            // React sukses
            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } }).catch(() => { });

            // ── Teks invoice pending (format Premium TeleBOT) ────────────────
            const invoicePending =
                `  ◆ QRIS BILLING INVOICE ◆
───────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(nominal)}
  Metode   : QRIS PaymentGateway
  Status   : Menunggu Pembayaran
  Expired  : 60 Menit
───────────────────────────
  Link Pembayaran:
  ${paymentUrl}
───────────────────────────
  ❐ NakunBOT | © MARIN V15`;

            // ── Kirim invoice + QR image ─────────────────────────────────────
            let sentInvoice;

            if (result && result.payment && result.payment.payment_number) {
                let qrisString = result.payment.payment_number;
                if (qrisString.includes('000201')) {
                    qrisString = qrisString.substring(qrisString.indexOf('000201'));
                }
                const qrBuffer = await buildQRImage(qrisString);
                sentInvoice = await sock.sendMessage(from, {
                    image: qrBuffer,
                    caption: invoicePending,
                    mimetype: 'image/png'
                }, { quoted: msg });
            } else {
                // Fallback: frame.png biasa + teks invoice
                console.warn('[PAYSIM] Pakasir tidak return QR string, fallback ke frame.png');
                if (fs.existsSync(FRAME_PATH)) {
                    sentInvoice = await sock.sendMessage(from, {
                        image: fs.readFileSync(FRAME_PATH),
                        caption: invoicePending,
                        mimetype: 'image/png'
                    }, { quoted: msg });
                } else {
                    sentInvoice = await sock.sendMessage(from, {
                        text: invoicePending
                    }, { quoted: msg });
                }
            }

            // ── Auto-polling (setiap 7 detik, max 1 jam) ─────────────────────
            let elapsed = 0;
            const POLL_INTERVAL = 7000;
            const MAX_WAIT = 60 * 60 * 1000;

            const pollingInterval = setInterval(async () => {
                elapsed += POLL_INTERVAL;

                // ── Expired ──────────────────────────────────────────────────
                if (elapsed >= MAX_WAIT) {
                    clearInterval(pollingInterval);
                    if (sentInvoice) await deleteMessage(sock, from, sentInvoice);
                    await sock.sendMessage(from, {
                        text:
                            `  ◆ QRIS BILLING INVOICE ◆
───────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(nominal)}
  Metode   : QRIS PaymentGateway
  Status   : EXPIRED
───────────────────────────
  ❐ NakunBOT | © MARIN V15`
                    }).catch(() => { });
                    return;
                }

                // ── Cek status pembayaran ────────────────────────────────────
                const checkResult = await fetchPakasirStatus(PAKASIR_SLUG, nominal, orderId, PAKASIR_API_KEY);
                if (checkResult && checkResult.transaction && checkResult.transaction.status === 'completed') {
                    clearInterval(pollingInterval);

                    // Hapus pesan invoice QR
                    if (sentInvoice) await deleteMessage(sock, from, sentInvoice);

                    // Kirim invoice sukses (format TeleBOT)
                    const timeString = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
                    await sock.sendMessage(from, {
                        text:
                            `  ◆ DEPOSIT BERHASIL ◆
───────────────────────────
  RESI / INVOICE DEPOSIT
───────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(nominal)}
  Metode   : QRIS PaymentGateway
  Waktu    : ${timeString} WIB
  Status   : *Completed*
───────────────────────────
  ❐ NakunBOT | © MARIN V15`
                    }).catch(() => { });
                }
            }, POLL_INTERVAL);

        } catch (err) {
            console.error('[PAYSIM] Error:', err.message);
            await sock.sendMessage(from, { react: { text: '❌', key: msg.key } }).catch(() => { });
            await sock.sendMessage(from, {
                text: `[ ! ] Terjadi kesalahan saat membuat invoice.\n${err.message}`
            }, { quoted: msg });
        }
    }
};
