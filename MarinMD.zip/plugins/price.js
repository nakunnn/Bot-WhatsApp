module.exports = {
    command: 'price',
    description: 'Menampilkan menu harga (panel, file, top-up, sc)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const teks = `╭❰ PRICE MENU ❱
│ ⟡ .pricepanel
│ ⟡ .pricefile
│ ⟡ .pricetopup
│ ⟡ .pricesc
╰────────────❱
©NakunStore`;
        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
