const axios = require('axios');

module.exports = {
    command: 'iqc',
    execute: async (sock, m, { args, reply, react }) => {
        if (!args.length) return reply("⚠️ Harap masukkan teks terlebih dahulu!\nContoh: .iqc Halo Dunia");
        
        const text = args.join(" ");
        const from = m.key.remoteJid || m.chat;

        await react(from, "⏳");

        try {
            const apiUrl = `https://api.nexadev.my.id/api/canvas/iqc?text=${encodeURIComponent(text)}`;
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                timeout: 60000
            });

            const dataBuffer = Buffer.from(response.data);

            await sock.sendImageAsSticker(from, dataBuffer, m, {
                packname: 'MarinMD',
                author: 'Nakun'
            });

            await react(from, "✅");
        } catch (error) {
            console.error('[IQC] Error:', error);
            await react(from, "❌");
            let errDetail = error.message;
            if (error.response?.data) {
                try {
                    const buf = Buffer.from(error.response.data);
                    const jsonErr = JSON.parse(buf.toString('utf8'));
                    errDetail = jsonErr.message || jsonErr.msg || errDetail;
                } catch (_) {}
            }
            await sock.sendMessage(from, { text: `❌ *Error:* ${errDetail}` }, { quoted: m });
        }
    }
};
