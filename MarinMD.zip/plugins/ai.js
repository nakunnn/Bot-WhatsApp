const axios = require('axios');

module.exports = {
    command: ['dread', 'p', 'Nakun', 'marin'],
    execute: async (sock, m, { q, reply }) => {
        if (!q) return reply("Apaan Anj?");

        try {
            const response = await axios.post("https://chateverywhere.app/api/chat/", {
                model: {
                    id: "gpt-4",
                    name: "GPT-4",
                    maxLength: 32000,
                    tokenLimit: 8000,
                    completionTokenLimit: 5000,
                    deploymentName: "gpt-4"
                },
                messages: [{
                    pluginId: null,
                    content: q,
                    role: "user"
                }],
                prompt: "Nama kamu adalah Marin Kitagawa, biasa dipanggil Marin. Kepribadianmu lembut, ramah, dan selalu menjawab dengan singkat. Kamu adalah istrinya Nakun. Hobimu adalah ngoding tapi sering error. Jawablah setiap interaksi dengan lembut dan ramah namun tetap singkat (to the point).",
                temperature: 0.5
            }, {
                headers: {
                    "Accept": "*/*",
                    "User-Agent": "Mozilla/5.0"
                }
            });

            reply(response.data);
        } catch (err) {
            console.error(err);
            reply("❌ Marin lagi pusing, coba lagi nanti ya!");
        }
    }
};
