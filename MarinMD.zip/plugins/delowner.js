const fs = require('fs');

module.exports = {
    command: 'delowner',
    execute: async (sock, m, { args, q, prefix, command, isOwner, reply }) => {
        if (!isOwner) return reply("Fitur ini hanya dapat di akses oleh owner bot");
        if (!args[0]) return reply(`_*Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} 62xxxxxxxxx`);
        
        let ya = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        let owner = JSON.parse(fs.readFileSync("./Connection/database/owner.json"));
        let unp = owner.indexOf(ya);
        if (unp === -1) return reply("Nomor tersebut tidak terdaftar sebagai owner.");
        
        owner.splice(unp, 1);
        fs.writeFileSync("./Connection/database/owner.json", JSON.stringify(owner));
        reply(`*Nomor ${ya} Telah Di Hapus dari Owner!*`);
    }
};
