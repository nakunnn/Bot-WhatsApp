const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'formatpanel',
    description: 'Menambahkan atau memperbarui data login panel',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;

        if (args.length < 2) {
            const petunjuk = `╭❰ FORMAT SALAH ❱\n│ ⟡ Gunakan: .formatpanel [username] [password]\n╰────────────❱\n©NakunStore`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        const username = args[0];
        const password = args.slice(1).join(" ");
        
        const dbDir = path.join(__dirname, '../database');
        const dbFile = path.join(dbDir, 'data_panel.json');

        if (!fs.existsSync(dbDir)) {
            fs.mkdirSync(dbDir, { recursive: true });
        }

        let dataPanel = [];
        if (fs.existsSync(dbFile)) {
            try {
                dataPanel = JSON.parse(fs.readFileSync(dbFile, 'utf8'));
            } catch (e) {
                dataPanel = [];
            }
        }

        const dateNow = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
        
        const index = dataPanel.findIndex(p => p.username.toLowerCase() === username.toLowerCase());
        
        if (index !== -1) {
            dataPanel[index].password = password;
            dataPanel[index].tanggal = dateNow;
        } else {
            dataPanel.push({
                username: username,
                password: password,
                tanggal: dateNow,
                status: 'ON'
            });
        }

        fs.writeFileSync(dbFile, JSON.stringify(dataPanel, null, 2), 'utf8');

        const teks = `╭❰ FORMAT LOGIN PANEL ❱
│ ⟡ Username: ${username}
│ ⟡ Password: ${password}
│ ⟡ Link: panel.nexoracloud.web.id
│ ⟡ Info: Pastikan panel kuat!
│ ⟡ Status: Terima kasih sudah order!
╰────────────❱
©NakunStore`;

        await sock.sendMessage(from, { text: teks }, { quoted: msg });
    }
};
