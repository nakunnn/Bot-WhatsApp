// Plugin: ss.js
// Ambil screenshot desktop dan kirim ke chat, auto-delete setelah 10 detik

const terminal = require('./terminal');

module.exports = {
    command: 'ss',
    description: 'Ambil screenshot desktop (auto-delete 10 detik)',
    execute: async (sock, msg, args) => {
        await terminal.handleSS(sock, msg);
    }
};
