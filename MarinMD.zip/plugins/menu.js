const fs = require('fs');

module.exports = {
    command: 'menu',
    execute: async (sock, m, { pushname, runtime, performance, args, react, prefix }) => {
        await react(m.chat, "📜");

        const subMenu = args[0]?.toLowerCase();
        let menuTitle = "MARIN DASHBOARD";
        let menuBody = "";
        let menuImage = "./Connection/foto/banner.jpeg";

        const adContext = {
            externalAdReply: {
                title: "Marin • Status",
                body: `🛒 ${global.totalPlugins || 13} items\n❐ nakun\n© MARIN V15`,
                thumbnailUrl: "https://files.catbox.moe/473n1z.jpeg",
                sourceUrl: "https://wa.me/6285726013874",
                mediaType: 1,
                renderLargerThumbnail: false
            }
        };

        if (!subMenu) {
            menuBody = `\`ⓘ こんにちは、マリンです。お手伝いできるボットです。⚠︎\`

Halo *${pushname}*! 👋
Selamat datang di pusat kontrol *Marin V15*.

Silakan pilih kategori menu di bawah ini untuk melihat daftar fitur yang tersedia.`;

            return sock.sendMessage(m.chat, {
                interactiveMessage: {
                    title: menuTitle + "\n\n" + menuBody,
                    footer: "⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫 | ©NakunStore",
                    image: { url: menuImage },
                    nativeFlowMessage: {
                        messageParamsJson: JSON.stringify({
                            limited_time_offer: {
                                text: "𝐍𝐀𝐊𝐔𝐍 𝐗 𝐌𝐀𝐑𝐈𝐍",
                                url: "https://wa.me/6285726013874",
                                copy_code: "MARINV15",
                                expiration_time: Date.now() + (24 * 60 * 60 * 1000)
                            },
                            bottom_sheet: {
                                in_thread_buttons_limit: 2,
                                divider_indices: [1, 2, 3, 4, 5, 999],
                                list_title: "PILIH KATEGORI",
                                button_title: "⿻ 𝐌𝐚𝐫𝐢𝐧"
                            },
                            tap_isTarget_configuration: {
                                title: " X ",
                                description: "Pilih Menu",
                                canonical_url: "",
                                domain: "",
                                button_index: 0
                            }
                        }),
                        buttons: [{
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "Daftar Menu",
                                sections: [
                                    {
                                        title: "STORE & PAYMENT",
                                        highlight_label: "⿻ 𝐌𝐚𝐫𝐢𝐧",
                                        rows: [
                                            { title: "Store Menu", description: "Layanan jual beli & payment", id: `${prefix}menu store` },
                                            { title: "Panel Menu", description: "Layanan pembuatan panel pterodactyl", id: `${prefix}menu panel` }
                                        ]
                                    },
                                    {
                                        title: "TOOLS & UTILITY",
                                        highlight_label: "⿻ 𝐌𝐚𝐫𝐢𝐧",
                                        rows: [
                                            { title: "AI Menu", description: "ChatGPT, Claude, Gemini, dll", id: `${prefix}menu ai` },
                                            { title: "Tools Menu", description: "Downloader, Stalking, & Utility", id: `${prefix}menu tools` }
                                        ]
                                    },
                                    {
                                        title: "ENTERTAINMENT",
                                        highlight_label: "⿻ 𝐌𝐚𝐫𝐢𝐧",
                                        rows: [
                                            { title: "Games Menu", description: "Asah otak & tebak-tebakan", id: `${prefix}menu games` },
                                            { title: "Fun Menu", description: "Fitur seru & lucu", id: `${prefix}menu fun` }
                                        ]
                                    },
                                    {
                                        title: "JADIBOT & SUBBOT",
                                        highlight_label: "⿻ 𝐌𝐚𝐫𝐢𝐧",
                                        rows: [
                                            { title: "Jadibot Menu", description: "Fitur multi-device & PM2 Manager", id: `${prefix}menu jadibot` }
                                        ]
                                    },
                                    {
                                        title: "SYSTEM & BUGS",
                                        highlight_label: "⿻ 𝐌𝐚𝐫𝐢𝐧",
                                        rows: [
                                            { title: "Bug Menu", description: "Fitur bug, crash, & payload", id: `${prefix}bugmenu` },
                                            { title: "Server Menu", description: "Status bot & sistem terminal", id: `${prefix}menu server` },
                                            { title: "All Features", description: "Tampilkan semua menu sekaligus", id: `${prefix}allmenu` }
                                        ]
                                    }
                                ]
                            })
                        }]
                    }
                },
                contextInfo: adContext
            }, { quoted: m });
        } else {
            menuTitle = `KATEGORI: ${subMenu.toUpperCase()}`;
            menuImage = "./Connection/foto/banner1.jpeg";

            switch (subMenu) {
                case 'offer':
                    menuTitle = "🔥 LIMITED OFFER 🔥";
                    menuImage = "./Connection/foto/banner.jpeg";
                    menuBody = `╭❰ 𝐍𝐀𝐊𝐔𝐍 𝐗 𝐌𝐀𝐑𝐈𝐍 ❱
│ 
│ Gabungan kekuatan antara 
│ **Nakun** (Developer) & **Marin** (AI).
│ 
│ 🌟 **PENAWARAN TERBATAS**:
│ - Script Bot Marin V15: **Chat Owner**
│ - Sewa Bot (All Feature): **Rp 10k/Bln**
│ - Akses Premium Bug: **Rp 5k/Minggu**
│ 
│ 💳 **Payment**: QRIS, Dana, Gopay, OVO
│ 
│ Hubungi Nakun untuk mendapatkan 
│ penawaran menarik lainnya!
│ 
╰────────────❱`;
                    break;
                case 'store':
                    menuBody = `Berikut adalah fitur untuk **STORE**:
- ${prefix}pay (Pembayaran)
- ${prefix}qris (Generate QRIS)
- ${prefix}testi (Cek Testimoni)
- ${prefix}unce (Kirim Akun Email)
- ${prefix}buyer (Data Buyer)
- ${prefix}price (Cek Harga)`;
                    break;
                case 'panel':
                    menuBody = `Berikut adalah fitur untuk **PANEL**:
- ${prefix}1gb s/d ${prefix}unli (Create Server)
- ${prefix}cadmin (Create Admin)
- ${prefix}listpanel (Cek Stok)`;
                    break;
                case 'tools':
                    menuBody = `Berikut adalah fitur untuk **TOOLS**:
- ${prefix}stiker (Buat Stiker)
- ${prefix}hd (HD Image Enhancer)
- ${prefix}nobg (Remove Background)
- ${prefix}img2pixel (Image Pixelate)
- ${prefix}nglspam (NGL Spammer)
- ${prefix}wmp1 (WMP Style 1 Maker)
- ${prefix}wmp2 (WMP Style 2 Maker)
- ${prefix}nokia (Nokia Mockup Maker)
- ${prefix}patrick (Brat Patrick Star)
- ${prefix}tiktok (Download TikTok)
- ${prefix}aio (AIO Downloader)
- ${prefix}play (Musik YouTube)
- ${prefix}tourl (Upload File)
- ${prefix}up (Upload 3 Jam)
- ${prefix}trackip (Cek IP)
- ${prefix}antibadword (Anti Kata Kasar)`;
                    break;
                case 'ai':
                    menuBody = `Berikut adalah fitur untuk **AI**:
- ${prefix}dread (Marin AI)
- ${prefix}lintar (Marin Toxic)
- ${prefix}chatgpt (GPT-4)
- ${prefix}claude (Claude 3)
- ${prefix}gemini (Google AI)`;
                    break;
                case 'games':
                    menuBody = `Berikut adalah fitur untuk **GAMES**:
- ${prefix}asahotak
- ${prefix}susunkata
- ${prefix}tebaktebakan
- ${prefix}tekateki`;
                    break;
                case 'jadibot':
                    menuBody = `Berikut adalah fitur untuk **JADIBOT**:
- ${prefix}jadibot [nomor] [ram]
- ${prefix}listbot (Cek Status)
- ${prefix}stop [nama] (Matikan)
- ${prefix}start [nama] (Nyalakan)
- ${prefix}restart [nama] (Reboot)
- ${prefix}hapus [nama] (Hapus Bot)
- ${prefix}batas [nama] [ram] (Ubah Limit)`;
                    break;
                default:
                    menuBody = `Kategori *${subMenu}* belum tersedia atau salah ketik.`;
            }

            return sock.sendMessage(m.chat, {
                interactiveMessage: {
                    title: menuTitle + "\n\n" + menuBody,
                    footer: "⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫 | ©NakunStore",
                    image: { url: menuImage },
                    nativeFlowMessage: {
                        messageParamsJson: JSON.stringify({
                            bottom_sheet: {
                                in_thread_buttons_limit: 2,
                                divider_indices: [1],
                                list_title: "CLICK",
                                button_title: "⿻ 𝐌𝐚𝐫𝐢𝐧"
                            },
                            tap_isTarget_configuration: {
                                title: " X ",
                                description: "Kembali",
                                canonical_url: "",
                                domain: "",
                                button_index: 0
                            }
                        }),
                        buttons: [{
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "Kembali ke Menu",
                                id: `${prefix}menu`
                            })
                        }]
                    }
                },
                contextInfo: adContext
            }, { quoted: m });
        }
    }
};
