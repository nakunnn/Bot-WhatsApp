const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');
const pm2api = require('../lib/pm2api');

module.exports = {
    command: 'jadibot',
    description: 'Membuat subbot baru dari send.zip menggunakan PM2',
    execute: async (sock, msg, { args, react }) => {
        const from = msg.key.remoteJid;

        // Cek argument [nomor] dan [nominal]
        if (args.length < 2) {
            return sock.sendMessage(from, { text: 'Format salah! Gunakan: .jadibot [nomor] [nominal]\nContoh: .jadibot 628123456789 500' }, { quoted: msg });
        }

        const nomor = args[0].replace(/[^0-9]/g, '');
        const nominal = parseInt(args[1]);

        if (!nomor || isNaN(nominal)) {
            return sock.sendMessage(from, { text: 'Nomor harus angka dan nominal harus angka (MB).' }, { quoted: msg });
        }

        try {
            await react(from, '⏳');

            const subbotDir = path.join(__dirname, '../subbot');
            const zipPath = path.join(subbotDir, 'send.zip');

            // Tentukan nama sX
            const subbots = await pm2api.listBots();
            let maxId = 0;
            for (const bot of subbots) {
                const num = parseInt(bot.name.replace('s', ''));
                if (!isNaN(num) && num > maxId) maxId = num;
            }
            const pm2Name = `s${maxId + 1}`;
            const targetPath = path.join(subbotDir, pm2Name);

            // 1. Cek ketersediaan send.zip
            if (!fs.existsSync(zipPath)) {
                return sock.sendMessage(from, { text: 'File send.zip tidak ditemukan di folder subbot!' }, { quoted: msg });
            }

            // 2. Cek apakah folder subbot sudah ada
            if (fs.existsSync(targetPath)) {
                return sock.sendMessage(from, { text: `Folder ${pm2Name} sudah ada! Hapus dulu dengan .hapus ${pm2Name}` }, { quoted: msg });
            }

            // 3. Ekstrak send.zip
            const zip = new AdmZip(zipPath);
            zip.extractAllTo(targetPath, true);

            // 4. Modifikasi index.js agar tidak prompt dan menggunakan environment variable BOT_NUMBER
            // Karena send.zip berisi folder 'send', path kerjanya ada di dalam targetPath/send
            const actualBotDir = path.join(targetPath, 'send');
            const indexPath = path.join(actualBotDir, 'index.js');
            if (fs.existsSync(indexPath)) {
                let indexCode = fs.readFileSync(indexPath, 'utf8');
                // Ganti prompt input manual dengan mengambil dari ENV, jika tidak ada baru prompt
                indexCode = indexCode.replace(/phoneNumber\s*=\s*await\s*question\('> '\);/g, "phoneNumber = process.env.BOT_NUMBER || await question('> ');");
                fs.writeFileSync(indexPath, indexCode);
            } else {
                return sock.sendMessage(from, { text: '⚠️ Gagal mengekstrak: index.js tidak ditemukan di dalam send.zip!' }, { quoted: msg });
            }

            // 5. Jalankan bot di dalam folder tersebut menggunakan PM2
            await pm2api.startBot(pm2Name, 'index.js', actualBotDir, nominal, { BOT_NUMBER: nomor });

            // 6. Dengarkan output PM2 untuk mendapatkan pairing code
            const pairingCode = await pm2api.listenForPairingCode(pm2Name, 45000); // Tunggu max 45 detik

            if (pairingCode) {
                const teks = `═════════════════════
Name : ${pm2Name}
Nomor : ${nomor}
Code : ${pairingCode}
Ram : ${nominal}MB
═════════════════════`;

                await sock.sendMessage(from, {
                    interactiveMessage: {
                        title: teks,
                        nativeFlowMessage: {
                            buttons: [{
                                name: "cta_copy",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Copy Code",
                                    id: "copy_code",
                                    copy_code: pairingCode.replace(/-/g, '')
                                })
                            }]
                        }
                    }
                }, { quoted: msg });
                await react(from, '✅');
            } else {
                await react(from, '❌');
                await sock.sendMessage(from, { text: `⚠️ Pairing Code tidak terdeteksi dalam 45 detik. Silakan cek logs menggunakan 'pm2 logs ${pm2Name}'.` }, { quoted: msg });
            }

        } catch (error) {
            console.error('[JADIBOT ERROR]', error);
            await react(from, '❌');
            await sock.sendMessage(from, { text: `Gagal membuat jadibot: ${error.message}` }, { quoted: msg });
        }
    }
};
