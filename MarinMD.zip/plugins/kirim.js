const fs = require('fs');
const path = require('path');

module.exports = {
    command: 'kirim',
    description: 'Mengirimkan link dari brankas ke pengguna',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;

        if (args.length < 1) {
            const petunjuk = `╭❰ FORMAT SALAH ❱\n│ ⟡ Gunakan: .kirim [nama]\n│ ⟡ Contoh: .kirim nama\n╰────────────❱\n©NakunBot`;
            return sock.sendMessage(from, { text: petunjuk }, { quoted: msg });
        }

        const namaFile = args.join(" ");
        const linkPath = path.join(__dirname, '../link.json');

        let linkData = {};
        if (fs.existsSync(linkPath)) {
            linkData = JSON.parse(fs.readFileSync(linkPath, 'utf-8'));
        }

        // Cek apakah ada link untuk file ini di link.json
        if (linkData[namaFile] && linkData[namaFile].trim() !== "") {
            const link = linkData[namaFile];

            const linkTeks = `╭❰ FILE BY NAKUN ❱
│ ⟡ Nama File: ${namaFile}
│ ⟡ Status: Aman / Tested
│ ⟡ Info: Harap lihat tutorial
│ ⟡ Terima kasih sudah order!
╰────────────❱
©NakunBot

Tutorial : https://files.catbox.moe/6auu4n.mp4
Link: ${link}`;

            await sock.sendMessage(from, { react: { text: "⏳", key: msg.key } });
            return sock.sendMessage(from, { text: linkTeks }, { quoted: msg });
        } else {
            // Jika tidak ditemukan, berikan list link yang tersedia di link.json
            const availableLinks = Object.keys(linkData).map(k => `│ ⟡ ${k}`).join('\n');
            const warning = `╭❰ LINK TIDAK TERSEDIA ❱
│ ⟡ Link untuk "${namaFile}" belum tersedia.
╰────────────❱
╭❰ DAFTAR LINK TERSEDIA ❱
${availableLinks || "│ (Kosong)"}
╰────────────❱
©NakunBot`;
            return sock.sendMessage(from, { text: warning }, { quoted: msg });
        }
    }
};
