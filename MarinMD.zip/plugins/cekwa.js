const fs = require('fs');
const { delay } = require('@whiskeysockets/baileys');
const chalk = require('chalk');

module.exports = {
    command: ['cekwa', 'checkwa'],
    execute: async (sock, m, { args, q, reply, react, from }) => {
        const INPUT_FILE = './numbers.txt';
        let numbers = [];

        // 1. Ambil input nomor (bisa dari argumen atau dari file)
        if (q) {
            // Jika user ngetik: .cekwa 0812xxx,0857xxx
            numbers = q.split(',').map(n => n.trim());
        } else if (fs.existsSync(INPUT_FILE)) {
            // Jika user cuma ngetik .cekwa, baca dari numbers.txt
            const fileContent = fs.readFileSync(INPUT_FILE, 'utf-8');
            numbers = fileContent.split('\n').map(n => n.trim()).filter(n => n.length >= 9);
        }

        if (numbers.length === 0) return reply(`Kirim nomor yang ingin dicek atau isi file ${INPUT_FILE}.\nContoh: .cekwa 0812xxx,0857xxx`);

        // 2. React Loading
        await react(from, '🕐');
        
        let report = `╭─「 *WA NUMBER CHECKER* 」\n`;
        report += `│ ⟡ Total: ${numbers.length} nomor\n`;
        report += `╰──────────────────\n\n`;

        // Fungsi deteksi provider
        const getProvider = (number) => {
            let clean = number.replace(/[^0-9]/g, '');
            if (clean.startsWith('62')) clean = '0' + clean.slice(2);
            else if (clean.startsWith('8')) clean = '0' + clean;
            
            const prefix = clean.slice(0, 4);
            const providerMap = {
                'Telkomsel': ['0811', '0812', '0813', '0821', '0822', '0823', '0851', '0852', '0853'],
                'Indosat': ['0814', '0815', '0816', '0857', '0858'],
                'XL': ['0817', '0818', '0819', '0859', '0877', '0878'],
                'Axis': ['0831', '0832', '0833', '0838'],
                'Tri': ['0895', '0896', '0897', '0898', '0899'],
                'Smartfren': ['0881', '0882', '0883', '0884', '0885', '0886', '0887', '0888', '0889']
            };
            for (const [provider, prefixes] of Object.entries(providerMap)) {
                if (prefixes.includes(prefix)) return provider;
            }
            return 'Lainnya';
        };

        const formatJid = (number) => {
            let clean = number.replace(/[^0-9]/g, '');
            if (clean.startsWith('0')) clean = '62' + clean.slice(1);
            if (clean.startsWith('8')) clean = '62' + clean;
            return clean.endsWith('@s.whatsapp.net') ? clean : clean + '@s.whatsapp.net';
        };

        // 3. Proses Pengecekan
        for (const num of numbers) {
            const provider = getProvider(num);
            const jid = formatJid(num);
            const display = jid.split('@')[0];

            try {
                const [exists] = await sock.onWhatsApp(jid);
                const status = exists?.exists ? '✅ Terdaftar' : '❌ Tidak terdaftar';
                report += `Number: ${display}\nProvider: ${provider}\nStatus: ${status}\n\n`;
            } catch (e) {
                report += `Number: ${display}\nProvider: ${provider}\nStatus: ⚠️ Error\n\n`;
            }

            // Safety Delay 3 detik (dipercepat sedikit karena ini bot)
            await delay(3000);
        }

        // 4. Kirim Hasil & React Success
        report += `© Marin-V15`;
        await reply(report);
        await react(from, '✅');
    }
};
