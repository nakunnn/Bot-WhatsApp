const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');

const BASE_QRIS = '00020101021126610014COM.GO-JEK.WWW01189360091432020329020210G2020329020303UMI51440014ID.CO.QRIS.WWW0215ID10253744258390303UMI5204581653033605802ID5912Nakunn store6008MAGELANG61055651262070703A016304C5DB';

function crc16_ccitt_false(str) {
    let crc = 0xFFFF;
    for (let i = 0; i < str.length; i++) {
        crc ^= str.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            if ((crc & 0x8000) > 0) {
                crc = (crc << 1) ^ 0x1021;
            } else {
                crc = (crc << 1);
            }
        }
    }
    return (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
}

function generateDynamicQRIS(baseQris, amount) {
    const amountStr = amount.toString();
    const amountLength = amountStr.length.toString().padStart(2, '0');
    const tag54 = `54${amountLength}${amountStr}`;
    const modifiedQris = baseQris.replace('5802ID', tag54 + '5802ID');
    const qrisWithoutCRC = modifiedQris.slice(0, -4);
    const newCRC = crc16_ccitt_false(qrisWithoutCRC);
    return qrisWithoutCRC + newCRC;
}

function formatRupiah(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(amount);
}

async function buildQRImage(qrisString) {
    const framePath = path.join(__dirname, '../media/frame.png');
    const qrBuffer = await QRCode.toBuffer(qrisString, {
        margin: 2,
        scale: 8,
        color: { dark: '#000000', light: '#FFFFFF' }
    });

    if (fs.existsSync(framePath)) {
        try {
            const sharp = require('sharp');
            const frameMeta = await sharp(framePath).metadata();
            const qrSize = 500;
            const qrResized = await sharp(qrBuffer).resize(qrSize, qrSize, { fit: 'fill' }).toBuffer();
            return await sharp({
                create: { width: frameMeta.width, height: frameMeta.height, channels: 4, background: { r: 255, g: 255, b: 255, alpha: 1 } }
            }).composite([
                { input: qrResized, top: 216, left: 84 },
                { input: framePath, top: 0, left: 0 }
            ]).png().toBuffer();
        } catch (e) { return qrBuffer; }
    }
    return qrBuffer;
}

module.exports = {
    command: 'qris',
    execute: async (sock, m, { args, reply, react }) => {
        if (!args.length) return reply("⚠️ Format: .qris <nominal>\nContoh: .qris 10000");

        await react(m.chat, "💸");
        const amount = parseInt(args[0].replace(/[.,\s]/g, '').replace(/^rp/i, ''));

        if (isNaN(amount) || amount < 100) return reply("❌ Nominal minimal Rp 100");

        try {
            const dynamicQRIS = generateDynamicQRIS(BASE_QRIS, amount);
            const imageBuffer = await buildQRImage(dynamicQRIS);

            let caption = `╭❰ QRIS DINAMIS ❱
│ ⟡ Nominal : ${formatRupiah(amount)}
│ ⟡ Untuk   : Nakun Store
│ ⟡ Aktif   : 5 Menit (Auto-Expired)
╰────────────❱

Silakan selesaikan pembayaran menggunakan aplikasi e-wallet favorit Anda.`;

            const sentMsg = await sock.sendMessage(m.chat, {
                interactiveMessage: {
                    title: `PAYMENT: ${formatRupiah(amount)}\n\n${caption}`,
                    footer: "⿻ 𝐌𝐚𝐫𝐢𝐧 𝐄𝐱𝐞𝐜𝐮𝐭𝐨𝐫 | ©NakunStore",
                    image: imageBuffer,
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Hubungi Admin",
                                    url: "https://wa.me/6285726013874"
                                })
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Sudah Bayar",
                                    id: ".testi"
                                })
                            }
                        ]
                    }
                }
            }, { quoted: m });

            // Auto-delete pesan dan kirim pesan expired setelah 5 menit (300000 ms)
            setTimeout(async () => {
                try {
                    // Hapus foto QRIS
                    await sock.sendMessage(m.chat, { delete: sentMsg.key });

                    const expiredText = `╭❰ ⚠️ PAY EXPIRING ❱
│ ⟡ Status   : EXPIRED
│ ⟡ Nominal  : ${formatRupiah(amount)}
│
│ ❌ Waktu pembayaran telah habis.
│ ❌ Foto QRIS telah dihapus otomatis.
╰────────────❱
©NakunStore`;

                    await sock.sendMessage(m.chat, { text: expiredText }, { quoted: m });
                } catch (e) {
                    console.error('[QRIS AUTO-DELETE EXPIRED ERROR]', e);
                }
            }, 300000);

        } catch (err) {
            console.error(err);
            reply("❌ Terjadi kesalahan saat membuat QRIS.");
        }
    }
};
