const axios = require('axios');

module.exports = {
    command: 'humanizer',
    description: 'Humanize AI Text (Bypass Detection)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0].split(':')[0];

        const text = args.join(' ');
        if (!text) {
            return sock.sendMessage(from, { text: 'Masukkan teks AI yang ingin di-humanize!\nContoh: .humanizer [teks]' }, { quoted: msg });
        }

        try {
            const apiUrl = `https://api.nexray.eu.cc/ai/bypass?text=${encodeURIComponent(text)}`;
            const response = await axios.get(apiUrl, { timeout: 300000 });
            
            if (response.data && response.data.status && response.data.result) {
                const replyText = `╭❰ HUMANIZER AI ❱
│ ⟡ Fungsi : Bypass AI Detection
╰────────────❱
╭❰ INFO ❱
│ ⟡ User : @${senderNumber} 
╰────────────❱

${response.data.result}`;

                await sock.sendMessage(from, { text: replyText, mentions: [sender] }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: 'Gagal mendapatkan respons dari server.' }, { quoted: msg });
            }
        } catch (error) {
            console.error('[ERR] Humanizer Fetch:', error.message);
            await sock.sendMessage(from, { text: 'Terjadi kesalahan saat menghubungi server.' }, { quoted: msg });
        }
    }
};
