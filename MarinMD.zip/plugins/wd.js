const { saveRevenue, loadRevenue } = require('../lib/gsheets');

module.exports = {
    command: ['wd', 'wb'],
    description: 'Melakukan penarikan (withdraw) nominal untung reseller atau melihat riwayatnya',
    execute: async (sock, msg, { args, react, reply, command }) => {
        const from = msg.key.remoteJid;
        const isWb = command.toLowerCase() === 'wb';
        const typeName = isWb ? 'WITHDRAW BONUS (WB)' : 'WITHDRAWAL (WD)';

        if (args.length < 1) {
            const petunjuk = `╭ ❰ FORMAT SALAH ❱
│ ⟡ Cara pakai: .${command} [nominal] [keterangan]
│ ⟡ Cara cek riwayat: .${command} history
│ ⟡ Contoh: .${command} 50000 Tarik Untung
│ ⟡ Ketik angka saja tanpa titik/Rp
╰────────────❱
©NakunStore`;
            return reply(petunjuk);
        }

        // --- FITUR HISTORY ---
        if (args[0].toLowerCase() === 'history') {
            try {
                await react(from, '⏳');
                const db = await loadRevenue();
                
                // Filter data dengan kategori WITHDRAW
                const history = db.filter(item => item.kategori === 'WITHDRAW');
                
                if (history.length === 0) {
                    await react(from, '❌');
                    return reply(`╭ ❰ HISTORY KOSONG ❱
│ ⟡ Belum ada riwayat penarikan (WD/WB)
╰────────────❱
©NakunStore`);
                }
                
                // Urutkan dari yang terbaru (paling bawah di sheets jadi teratas di tampilkan)
                const recentHistory = [...history].reverse().slice(0, 10);
                
                const fmt = (n) => Math.abs(n).toLocaleString('id-ID');
                let listTeks = '';
                recentHistory.forEach((item) => {
                    const cleanKet = item.keterangan.replace(/\[WD\]\s*|\[WB\]\s*/g, '');
                    listTeks += `│ ⟡ [${item.tanggal.slice(0, 5)}] -Rp${fmt(item.untung_reseller)} | ${cleanKet}\n`;
                });
                
                await react(from, '✅');
                const responseText = `╭ ❰ RIWAYAT PENARIKAN (MAX 10) ❱
${listTeks}╰────────────❱
©NakunStore`;
                
                return reply(responseText);
            } catch (error) {
                console.error('[WD HISTORY ERROR]', error);
                await react(from, '❌');
                return reply(`❌ Gagal mengambil riwayat penarikan: ${error.message}`);
            }
        }

        // --- FITUR EKSEKUSI WD/WB ---
        const nominal = parseInt(args[0].replace(/[^0-9]/g, ''));
        if (isNaN(nominal) || nominal <= 0) {
            return reply('❌ Masukkan nominal angka yang valid atau gunakan command "history"!');
        }

        const keteranganInput = args.slice(1).join(' ') || '-';
        const labelCmd = command.toUpperCase();
        const keterangan = `[${labelCmd}] ${keteranganInput}`;

        await react(from, '⏳');

        try {
            // 1. Ambil data omzet untuk menghitung total untung reseller saat ini
            const db = await loadRevenue();
            let totalResellerProfit = 0;
            for (const item of db) {
                totalResellerProfit += Number(item.untung_reseller) || 0;
            }

            // 2. Simpan pengurangan ke Google Sheets (untung_reseller minus)
            const berhasil = await saveRevenue({
                masuk: 0,
                untung_me: 0,
                untung_reseller: -Math.abs(nominal),
                keterangan: keterangan,
                kategori: 'WITHDRAW',
            });

            if (!berhasil) {
                await react(from, '⚠️');
                return reply(`╭ ❰ PERINGATAN ❱
│ ⟡ GAGAL menyimpan transaksi ${labelCmd} ke Google Sheets
│ ⟡ Cek koneksi / Spreadsheet ID Anda
╰────────────❱
©NakunStore`);
            }

            const fmt = (n) => n.toLocaleString('id-ID');
            const sisaProfit = totalResellerProfit - nominal;

            await react(from, '✅');
            const teksSukses = `╭ ❰ ${typeName} SUKSES ❱
│ ⟡ Nominal Tarik  : Rp ${fmt(nominal)}
│ ⟡ Keterangan     : ${keteranganInput}
│ ---------------------------
│ ⟡ Untung Awal    : Rp ${fmt(totalResellerProfit)}
│ ⟡ Sisa Untung    : Rp ${fmt(sisaProfit)}
│ 
│ ✅ Transaksi tercatat di Google Sheets!
╰────────────❱
©NakunStore`;

            return reply(teksSukses);
        } catch (error) {
            console.error('[WD/WB ERROR]', error);
            await react(from, '❌');
            return reply(`❌ Terjadi kesalahan: ${error.message}`);
        }
    }
};
