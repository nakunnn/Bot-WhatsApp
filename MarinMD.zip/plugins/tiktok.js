const axios = require('axios');

module.exports = {
    command: 'tiktok',
    execute: async (sock, m, { args, reply, react }) => {
        if (!args[0]) return reply("⚠️ Kirim link TikTok!\nContoh: .tiktok <link>");
        
        await react(m.chat, "⏳");
        try {
            const url = args[0];
            const params = new URLSearchParams();
            params.set("url", url);
            params.set("hd", "1");
            
            const response = await axios({
                method: "POST",
                url: "https://tikwm.com/api/",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    Cookie: "current_language=en",
                    "User-Agent": "Mozilla/5.0"
                },
                data: params
            });
            
            const result = response.data.data;
            if (!result || !result.play) {
                await react(m.chat, "❌");
                return reply("❌ Gagal mendapatkan video TikTok.");
            }
            
            let caption = `📥 TikTok Downloader\n🎬 Title: ${result.title}\n🎵 Music: ${result.music}\n`;
            
            await sock.sendMessage(m.chat, {
                video: { url: result.play },
                caption: caption,
                jpegThumbnail: (await axios.get(result.cover, { responseType: 'arraybuffer' })).data
            }, { quoted: m });
            await react(m.chat, "✅");
            
        } catch (err) {
            console.error(err);
            await react(m.chat, "❌");
            reply("❌ Terjadi kesalahan saat memproses TikTok.");
        }
    }
};
