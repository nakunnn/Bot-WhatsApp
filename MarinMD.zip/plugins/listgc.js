module.exports = {
    command: 'listgc',
    description: 'Cek statistik grup yang dimasuki bot',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        
        try {
            const groups = await sock.groupFetchAllParticipating();
            let total = 0;
            let open = 0;
            let closed = 0;
            
            const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
            
            for (const jid in groups) {
                if (jid === '120363405675223209@g.us') continue;
                
                const metadata = groups[jid];
                total++;
                
                // Cek apakah grup ditutup (hanya admin)
                if (metadata.announce) {
                    const isBotAdmin = metadata.participants.find(p => p.id === botId)?.admin;
                    if (isBotAdmin) {
                        open++;
                    } else {
                        closed++;
                    }
                } else {
                    open++;
                }
            }
            
            const resultMsg = `╭❰ HASIL CEK GROUP ❱\n│ ⟡ Total Grup: ${total}\n│ ⟡ Terbuka: ${open}\n│ ⟡ Tertutup: ${closed}\n╰────────────❱\n©NakunStore`;
            
            await sock.sendMessage(from, { text: resultMsg }, { quoted: msg });
            
        } catch (err) {
            console.error('Error in listgc:', err);
            await sock.sendMessage(from, { text: '╭❰ ERROR ❱\n│ ⟡ Gagal memuat daftar grup.\n╰────────────❱\n©NakunStore' }, { quoted: msg });
        }
    }
}
