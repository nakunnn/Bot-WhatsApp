module.exports = {
    command: 'swgrup',
    execute: async (sock, m, { q, command, prefix, reply }) => {
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || "";
        const text = q || "";
        
        if (/image/.test(mime)) {
            const media = await quoted.download();
            await sock.sendMessage(m.chat, { groupStatusMessage: { image: media, caption: text } });
            reply("Udah Jing");
        } else if (/video/.test(mime)) {
            const media = await quoted.download();
            await sock.sendMessage(m.chat, { groupStatusMessage: { video: media, caption: text } });
            reply("Udah Jing");
        } else if (/audio/.test(mime)) {
            const media = await quoted.download();
            await sock.sendMessage(m.chat, { groupStatusMessage: { audio: media } });
            reply("Udah Jing");
        } else if (text) {
            await sock.sendMessage(m.chat, { groupStatusMessage: { text: text } });
            m.react("✅️");
        } else {
            reply(`reply media atau tambahkan teks.\nexample: ${prefix + command} (reply image/video/audio) hai ini saya`);
        }
    }
};
