const targetGroup = "120363405675223209@g.us";

// Inisialisasi state warmer di global agar tidak hilang saat reload module
if (!global.warmerState) {
    global.warmerState = {
        intervalId: null,
        active: false
    };
}

module.exports = {
    command: 'warmer',
    description: 'Menyalakan proses warmer bot ke grup khusus tiap satu jam',
    execute: async (sock, msg, args) => {
        const subCommand = args[0] ? args[0].toLowerCase() : '';
        const from = msg.key.remoteJid;

        if (subCommand === 'on') {
            if (global.warmerState.active) {
                return sock.sendMessage(from, {
                    text: '╭❰ WARMER ❱\n│ ⟡ Proses warmer sudah aktif!\n╰────────────❱\n©NakunBot'
                }, { quoted: msg });
            }

            global.warmerState.active = true;

            // Kirim pesan untuk pertama kali saat diaktifkan
            try {
                await sock.sendMessage(targetGroup, { text: 'proses warmer anti kenon [BOT]' });
            } catch (err) {
                console.error('[WARMER] Gagal mengirim pesan awal:', err);
            }

            // Set interval setiap 1 jam (3600000 ms)
            global.warmerState.intervalId = setInterval(async () => {
                try {
                    console.log('[WARMER] Mengirim pesan warmer ke grup khusus...');
                    await sock.sendMessage(targetGroup, { text: 'proses warmer anti kenon [BOT]' });
                } catch (err) {
                    console.error('[WARMER] Error interval warmer:', err);
                }
            }, 3600000);

            return sock.sendMessage(from, {
                text: '╭❰ WARMER ❱\n│ ⟡ Warmer telah diaktifkan! Pesan akan dikirim setiap 1 jam ke grup khusus.\n╰────────────❱\n©NakunBot'
            }, { quoted: msg });

        } else if (subCommand === 'off') {
            if (!global.warmerState.active) {
                return sock.sendMessage(from, {
                    text: '╭❰ WARMER ❱\n│ ⟡ Proses warmer memang sedang tidak aktif!\n╰────────────❱\n©NakunBot'
                }, { quoted: msg });
            }

            // Matikan interval
            global.warmerState.active = false;
            if (global.warmerState.intervalId) {
                clearInterval(global.warmerState.intervalId);
                global.warmerState.intervalId = null;
            }

            return sock.sendMessage(from, {
                text: '╭❰ WARMER ❱\n│ ⟡ Warmer berhasil dimatikan!\n╰────────────❱\n©NakunBot'
            }, { quoted: msg });

        } else {
            // Tampilkan status & menu bantuan
            const statusText = global.warmerState.active ? 'Aktif' : 'Nonaktif';
            return sock.sendMessage(from, {
                text: `╭❰ WARMER ❱\n` +
                    `│ ⟡ Status: ${statusText}\n` +
                    `│\n` +
                    `│ Daftar Command:\n` +
                    `│ • .warmer on — Aktifkan proses warmer (1 jam)\n` +
                    `│ • .warmer off — Matikan proses warmer\n` +
                    `╰────────────❱\n` +
                    `©NakunBot`
            }, { quoted: msg });
        }
    }
};
