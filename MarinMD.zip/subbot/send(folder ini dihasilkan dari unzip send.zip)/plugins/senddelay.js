const sendPlugin = require('./send');

module.exports = {
    command: 'senddelay',
    description: 'Sets the background loop delay in minutes for the send session',
    execute: async (sock, msg, args) => {
        const minutes = parseInt(args[0]);
        if (isNaN(minutes)) {
            await sock.sendMessage(msg.key.remoteJid, { text: '╭❰ ERROR ❱\n│ ⟡ Please provide a valid number of minutes.\n│ ⟡ Usage: .senddelay <minutes>\n│ ⟡ Use 0 to stop the repeating loop.\n╰────────────❱\n©NakunBot' }, { quoted: msg });
            return;
        }

        // Clear existing interval
        if (global.sendState.intervalId) {
            clearInterval(global.sendState.intervalId);
            global.sendState.intervalId = null;
        }

        if (minutes <= 0) {
            global.sendState.delayMinutes = 0;
            await sock.sendMessage(msg.key.remoteJid, { text: '╭❰ AUTO send DELAY ❱\n│ ⟡ Auto send loop has been stopped.\n╰────────────❱\n©NakunBot' }, { quoted: msg });
            return;
        }

        if (!global.sendState.lastMessage) {
            await sock.sendMessage(msg.key.remoteJid, { 
                text: '╭❰ ERROR ❱\n│ ⟡ No previous Auto send message found in memory.\n│ ⟡ Please run .send <message> at least once.\n╰────────────❱\n©NakunBot' 
            }, { quoted: msg });
            return;
        }

        global.sendState.delayMinutes = minutes;
        const ms = minutes * 60 * 1000;

        await sock.sendMessage(msg.key.remoteJid, { 
            text: `╭❰ AUTO send DELAY ❱\n│ ⟡ Loop set to repeat every ${minutes} minutes.\n│ ⟡ Bot will broadcast previously saved message.\n╰────────────❱\n©NakunBot` 
        }, { quoted: msg });

        // Start repeating interval
        global.sendState.intervalId = setInterval(async () => {
            if (global.sendState.isLooping) {
                console.log(`[Interval loop triggered] Re-running background Auto send broadcast...`);
                await sendPlugin.dosendBroadcast(sock, global.sendState.lastMessage, global.sendState.callerId);
            }
        }, ms);
    }
};
