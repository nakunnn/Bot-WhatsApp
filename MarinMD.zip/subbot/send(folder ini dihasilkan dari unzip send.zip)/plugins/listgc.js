module.exports = {
    command: 'listgc',
    description: 'Mengecek total grup (semua, terbuka, tertutup)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        try {
            await sock.sendMessage(from, { text: '╭❰ INFO ❱\n│ ⟡ Sedang mengambil data grup...\n╰────────────❱\n©NakunBot' }, { quoted: msg });
            
            const groups = await sock.groupFetchAllParticipating();
            const groupList = Object.values(groups);
            
            let totalGroups = 0;
            let openGroups = 0;
            let closedGroups = 0;

            for (const g of groupList) {
                // Jangan hitung grup utama JPM Nakun jika mau, 
                // tapi karena diminta 'total semua', kita hitung semua saja.
                totalGroups++;
                if (g.announce) {
                    closedGroups++;
                } else {
                    openGroups++;
                }
            }

            const finalMsg = `╭❰ STATISTIK GRUP ❱
│ ⟡ Total Grup: ${totalGroups}
│ ⟡ Terbuka: ${openGroups}
│ ⟡ Tertutup: ${closedGroups}
╰────────────❱
©NakunBot`;

            await sock.sendMessage(from, { text: finalMsg }, { quoted: msg });
        } catch (error) {
            console.error('Error in listgc:', error);
            await sock.sendMessage(from, { text: '╭❰ ERROR ❱\n│ ⟡ Terjadi kesalahan saat memeriksa grup.\n╰────────────❱\n©NakunBot' }, { quoted: msg });
        }
    }
}
