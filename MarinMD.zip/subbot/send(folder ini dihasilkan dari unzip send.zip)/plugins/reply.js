const fs = require('fs');
const path = require('path');

const dbDir = path.join(__dirname, '../database');
const dbPath = path.join(dbDir, 'autoreply.json');
const targetGroup = "120363405675223209@g.us";

const DEFAULT_MESSAGE = 'Halo! Pesan kamu sudah diterima.\nMohon tunggu balasan dari admin.\n\n©NakunBot';
const BANNER_URL = "https://files.catbox.moe/oj0oec.jpeg";

// Map untuk menyimpan cooldown auto-reply (1 menit per orang)
const pmCooldowns = new Map();

// ─── DATABASE HELPERS ───
function getDB() {
    let db = { status: true, message: DEFAULT_MESSAGE };
    try {
        if (fs.existsSync(dbPath)) {
            const raw = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
            db.status = raw.status !== undefined ? raw.status : true;
            db.message = raw.message || DEFAULT_MESSAGE;
        } else {
            if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 4));
            console.log('[REPLY] Database autoreply.json dibuat otomatis.');
        }
    } catch (e) {
        console.error('[REPLY] Error baca database:', e.message);
    }
    return db;
}

function saveDB(data) {
    if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 4));
}

// ─── CEK TIPE PESAN ───
function isMediaMessage(msg) {
    if (!msg.message) return false;
    let m = msg.message;
    if (m.ephemeralMessage) m = m.ephemeralMessage.message;
    return !!(m.imageMessage || m.audioMessage || m.videoMessage || m.stickerMessage || m.documentMessage);
}

function getTextContent(msg) {
    if (!msg.message) return '';
    let m = msg.message;
    if (m.ephemeralMessage) m = m.ephemeralMessage.message;
    return m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || '';
}

const withTimeout = (promise, ms) => {
    let timeoutId;
    const timeoutPromise = new Promise((_, reject) => {
        timeoutId = setTimeout(() => {
            reject(new Error("Timeout"));
        }, ms);
    });
    return Promise.race([promise, timeoutPromise]).finally(() => {
        clearTimeout(timeoutId);
    });
};

async function sendPremiumReply(sock, to, replyText) {
    try {
        await withTimeout(sock.sendMessage(to, {
            interactiveMessage: {
                title: replyText,
                footer: "⿻ 𝐍𝐚𝐤𝐮𝐧𝐁𝐨𝐭 𝐒𝐞𝐧𝐭 | ©NakunBot",
                image: { url: BANNER_URL },
                nativeFlowMessage: {
                    messageParamsJson: JSON.stringify({
                        limited_time_offer: {
                            text: "𝐍𝐀𝐊𝐔𝐍 𝐗 𝐌𝐀𝐑𝐈𝐍",
                            url: "https://wa.me/6285726013874",
                            copy_code: "MARINV15",
                            expiration_time: Date.now() + (24 * 60 * 60 * 1000)
                        },
                        bottom_sheet: {
                            in_thread_buttons_limit: 2,
                            divider_indices: [1],
                            list_title: "LIST",
                            button_title: "⿻ 𝐌𝐚𝐫𝐢𝐧"
                        }
                    }),
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Testimoni",
                            url: "https://whatsapp.com/channel/0029VbC3DioDeONBPSW8hH3n",
                            merchant_url: "https://whatsapp.com/channel/0029VbC3DioDeONBPSW8hH3n"
                        })
                    }]
                }
            },
            contextInfo: {
                externalAdReply: {
                    title: "NAKUN STORE • AUTO REPLY",
                    body: "Silakan tunggu respon admin kami",
                    thumbnailUrl: BANNER_URL,
                    sourceUrl: "https://wa.me/6285726013874",
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
        }), 5000);
        console.log('[REPLY] Interactive auto-reply berhasil dikirim!');
        return true;
    } catch (err) {
        console.error('[REPLY] GAGAL kirim interactive reply:', err.message);
        // Fallback: plain text
        try {
            await sock.sendMessage(to, { text: replyText });
            console.log('[REPLY] Fallback plain text berhasil!');
            return true;
        } catch (e) {
            console.error('[REPLY] Fallback juga gagal:', e.message);
            return false;
        }
    }
}

module.exports = {
    command: 'reply',
    description: 'Auto-reply untuk pesan masuk & forward ke grup khusus',

    // ═══════════════════════════════════════════
    // handlePM — dipanggil dari index.js untuk SETIAP pesan masuk
    // ═══════════════════════════════════════════
    handlePM: async (sock, msg) => {
        try {
            const from = msg.key.remoteJid;

            // Skip status broadcast & group
            if (!from || from === 'status@broadcast') return;
            const isGroup = from.endsWith('@g.us');
            if (isGroup) return; // Hanya proses PM

            const isMe = msg.key.fromMe;
            if (isMe) return; // Skip pesan dari bot sendiri

            // Skip jika pesan adalah command (agar .reply edit dll tidak di-auto-reply)
            const rawText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            if (rawText.trim().startsWith('.')) return;

            const senderName = msg.pushName || 'Tidak diketahui';
            const senderNumber = from.split('@')[0];

            console.log(`[REPLY] PM masuk dari ${senderName} (${senderNumber})`);

            // Baca database terbaru
            const db = getDB();
            if (!db.status) {
                console.log('[REPLY] Auto-reply OFF, skip.');
                return;
            }

            const replyText = db.message || DEFAULT_MESSAGE;

            // ── 1. KIRIM AUTO-REPLY ke pengirim (dengan cooldown 1 menit) ──
            const now = Date.now();
            const lastReply = pmCooldowns.get(from) || 0;
            if (now - lastReply >= 60000) { // 60000ms = 1 menit
                await sendPremiumReply(sock, from, replyText, msg);
                pmCooldowns.set(from, now);
            } else {
                console.log(`[REPLY] Cooldown aktif untuk ${senderNumber}, skip kirim auto-reply.`);
            }

            // ── 2. FORWARD ke GRUP KHUSUS + HIDE TAG ──
            if (isMediaMessage(msg)) {
                console.log('[REPLY] Pesan media, skip forward ke grup.');
                return;
            }

            const contentText = getTextContent(msg);
            if (!contentText) {
                console.log('[REPLY] Tidak ada content teks, skip forward.');
                return;
            }

            try {
                console.log(`[REPLY] Forwarding pesan ke grup...`);

                const groupMetadata = await sock.groupMetadata(targetGroup);
                const participants = groupMetadata.participants.map(p => p.id);

                const waktu = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

                const forwardText =
                    `╭❰ PESAN MASUK ❱\n` +
                    `│ ⟡ Dari: ${senderName}\n` +
                    `│ ⟡ Nomor: wa.me/${senderNumber}\n` +
                    `│ ⟡ Waktu: ${waktu}\n` +
                    `│\n` +
                    `│ 💬 Pesan:\n` +
                    `│ ${contentText}\n` +
                    `╰────────────❱\n` +
                    `©NakunBot`;

                await sock.sendMessage(targetGroup, {
                    text: forwardText,
                    mentions: participants
                });
                console.log('[REPLY] Forward ke grup berhasil!');
            } catch (err) {
                console.error('[REPLY] GAGAL forward ke grup:', err.message);
            }
        } catch (err) {
            console.error('[REPLY] ERROR FATAL di handlePM:', err.message);
        }
    },

    // ═══════════════════════════════════════════
    // execute — handler untuk command .reply
    // ═══════════════════════════════════════════
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const sub = args[0] ? args[0].toLowerCase() : '';

        // .reply on
        if (sub === 'on') {
            const db = getDB();
            db.status = true;
            saveDB(db);
            return sock.sendMessage(from, {
                text: '╭❰ AUTO REPLY ❱\n│ ⟡ Auto-Reply berhasil diaktifkan! ✅\n╰────────────❱\n©NakunBot'
            }, { quoted: msg });
        }

        // .reply off
        if (sub === 'off') {
            const db = getDB();
            db.status = false;
            saveDB(db);
            return sock.sendMessage(from, {
                text: '╭❰ AUTO REPLY ❱\n│ ⟡ Auto-Reply berhasil dimatikan! ❌\n╰────────────❱\n©NakunBot'
            }, { quoted: msg });
        }

        // .reply edit <pesan>
        if (sub === 'edit') {
            const text = args.slice(1).join(' ');
            if (!text) {
                return sock.sendMessage(from, {
                    text: '╭❰ ERROR ❱\n│ ⟡ Pesan tidak boleh kosong.\n│ ⟡ Contoh: .reply edit Halo kak!\n╰────────────❱\n©NakunBot'
                }, { quoted: msg });
            }
            try {
                const db = getDB();
                db.message = text;
                saveDB(db);
                return sock.sendMessage(from, {
                    text: `╭❰ SUCCESS ❱\n│ ⟡ Pesan auto-reply berhasil diperbarui!\n│\n│ 📝 Preview:\n│ ${text}\n╰────────────❱\n©NakunBot`
                }, { quoted: msg });
            } catch (err) {
                console.error('[ERR] .reply edit error:', err);
                return sock.sendMessage(from, {
                    text: `╭❰ ERROR ❱\n│ ⟡ Gagal menyimpan pesan auto-reply.\n│ ⟡ Error: ${err.message}\n╰────────────❱\n©NakunBot`
                }, { quoted: msg });
            }
        }

        // .reply (tanpa argumen) → tampilkan info
        const db = getDB();
        const statusText = db.status ? '✅ Aktif' : '❌ Nonaktif';
        const currentMsg = db.message || DEFAULT_MESSAGE;

        return sock.sendMessage(from, {
            text: `╭❰ AUTO REPLY ❱\n` +
                `│ ⟡ Status: ${statusText}\n` +
                `│\n` +
                `│ 📝 Pesan Saat Ini:\n` +
                `│ ${currentMsg}\n` +
                `│\n` +
                `│ 📋 Daftar Command:\n` +
                `│ • .reply on — Aktifkan\n` +
                `│ • .reply off — Matikan\n` +
                `│ • .reply edit <pesan> — Edit pesan\n` +
                `╰────────────❱\n` +
                `©NakunBot`
        }, { quoted: msg });
    }
};
