const { delay } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../database/send.json');

// Helper untuk mengambil pesan yang tersimpan
function getSavedMessage() {
    if (fs.existsSync(configPath)) {
        try {
            const data = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            return data.message || '';
        } catch (e) {
            return '';
        }
    }
    return '';
}

// Helper untuk menyimpan pesan
function saveMessage(text) {
    const dir = path.dirname(configPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(configPath, JSON.stringify({ message: text }, null, 4));
}

async function dosendBroadcast(sock, textMessage, callerId) {
    if (!textMessage || !callerId) return;
    if (global.sendState.isRunning) {
        console.log("[SEND] Broadcast is already running, skipping this execution.");
        return;
    }
    
    global.sendState.isRunning = true;
    try {
        const groups = await sock.groupFetchAllParticipating();
        const groupEntries = Object.entries(groups).filter(([jid]) => jid !== '120363405675223209@g.us');
        const totalGroups = groupEntries.length;
        let successCount = 0;
        let failedCount = 0;
        
        // START NOTIFICATION
        console.log(`Starting send Broadcast to ${totalGroups} groups...`);
        try {
            await sock.sendMessage(callerId, {
                text: `╭❰ INFO send ❱\n│ ⟡ Putaran send baru dimulai.\n│ ⟡ Target: ${totalGroups} Grup\n│ ⟡ Mohon tunggu sampai selesai.\n╰────────────❱\n©NakunBot`
            });
        } catch (e) {
            console.error(`Failed to send start notification:`, e.message);
        }
        for (const [jid, metadata] of groupEntries) {
            // CHECK STOP SIGNAL
            if (!global.sendState.isLooping) {
                console.log("Broadcast stopped by signal.");
                break;
            }

            try {
                await sock.sendMessage(jid, { text: textMessage });
                successCount++;
                console.log(`Broadcast success to: ${jid}`);
            } catch (e) {
                failedCount++;
                console.error(`Broadcast failed for ${jid}:`, e.message);
            }
            await delay(4000); 
        }
        
        // Only send summary if broadcast actually happened or wasn't immediately stopped
        if (successCount > 0 || failedCount > 0) {
            try {
                const statusSuffix = global.sendState.isLooping ? "telah selesai" : "dihentikan paksa";
                await sock.sendMessage(callerId, {
                    text: `╭❰ INFO send ❱\n│ ⟡ Putaran send ${statusSuffix}.\n│ ⟡ Total Grup: ${totalGroups}\n│ ⟡ Terbuka: ${successCount}\n│ ⟡ Tertutup: ${failedCount}\n╰────────────❱\n©NakunBot`
                });
            } catch (e) {
                console.error(`Failed to send completion notification:`, e.message);
            }
        }

        console.log(`send Broadcast finished/stopped. Success: ${successCount}, Failed: ${failedCount}`);
    } catch (err) {
        console.error('Failed to init groupFetchAllParticipating:', err);
    } finally {
        global.sendState.isRunning = false;
    }
}

module.exports = {
    command: 'send',
    description: 'Fetches all group JIDs and broadcasts a message safely',
    dosendBroadcast,
    execute: async (sock, msg, args) => {
        if (!global.sendState) {
            global.sendState = {
                intervalId: null,
                lastMessage: '',
                delayMinutes: 0,
                isLooping: false
            };
        }
        const from = msg.key.remoteJid;
        const subCommand = args[0] ? args[0].toLowerCase() : '';

        if (subCommand === 'off') {
            global.sendState.isLooping = false; // Stop active loop
            if (global.sendState.intervalId) {
                clearInterval(global.sendState.intervalId);
                global.sendState.intervalId = null;
                await sock.sendMessage(from, { text: '╭❰ AUTO send ❱\n│ ⟡ Auto send telah dimatikan.\n╰────────────❱\n©NakunBot' }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: '╭❰ AUTO send ❱\n│ ⟡ Auto send memang sedang tidak berjalan.\n╰────────────❱\n©NakunBot' }, { quoted: msg });
            }
            return;
        }

        if (subCommand === 'edit') {
            const text = args.slice(1).join(' ');
            if (!text) {
                await sock.sendMessage(from, { text: '╭❰ ERROR ❱\n│ ⟡ Pesan tidak boleh kosong.\n│ ⟡ Penggunaan: .send edit <pesan>\n╰────────────❱\n©NakunBot' }, { quoted: msg });
                return;
            }
            try {
                saveMessage(text);
                global.sendState.lastMessage = text;
                await sock.sendMessage(from, { text: '╭❰ SUCCESS ❱\n│ ⟡ Pesan send berhasil diperbarui dan disimpan!\n╰────────────❱\n©NakunBot' }, { quoted: msg });
            } catch (err) {
                console.error('[ERR] .send edit error:', err);
                await sock.sendMessage(from, { text: `╭❰ ERROR ❱\n│ ⟡ Gagal menyimpan pesan.\n│ ⟡ Error: ${err.message}\n╰────────────❱\n©NakunBot` }, { quoted: msg });
            }
            return;
        }

        if (subCommand === 'help') {
            const tutorialText = `╭❰ TUTORIAL AUTO send ❱
│
│ 1. *Set Pesan*: Gunakan *.send edit [pesan]* 
│    untuk menyimpan pesan promosi Anda.
│
│ 2. *Set Jeda*: Gunakan *.senddelay [menit]* 
│    untuk mengatur interval pengiriman.
│    (Contoh: .senddelay 5)
│
│ 3. *Mulai send*: Gunakan *.send on* 
│    untuk mengaktifkan pengiriman otomatis.
│
│ 4. *Cek Status*: Gunakan *.cserver* 
│    untuk melihat apakah fitur send aktif.
│
│ 5. *Matikan*: Gunakan *.send off* 
│    untuk menghentikan pengiriman otomatis.
│
│ *Tips*: Pastikan bot sudah masuk ke 
│ grup-grup tujuan sebelum memulai.
╰────────────❱\n©NakunBot`;
            await sock.sendMessage(from, { text: tutorialText }, { quoted: msg });
            return;
        }

        if (subCommand === 'on') {
            let text = args.slice(1).join(' ');
            if (!text) {
                // Baca dari JSON jika tidak ada argumen pesan
                text = getSavedMessage();
            } else {
                // Simpan pesan baru jika disertakan setelah 'on'
                saveMessage(text);
            }

            if (!text) {
                await sock.sendMessage(from, { text: '╭❰ ERROR ❱\n│ ⟡ Belum ada pesan tersimpan.\n│ ⟡ Silakan gunakan: .send edit <pesan>\n╰────────────❱\n©NakunBot' }, { quoted: msg });
                return;
            }

            if (global.sendState.intervalId) {
                clearInterval(global.sendState.intervalId);
            }

            global.sendState.isLooping = true;
            global.sendState.lastMessage = text;
            const minutes = global.sendState.delayMinutes > 0 ? global.sendState.delayMinutes : 5;
            global.sendState.delayMinutes = minutes;
            const ms = minutes * 60 * 1000;

            global.sendState.callerId = from;

            await sock.sendMessage(from, { text: `╭❰ AUTO send ❱\n│ ⟡ Mengaktifkan Auto send!\n│ ⟡ Broadcast akan berjalan setiap ${minutes} menit.\n╰────────────❱\n©NakunBot` }, { quoted: msg });
            
            await dosendBroadcast(sock, text, from);

            global.sendState.intervalId = setInterval(async () => {
                if (global.sendState.isLooping) {
                    console.log(`[Interval loop triggered] Re-running background Auto send broadcast...`);
                    const freshText = getSavedMessage() || global.sendState.lastMessage;
                    await dosendBroadcast(sock, freshText, global.sendState.callerId);
                }
            }, ms);
            return;
        }

        // Shortcut untuk kirim 1x (tetap bisa pakai argument langsung)
        const text = args.join(' ');
        if (!text && subCommand !== 'list') {
            await sock.sendMessage(from, { text: '╭❰ INFO COMMAND ❱\n│ ⟡ .send help (Panduan Lengkap)\n│ ⟡ .send edit <pesan> (Simpan pesan)\n│ ⟡ .send on (Aktifkan send otomatis)\n│ ⟡ .send off (Matikan send otomatis)\n│ ⟡ .send <pesan> (Kirim 1x)\n╰────────────❱\n©NakunBot' }, { quoted: msg });
            return;
        }

        // Jika hanya .send <text>, kirim 1x
        if (text) {
            global.sendState.isLooping = true;
            global.sendState.lastMessage = text;
            global.sendState.callerId = from;
            await sock.sendMessage(from, { text: `╭❰ AUTO send ❱\n│ ⟡ Starting 1x Auto send broadcast...\n╰────────────❱\n©NakunBot` }, { quoted: msg });
            await dosendBroadcast(sock, text, from);
            if (!global.sendState.intervalId) {
                global.sendState.isLooping = false; 
            }
            await sock.sendMessage(from, { text: `╭❰ AUTO send ❱\n│ ⟡ Auto send broadcast completed!\n│ ⟡ (Hanya 1x pengiriman)\n╰────────────❱\n©NakunBot` }, { quoted: msg });
        }
    }
};
