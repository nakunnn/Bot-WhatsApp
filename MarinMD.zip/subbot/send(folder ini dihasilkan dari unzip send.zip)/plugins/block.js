module.exports = {
    command: 'block',
    description: 'Blokir nomor dengan alasan',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        
        let target;
        let reason;
        
        // Cek apakah user mereply pesan seseorang
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.participant;
        
        if (quoted) {
            // Jika reply: .block [alasan]
            target = quoted;
            reason = args.join(' ') || 'Tidak ada alasan spesifik.';
        } else if (args[0]) {
            // Jika manual: .block [nomer] [alasan]
            let num = args[0].replace(/[^0-9]/g, '');
            if (num.startsWith('0')) num = '62' + num.slice(1);
            if (!num.startsWith('62') && num.length < 10) {
                return sock.sendMessage(from, { text: "Nomor tidak valid. Gunakan format 62xxx atau 08xxx." }, { quoted: msg });
            }
            target = num + '@s.whatsapp.net';
            reason = args.slice(1).join(' ') || 'Tidak ada alasan spesifik.';
        } else {
            return sock.sendMessage(from, { 
                text: "Cara Penggunaan:\n1. Reply pesan lalu ketik: .block [alasan]\n2. Atau ketik: .block [nomor] [alasan]" 
            }, { quoted: msg });
        }

        try {
            const targetNum = target.split('@')[0];
            console.log(`[BLOCK] Memproses blokir untuk ${targetNum} dengan alasan: ${reason}`);

            // 1. Beritahu orang tersebut sebelum diblock (Text Normal)
            await sock.sendMessage(target, { 
                text: `Anda telah diblokir oleh admin.\nAlasan: ${reason}\n\n©NakunBot` 
            });
            
            // Beri jeda 1 detik agar pesan notifikasi terkirim dulu
            await new Promise(resolve => setTimeout(resolve, 1000));

            // 2. Eksekusi blokir
            await sock.updateBlockStatus(target, "block");
            
            // 3. Beritahu admin bahwa berhasil (Text Normal)
            await sock.sendMessage(from, { 
                text: `Berhasil memblokir ${targetNum}.\nAlasan: ${reason}` 
            }, { quoted: msg });

        } catch (err) {
            console.error('[BLOCK] Error:', err.message);
            sock.sendMessage(from, { text: `Gagal memblokir: ${err.message}` }, { quoted: msg });
        }
    }
};
