const { delay } = require('@whiskeysockets/baileys');

module.exports = {
    command: 'outclosed',
    description: 'Keluar otomatis dari grup yang tertutup (hanya admin yang bisa kirim pesan)',
    execute: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const subCommand = args[0] ? args[0].toLowerCase() : '';

        try {
            const groups = await sock.groupFetchAllParticipating();
            let closedGroups = [];
            
            // Filter grup yang tertutup & bot bukan admin
            for (const jid in groups) {
                // Kecualikan grup kontrol utama agar bot tidak keluar dari sana
                if (jid === '120363405675223209@g.us') continue;
                
                const metadata = groups[jid];
                if (metadata.announce) {
                    const isBotAdmin = metadata.participants.find(p => p.id === botId)?.admin;
                    if (!isBotAdmin) {
                        closedGroups.push({ jid, subject: metadata.subject });
                    }
                }
            }

            if (closedGroups.length === 0) {
                return await sock.sendMessage(from, { text: '╭❰ OUT CLOSED ❱\n│ ⟡ Tidak ditemukan grup tertutup (di mana bot bukan admin).\n╰────────────❱\n©NakunBot' }, { quoted: msg });
            }

            // Tahap Konfirmasi: .outclosed
            if (subCommand !== 'confirm') {
                const listGrup = closedGroups.map((g, i) => `${i + 1}. ${g.subject}`).join('\n');
                const confirmMsg = `╭❰ KONFIRMASI OUT ❱\n│ ⟡ Ditemukan ${closedGroups.length} grup tertutup:\n│\n${listGrup}\n│\n│ ⟡ Ketik *.outclosed confirm* untuk keluar dari semua grup di atas.\n╰────────────❱\n©NakunBot`;
                return await sock.sendMessage(from, { text: confirmMsg }, { quoted: msg });
            }

            // Tahap Eksekusi: .outclosed confirm
            await sock.sendMessage(from, { text: `╭❰ PROSES OUT ❱\n│ ⟡ Sedang keluar dari ${closedGroups.length} grup...\n│ ⟡ Mohon tunggu sebentar.\n╰────────────❱\n©NakunBot` }, { quoted: msg });

            let successCount = 0;
            for (const group of closedGroups) {
                try {
                    console.log(`[OUT CLOSED] Meninggalkan grup: ${group.subject} (${group.jid})`);
                    await sock.groupLeave(group.jid);
                    successCount++;
                    // Delay 2 detik antar grup untuk menghindari rate limit/ban
                    await delay(2000); 
                } catch (e) {
                    console.error(`[ERROR OUT CLOSED] Gagal keluar dari ${group.subject}:`, e.message);
                }
            }

            const finalMsg = `╭❰ HASIL OUT CLOSED ❱\n│ ⟡ Selesai!\n│ ⟡ Berhasil Keluar: ${successCount}\n│ ⟡ Gagal: ${closedGroups.length - successCount}\n╰────────────❱\n©NakunBot`;
            await sock.sendMessage(from, { text: finalMsg }, { quoted: msg });

        } catch (err) {
            console.error('Error in outclosed:', err);
            await sock.sendMessage(from, { text: '╭❰ ERROR ❱\n│ ⟡ Terjadi kesalahan saat memproses grup.\n╰────────────❱\n©NakunBot' }, { quoted: msg });
        }
    }
};
