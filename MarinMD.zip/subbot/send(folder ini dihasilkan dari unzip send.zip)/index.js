const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, getDevice, prepareWAMessageMedia } = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const readline = require("readline");

const os = require('os');
const { drive } = require('node-os-utils');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));
const CUSTOM_PAIRING_CODE = 'NAKUNBOT';


// --- FILTER LOG SISTEM (Mencegah log enkripsi/sesi Baileys bocor) ---
const originalLog = console.log;
const originalInfo = console.info;
const originalWarn = console.warn;
const originalError = console.error;

function logFilter(args) {
    const msg = args[0];
    if (typeof msg === 'string' && (
        msg.includes('Closing session') || 
        msg.includes('Closing open session') || 
        msg.includes('incoming prekey bundle') ||
        msg.includes('SessionEntry') ||
        msg.includes('pendingPreKey')
    )) return true;
    
    if (typeof msg === 'object' && msg !== null) {
        try {
            const str = JSON.stringify(msg);
            if (str && (str.includes('SessionEntry') || str.includes('pendingPreKey') || str.includes('registrationId'))) return true;
        } catch (e) {
            // Jika gagal stringify (circular), kita cek manual propertinya
            if (msg.registrationId || msg.pendingPreKey || msg.currentRatchet) return true;
        }
    }
    return false;
}

console.log = function () { if (!logFilter(arguments)) originalLog.apply(console, arguments); };
console.info = function () { if (!logFilter(arguments)) originalInfo.apply(console, arguments); };
console.warn = function () { if (!logFilter(arguments)) originalWarn.apply(console, arguments); };
console.error = function () { if (!logFilter(arguments)) originalError.apply(console, arguments); };

// --- SETTING WARNA CONSOLE ---
const c = {
    red: (text) => `\x1b[31m${text}\x1b[0m`,
    green: (text) => `\x1b[32m${text}\x1b[0m`,
    yellow: (text) => `\x1b[33m${text}\x1b[0m`,
    magenta: (text) => `\x1b[35m${text}\x1b[0m`,
    cyan: (text) => `\x1b[36m${text}\x1b[0m`,
    white: (text) => `\x1b[37m${text}\x1b[0m`,
};


let phoneNumber = '';
let reconnectAttempts = 0;
const MAX_RECONNECT = 10;
const msgRetryCounterCache = new Map();

global.sendState = {
    intervalId: null,
    lastMessage: '',
    delayMinutes: 0,
    isLooping: false
};

global.isFirstConnection = true;


try {
    global.totalPlugins = fs.readdirSync(path.join(__dirname, 'plugins')).filter(f => f.endsWith('.js')).length;
} catch (e) {
    global.totalPlugins = 0;
}

// --- HELPER STATUS & LAPORAN (Pindahkan ke plugins/cserver.js jika diperlukan oleh plugin tersebut) ---
const targetGroup = "120363405675223209@g.us";

async function init() {
    if (!fs.existsSync('./auth_info/creds.json')) {
        console.clear();
        console.log(c.cyan('[PAIR] Login - Pairing Code Mode'));
        console.log(c.yellow('Nomor WA Bot (628xxx): '));
        phoneNumber = await question('> ');
    }
    connectToWhatsApp();
}

async function getWaVersion() {
    const defaultVersion = [2, 3000, 1035194821];
    try {
        const axios = require('axios');
        const res = await axios.get('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json', { timeout: 5000 });
        if (res.data && Array.isArray(res.data.version)) {
            return res.data.version;
        }
    } catch (e) {
        try {
            const fetch = require('node-fetch');
            const response = await fetch('https://web.whatsapp.com/sw.js', {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': '*/*'
                },
                timeout: 5000
            });
            if (response.ok) {
                const data = await response.text();
                const match = data.match(/"client_revision":\s*(\d+)/);
                if (match && match[1]) {
                    return [2, 3000, parseInt(match[1])];
                }
            }
        } catch (err) {}
    }
    return defaultVersion;
}

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');
    const version = await getWaVersion();

    const sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: 'fatal' }),
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        connectTimeoutMs: 60000,
        qrTimeout: 40000,
        syncFullHistory: false,
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect: true,
        msgRetryCounterCache,
        retryRequestDelayMs: 250,
    });

    // --- INJECT CUSTOM_PAIRING_CODE ke Message ID & DEKORASI PESAN (sama seperti marin) ---
    sock.prepareWAMessageMedia = prepareWAMessageMedia;
    const originalSendMessage = sock.sendMessage;
    sock.sendMessage = async (jid, content, options = {}) => {
        if (!options.messageId) {
            options.messageId = CUSTOM_PAIRING_CODE + Math.random().toString(36).substring(2, 10).toUpperCase();
        }

        // Hanya tambahkan efek "Forwarded dari Channel" untuk pesan ke GRUP atau newsletter
        // Jangan tambahkan ke PM agar tidak ditolak oleh server WhatsApp
        const isGroupOrNewsletter = typeof jid === 'string' && (jid.endsWith('@g.us') || jid.endsWith('@newsletter'));
        if (isGroupOrNewsletter && content && typeof content === 'object' && !content.delete && !content.react && !content.pin) {
            if (content.interactiveMessage) {
                content.interactiveMessage.contextInfo = {
                    ...(content.interactiveMessage.contextInfo || {}),
                    isForwarded: true,
                    forwardingScore: 255,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.channelJid || '120363425454088709@newsletter',
                        newsletterName: global.channelName || 'NakunStore',
                        serverMessageId: 1
                    }
                };
            } else {
                content.contextInfo = {
                    ...(content.contextInfo || {}),
                    isForwarded: true,
                    forwardingScore: 255,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.channelJid || '120363425454088709@newsletter',
                        newsletterName: global.channelName || 'NakunStore',
                        serverMessageId: 1
                    }
                };
            }
        }

        return originalSendMessage.call(sock, jid, content, options);
    };

    // --- FIX updateBlockStatus: tambah 'list' wrapper yang dibutuhkan WA server ---
    sock.updateBlockStatus = async (jid, action) => {
        return sock.query({
            tag: 'iq',
            attrs: {
                xmlns: 'blocklist',
                to: 's.whatsapp.net',
                type: 'set',
                id: sock.generateMessageTag()
            },
            content: [{
                tag: 'list',
                attrs: {},
                content: [{
                    tag: 'item',
                    attrs: { action, jid }
                }]
            }]
        });
    };

    if (!state.creds.registered && phoneNumber) {
        console.log(c.yellow('\n[PAIR] Meminta kode...'));
        setTimeout(async () => {
            try {
                let code = await sock.requestPairingCode(phoneNumber.replace(/[^0-9]/g, ''), CUSTOM_PAIRING_CODE);
                code = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(c.magenta(`\n[PAIR] Kode: ${code}`));
                console.log(c.magenta('[PAIR] Masukkan kode ini di WhatsApp > Perangkat Tertaut > Tautkan Perangkat\n'));
            } catch (err) {
                console.log(c.red('[ERR] Gagal minta kode: ' + err.message));
            }
        }, 4000);
    }

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (update.qr) {
            console.log('[QR] Diabaikan.');
        }

        if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.output?.payload?.statusCode;
            const errorMsg = lastDisconnect?.error?.message || '';
            const reason = lastDisconnect?.error?.output?.payload?.message || errorMsg || 'Unknown';

            console.log(c.yellow(`[DC] ${statusCode} | ${reason}`));

            // Logout permanen — hapus sesi
            if (statusCode === DisconnectReason.loggedOut) {
                console.log(c.red('[LOGOUT] Hapus sesi...'));
                try {
                    fs.rmSync('./auth_info', { recursive: true, force: true });
                    console.log(c.yellow('[OK] Sesi dihapus. Restart bot.'));
                } catch (e) {
                    console.log(c.red('[ERR] ' + e.message));
                }
                return;
            }

            reconnectAttempts++;

            // Max reconnect — hapus sesi agar bisa pair ulang
            if (reconnectAttempts >= MAX_RECONNECT) {
                console.log(c.red(`[FATAL] ${MAX_RECONNECT}x gagal, hapus sesi...`));
                try {
                    fs.rmSync('./auth_info', { recursive: true, force: true });
                    console.log(c.yellow('[OK] Sesi dihapus. Restart bot.'));
                } catch (e) {
                    console.log(c.red('[ERR] ' + e.message));
                }
                reconnectAttempts = 0;
                return;
            }

            // Bad MAC — reset signal keys saja (jangan hapus creds)
            const isBadMAC = errorMsg.includes('Bad MAC') || errorMsg.includes('Bad Tag') || errorMsg.includes('hmac');
            if (isBadMAC) {
                console.log(c.yellow('[WARN] Bad MAC, reset signal keys...'));
                try {
                    const authDir = './auth_info';
                    if (fs.existsSync(authDir)) {
                        fs.readdirSync(authDir).forEach(file => {
                            if (file !== 'creds.json') fs.unlinkSync(path.join(authDir, file));
                        });
                    }
                } catch (e) { }
            }

            const delay = statusCode === 515 ? 5000 : 3000;
            console.log(c.yellow(`[RC] ${reconnectAttempts}/${MAX_RECONNECT} (${delay / 1000}s)...`));
            setTimeout(connectToWhatsApp, delay);

        } else if (connection === 'open') {
            reconnectAttempts = 0;
            console.log(c.green('[ON] NakunBot Hidup!'));

            // AUTO-AKTIFKAN AUTO REPLY SAAT STARTUP
            try {
                const replyPath = path.join(__dirname, 'plugins', 'reply.js');
                if (fs.existsSync(replyPath)) {
                    const dbDir = path.join(__dirname, 'database');
                    const dbPath = path.join(dbDir, 'autoreply.json');
                    if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
                    
                    let db = { status: true };
                    try {
                        if (fs.existsSync(dbPath)) {
                            db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
                        }
                    } catch (e) { }
                    
                    db.status = true; // Paksa jadi True
                    fs.writeFileSync(dbPath, JSON.stringify(db, null, 4));
                    console.log(c.cyan('[AR] Auto-Reply ON'));
                }
            } catch (err) {
                console.error('[ERR] Auto-Reply:', err.message);
            }
            
            if (global.isFirstConnection) {
                sock.sendMessage(targetGroup, {
                    text: `╭❰ NOTIFIKASI ❱\n│ - Status: NakunBot send Hidup\n│ - Waktu: ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}\n│ - Pengingat: Aktifkan .send & .reply\n╰────────────❱\n©NakunBot`
                });
                global.isFirstConnection = false;
            }

            // Jalankan background reporting dari cserver.js
            try {
                const cserver = require('./plugins/cserver');
                if (cserver.startReporting) {
                    cserver.startReporting(sock);
                }
            } catch (err) {
                console.error('[ERR] cserver:', err.message);
            }
        }
    });


    // --- PESAN MASUK ---
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        for (const msg of messages) {
            try {
                if (!msg || !msg.message) continue;

                const from = msg.key.remoteJid;
                if (!from || from === 'status@broadcast') continue;

                const isMe = msg.key.fromMe;
                if (isMe) continue;

                // (isMe check sudah cukup untuk skip echo pesan bot sendiri)

                // ----- AUTO-REPLY PM (background, tidak blokir loop) -----
                try {
                    const replyPluginPath = path.join(__dirname, 'plugins', 'reply.js');
                    if (fs.existsSync(replyPluginPath)) {
                        delete require.cache[require.resolve(replyPluginPath)];
                        const replyPlugin = require(replyPluginPath);
                        if (replyPlugin.handlePM) {
                            replyPlugin.handlePM(sock, msg).catch(err => {
                                console.error('[ERR] PM plugin async:', err.message);
                            });
                        }
                    }
                } catch (err) {
                    console.error('[ERR] PM plugin:', err.message);
                }

                const contentText = getMessageText(msg);
                const content = contentText.toLowerCase();
                const senderNum = from.split('@')[0];
                const isPM = from.endsWith('@s.whatsapp.net');
                const isTargetGroup = from === targetGroup;

                // Hanya proses pesan dari PM atau grup target
                if (!isPM && !isTargetGroup) continue;

                console.log(c.cyan(`[MSG] ${msg.pushName || '?'}: (${senderNum}) "${content}"`));

                // ----- FITUR AFK -----
                const sender = msg.key.participant || msg.key.remoteJid;
                const afkFile = path.join(__dirname, 'afk.json');
                if (fs.existsSync(afkFile) && !content.startsWith('.afk')) {
                    try {
                        let afkData = JSON.parse(fs.readFileSync(afkFile));
                        if (afkData[sender]) {
                            const afkTime = Date.now() - afkData[sender].time;
                            const hours = Math.floor(afkTime / 3600000);
                            const minutes = Math.floor((afkTime % 3600000) / 60000);
                            const seconds = Math.floor((afkTime % 60000) / 1000);
                            let timeString = '';
                            if (hours > 0) timeString += `${hours} jam `;
                            if (minutes > 0) timeString += `${minutes} menit `;
                            timeString += `${seconds} detik`;
                            if (!timeString.trim()) timeString = 'kurang dari 1 detik';
                            delete afkData[sender];
                            fs.writeFileSync(afkFile, JSON.stringify(afkData, null, 2));
                            await sock.sendMessage(from, {
                                text: `╭❰ AFK ❱\n│ ⟡ Kamu telah kembali dari AFK!\n│ ⟡ Total waktu AFK: ${timeString.trim()}\n╰────────────❱\n©NakunBot`
                            }, { quoted: msg });
                        }
                    } catch (e) {}
                }

                // ----- COMMAND HANDLER -----
                if (content.startsWith('.')) {
                    const argsList = contentText.trim().split(/ +/);
                    const command = argsList[0].slice(1).toLowerCase();
                    const args = argsList.slice(1);
                    const pluginPath = path.join(__dirname, 'plugins', `${command}.js`);

                    // Cek maintenance
                    const maintenancePath = path.join(__dirname, 'database', 'maintenance.json');
                    let isMaintenance = false;
                    try {
                        if (fs.existsSync(maintenancePath)) {
                            isMaintenance = JSON.parse(fs.readFileSync(maintenancePath, 'utf8')).status;
                        }
                    } catch (e) {}

                    if (isMaintenance && command !== 'maintenance') {
                        await sock.sendMessage(from, {
                            text: `╭❰ MAINTENANCE ❱\n│ ⟡ Mohon maaf, bot sedang dalam perbaikan.\n│ ⟡ Silakan coba beberapa saat lagi.\n╰────────────❱\n©NakunBot`
                        }, { quoted: msg });
                        continue;
                    }

                    if (fs.existsSync(pluginPath)) {
                        try {
                            delete require.cache[require.resolve(pluginPath)];
                            const plugin = require(pluginPath);
                            await plugin.execute(sock, msg, args);
                            console.log(c.green(`[OK] .${command}`));
                        } catch (err) {
                            console.error(c.red(`[ERR] .${command}:`), err.message);
                            try {
                                await sock.sendMessage(from, {
                                    text: `╭❰ SYSTEM ERROR ❱\n│ ⟡ Terjadi kesalahan saat menjalankan .${command}.\n│ ⟡ Error: ${err.message}\n╰────────────❱\n©NakunBot`
                                }, { quoted: msg });
                            } catch (sendErr) {}
                        }
                    } else {
                        console.log(c.yellow(`[MISS] plugin .${command} tidak ditemukan`));
                    }
                }
            } catch (outerErr) {
                console.error('[ERR] message handler:', outerErr.message);
            }
        }
    });
}

function getMessageText(msg) {
    if (!msg || !msg.message) return "";
    let m = msg.message;
    if (m.ephemeralMessage) m = m.ephemeralMessage.message;
    if (m.viewOnceMessage) m = m.viewOnceMessage.message;
    if (m.viewOnceMessageV2) m = m.viewOnceMessageV2.message;
    if (m.documentWithCaptionMessage) m = m.documentWithCaptionMessage.message;
    
    return m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || m.documentMessage?.caption || "";
}

init();