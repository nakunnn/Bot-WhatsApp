const { imageToWebp, addExif } = require('./Connection/database/exif');
const fs = require('fs');
const axios = require('axios');

async function test() {
    try {
        const url = 'https://api.nexadev.my.id/api/canvas/brat?text=Test%20Sticker';
        console.log('Fetching image from:', url);
        const res = await axios.get(url, { responseType: 'arraybuffer' });
        
        console.log('Converting to WebP...');
        const webpBuffer = await imageToWebp(res.data);
        console.log('WebP buffer length:', webpBuffer.length);
        
        console.log('Adding Exif metadata...');
        const exifWebp = await addExif(webpBuffer, 'MarinMD', 'Nakun');
        console.log('Exif WebP buffer length:', exifWebp.length);
        
        fs.writeFileSync('test_output_sticker.webp', exifWebp);
        console.log('Saved to test_output_sticker.webp successfully!');
    } catch (e) {
        console.error('Error:', e);
    }
}

test();
