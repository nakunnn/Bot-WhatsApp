const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    delay,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');
const chalk = require('chalk');

// --- Konfigurasi ---
const SESSION_NAME = 'auth_info_checker';
const INPUT_FILE = 'numbers.txt';
let isProcessing = false;

// --- Logika Deteksi Provider ---
function getProvider(number) {
    let clean = number.replace(/[^0-9]/g, '');
    if (clean.startsWith('62')) {
        clean = '0' + clean.slice(2);
    } else if (clean.startsWith('8')) {
        clean = '0' + clean;
    }
    
    const prefix = clean.slice(0, 4);
    const providerMap = {
        'Telkomsel': ['0811', '0812', '0813', '0821', '0822', '0823', '0851', '0852', '0853'],
        'Indosat': ['0814', '0815', '0816', '0857', '0858'],
        'XL': ['0817', '0818', '0819', '0859', '0877', '0878'],
        'Axis': ['0831', '0832', '0833', '0838'],
        'Tri': ['0895', '0896', '0897', '0898', '0899'],
        'Smartfren': ['0881', '0882', '0883', '0884', '0885', '0886', '0887', '0888', '0889']
    };

    for (const [provider, prefixes] of Object.entries(providerMap)) {
        if (prefixes.includes(prefix)) return provider;
    }
    return 'Lainnya';
}

function formatJid(number) {
    let clean = number.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) clean = '62' + clean.slice(1);
    if (clean.startsWith('8')) clean = '62' + clean;
    return clean.endsWith('@s.whatsapp.net') ? clean : clean + '@s.whatsapp.net';
}

async function start() {
    const { state, saveCreds } = await useMultiFileAuthState(SESSION_NAME);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
        },
        printQRInTerminal: true,
        browser: ['WA-Checker', 'Chrome', '1.0.0']
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) console.log(chalk.yellow('[!] Scan QR untuk login...'));

        if (connection === 'close') {
            const reason = lastDisconnect?.error?.output?.statusCode;
            if (reason !== DisconnectReason.loggedOut) {
                start();
            } else {
                console.log(chalk.red('[!] Sesi berakhir. Hapus folder ' + SESSION_NAME + ' dan scan ulang.'));
                process.exit(1);
            }
        } else if (connection === 'open') {
            console.log(chalk.green('✅ WhatsApp Terhubung!'));
            if (!isProcessing) {
                isProcessing = true;
                await runChecker(sock);
            }
        }
    });
}

async function runChecker(sock) {
    if (!fs.existsSync(INPUT_FILE)) {
        console.log(chalk.red(`[Error] File ${INPUT_FILE} tidak ditemukan!`));
        process.exit(1);
    }

    const numbers = fs.readFileSync(INPUT_FILE, 'utf-8')
        .split('\n')
        .map(n => n.trim())
        .filter(n => n.length >= 9);

    console.log(chalk.blue(`[System] Memproses ${numbers.length} nomor...\n`));

    for (const number of numbers) {
        const provider = getProvider(number);
        const jid = formatJid(number);
        const display = jid.split('@')[0];

        try {
            const [exists] = await sock.onWhatsApp(jid);
            const statusText = exists?.exists ? chalk.green('Terdaftar') : chalk.red('Tidak terdaftar');
            
            console.log(chalk.cyan('-----------------------'));
            console.log(chalk.bold('Number   : ') + display);
            console.log(chalk.bold('Provider : ') + provider);
            console.log(chalk.bold('Status   : ') + statusText);
            console.log(chalk.cyan('-----------------------'));

        } catch (e) {
            console.log(chalk.cyan('-----------------------'));
            console.log(chalk.bold('Number   : ') + display);
            console.log(chalk.bold('Provider : ') + provider);
            console.log(chalk.bold('Status   : ') + chalk.yellow('Timeout/Error'));
            console.log(chalk.cyan('-----------------------'));
        }

        // Random Delay 3-7 detik
        await delay(Math.floor(Math.random() * 4000) + 3000);
    }

    console.log(chalk.green('\n✅ Pengecekan Selesai!'));
    process.exit(0);
}

start().catch(err => console.error(err));
