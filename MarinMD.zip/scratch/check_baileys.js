const Baileys = require("@whiskeysockets/baileys");
console.log("Keys:", Object.keys(Baileys));
if (Baileys.makeInMemoryStore) {
    console.log("makeInMemoryStore is present");
} else {
    console.log("makeInMemoryStore is NOT present");
}
