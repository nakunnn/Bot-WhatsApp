const { prepareWAMessageMedia } = require("@whiskeysockets/baileys");

async function test() {
    try {
        const result = await prepareWAMessageMedia({ 
            image: { url: "./Connection/foto/banner1.jpeg" }
        }, { 
            upload: async () => ({ url: "test" }) 
        });
        console.log("Success:", !!result);
    } catch (e) {
        console.log("Error:", e.message);
    }
}
test();
