const { prepareWAMessageMedia } = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");

async function test() {
    try {
        const result = await prepareWAMessageMedia({ 
            image: fs.readFileSync("./Connection/foto/banner1.jpeg") 
        }, { 
            upload: async () => ({ url: "test" }) 
        });
        console.log("Success:", result);
    } catch (e) {
        console.log("Error:", e);
    }
}
test();
