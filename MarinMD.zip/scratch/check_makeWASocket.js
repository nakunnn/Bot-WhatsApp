const { default: makeWASocket } = require("@whiskeysockets/baileys");
console.log("makeWASocket toString:");
console.log(makeWASocket.toString().substring(0, 1000));
