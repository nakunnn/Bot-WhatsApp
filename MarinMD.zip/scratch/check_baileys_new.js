const Baileys = require("baileys");
console.log("Keys:", Object.keys(Baileys));
if (Baileys.makeInMemoryStore) {
    console.log("makeInMemoryStore is present in 'baileys'");
} else {
    console.log("makeInMemoryStore is NOT present in 'baileys'");
}
