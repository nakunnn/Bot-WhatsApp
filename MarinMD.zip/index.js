const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, getDevice, Browsers, makeCacheableSignalKeyStore, getContentType, prepareWAMessageMedia, downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const fs = require('fs');
require('./config');
const path = require('path');
const readline = require("readline");
const os = require('os');
const { drive } = require('node-os-utils');
const { performance } = require('perf_hooks');

/**
 * Runtime helper
 * @param {Number} seconds 
 * @returns {String}
 */
function runtime(seconds) {
	seconds = Number(seconds);
	var d = Math.floor(seconds / (3600 * 24));
	var h = Math.floor(seconds % (3600 * 24) / 3600);
	var m = Math.floor(seconds % 3600 / 60);
	var s = Math.floor(seconds % 60);
	var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
	var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
	var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
	var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
	return dDisplay + hDisplay + mDisplay + sDisplay;
}

// --- LOAD .env FILE (untuk SPOTIFY_CLIENT_ID, dll) ---
try {
    const envPath = path.join(__dirname, '.env');
    if (fs.existsSync(envPath)) {
        fs.readFileSync(envPath, 'utf8').split('\n').forEach(line => {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('#')) return;
            const [key, ...val] = trimmed.split('=');
            if (key && val.length) process.env[key.trim()] = val.join('=').trim();
        });
    }
} catch (_) { }

// Initialize native subbot manager
require('./lib/pm2api').init().catch(console.error);

// --- RETRY CACHE UNTUK HANDLE BAD MAC ---
const msgRetryCounterCache = new Map();
let reconnectAttempts = 0;
const MAX_RECONNECT = 10;

// --- CUSTOM PAIRING CODE (8 karakter, digunakan saat login) ---
const CUSTOM_PAIRING_CODE = 'NAKUNBOT';

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

// --- FILTER LOG SISTEM (Mencegah log enkripsi/sesi Baileys bocor) ---
const originalLog = console.log;
const originalInfo = console.info;
const originalWarn = console.warn;
const originalError = console.error;

function logFilter(args) {
    const msg = args[0];
    if (typeof msg === 'string' && (
        msg.includes('Closing session') ||
        msg.includes('Closing open session') ||
        msg.includes('incoming prekey bundle') ||
        msg.includes('SessionEntry') ||
        msg.includes('pendingPreKey')
    )) return true;

    if (typeof msg === 'object' && msg !== null) {
        try {
            const str = JSON.stringify(msg);
            if (str && (str.includes('SessionEntry') || str.includes('pendingPreKey') || str.includes('registrationId'))) return true;
        } catch (e) {
            // Jika gagal stringify (circular), kita cek manual propertinya
            if (msg.registrationId || msg.pendingPreKey || msg.currentRatchet) return true;
        }
    }
    return false;
}

console.log = function () { if (!logFilter(arguments)) originalLog.apply(console, arguments); };
console.info = function () { if (!logFilter(arguments)) originalInfo.apply(console, arguments); };
console.warn = function () { if (!logFilter(arguments)) originalWarn.apply(console, arguments); };
console.error = function () { if (!logFilter(arguments)) originalError.apply(console, arguments); };

// --- SETTING WARNA CONSOLE ---
const c = {
    red: (text) => `\x1b[31m${text}\x1b[0m`,
    green: (text) => `\x1b[32m${text}\x1b[0m`,
    yellow: (text) => `\x1b[33m${text}\x1b[0m`,
    magenta: (text) => `\x1b[35m${text}\x1b[0m`,
    cyan: (text) => `\x1b[36m${text}\x1b[0m`,
    white: (text) => `\x1b[37m${text}\x1b[0m`,
};


let phoneNumber = '';

global.unceState = {
    intervalId: null,
    lastMessage: '',
    delayMinutes: 0,
    isLooping: false
};

global.jpmState = {
    intervalId: null,
    lastMessage: '',
    delayMinutes: 0,
    isLooping: false,
    callerId: null
};

global.isFirstConnection = true;
global.games = {};
global.typingState = {};


try {
    global.totalPlugins = fs.readdirSync(path.join(__dirname, 'plugins')).filter(f => f.endsWith('.js')).length;
} catch (e) {
    global.totalPlugins = 0;
}

// --- HELPER STATUS & LAPORAN (Pindahkan ke plugins/cserver.js jika diperlukan oleh plugin tersebut) ---
const targetGroup = "120363405675223209@g.us";

async function init() {
    if (!fs.existsSync('./auth_info/creds.json')) {
        console.clear();
        console.log(c.cyan('[PAIR] Login - Pairing Code Mode'));
        console.log(c.yellow('Nomor WA Bot (628xxx): '));
        phoneNumber = await question('> ');
    }
    connectToWhatsApp();
}

async function getWaVersion() {
    const defaultVersion = [2, 3000, 1035194821];
    try {
        const axios = require('axios');
        const res = await axios.get('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json', { timeout: 5000 });
        if (res.data && Array.isArray(res.data.version)) {
            return res.data.version;
        }
    } catch (e) {
        try {
            const fetch = require('node-fetch');
            const response = await fetch('https://web.whatsapp.com/sw.js', {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': '*/*'
                },
                timeout: 5000
            });
            if (response.ok) {
                const data = await response.text();
                const match = data.match(/"client_revision":\s*(\d+)/);
                if (match && match[1]) {
                    return [2, 3000, parseInt(match[1])];
                }
            }
        } catch (err) {}
    }
    return defaultVersion;
}

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');
    const version = await getWaVersion();
    const logger = pino({ level: 'fatal' });

    const sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: false,
        logger,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        connectTimeoutMs: 60000,
        qrTimeout: 40000,
        syncFullHistory: false,
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect: true,
        msgRetryCounterCache,
        retryRequestDelayMs: 250,
    });

    // --- CUSTOM: Inject CUSTOM_PAIRING_CODE ke Message ID ---
    const originalSendMessage = sock.sendMessage;
    sock.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };

    sock.sendMessage = async (jid, content, options = {}) => {
        if (!options.messageId) {
            options.messageId = CUSTOM_PAIRING_CODE + Math.random().toString(36).substring(2, 10).toUpperCase();
        }

        // Otomatis tambahkan efek "Forwarded dari Channel" ke semua pesan teks/media/interactiveMessage dll.
        if (content && typeof content === 'object' && !content.delete && !content.react && !content.pin) {
            if (content.interactiveMessage) {
                content.interactiveMessage.contextInfo = {
                    ...(content.interactiveMessage.contextInfo || {}),
                    isForwarded: true,
                    forwardingScore: 255,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.channelJid || '120363311910609503@newsletter',
                        newsletterName: global.channelName || 'Marin MD Updates',
                        serverMessageId: 1
                    }
                };
            } else {
                content.contextInfo = {
                    ...(content.contextInfo || {}),
                    isForwarded: true,
                    forwardingScore: 255,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.channelJid || '120363311910609503@newsletter',
                        newsletterName: global.channelName || 'Marin MD Updates',
                        serverMessageId: 1
                    }
                };
            }
        }

        return originalSendMessage.call(sock, jid, content, options);
    };

    sock.sendImageAsSticker = async (jid, media, quoted, options = {}) => {
        const { writeExifImg } = require('./Connection/database/exif');
        let stickerPath = await writeExifImg(media, {
            packname: options.packname || global.packname,
            author: options.author || global.author,
            ...options
        });
        await sock.sendMessage(jid, { sticker: { url: stickerPath } }, { quoted });
        try {
            fs.unlinkSync(stickerPath);
        } catch (e) {}
    };

    sock.sendVideoAsSticker = async (jid, media, quoted, options = {}) => {
        const { writeExifVid } = require('./Connection/database/exif');
        let stickerPath = await writeExifVid(media, {
            packname: options.packname || global.packname,
            author: options.author || global.author,
            ...options
        });
        await sock.sendMessage(jid, { sticker: { url: stickerPath } }, { quoted });
        try {
            fs.unlinkSync(stickerPath);
        } catch (e) {}
    };

    if (!state.creds.registered && phoneNumber) {
        console.log(c.yellow('\n[PAIR] Meminta kode...'));
        setTimeout(async () => {
            try {
                let code = await sock.requestPairingCode(phoneNumber.replace(/[^0-9]/g, ''), CUSTOM_PAIRING_CODE);
                code = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(c.magenta(`\n[PAIR] Kode Anda: ${code}`));
                console.log(c.magenta('[PAIR] Masukkan kode ini di WhatsApp > Perangkat Tertaut > Tautkan Perangkat > Tautkan dengan nomor telepon saja\n'));
            } catch (err) {
                console.log(c.red('[ERR] Gagal minta kode. Cek nomor bot: ' + err.message));
            }
        }, 4000);
    }

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        // QR Code dinonaktifkan - hanya pairing code yang digunakan
        if (update.qr) {
            console.log(c.yellow('[QR] Diabaikan, pakai pairing code.'));
        }

        if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.output?.payload?.statusCode;
            const errorMsg = lastDisconnect?.error?.message || '';
            const reason = lastDisconnect?.error?.output?.payload?.message || errorMsg || 'Unknown';

            console.log(c.yellow(`[DC] ${statusCode} | ${reason}`));

            // Cek apakah error Bad MAC / session corrupt
            const isBadMAC = errorMsg.includes('Bad MAC') || errorMsg.includes('Bad Tag') || errorMsg.includes('hmac');

            if (statusCode === DisconnectReason.loggedOut) {
                console.log(c.red('[LOGOUT] Hapus sesi...'));
                try {
                    fs.rmSync('./auth_info', { recursive: true, force: true });
                    console.log(c.yellow('[OK] Sesi dihapus. Restart bot.'));
                } catch (e) {
                    console.log(c.red('[ERR] ' + e.message));
                }
                return;
            }

            reconnectAttempts++;

            if (reconnectAttempts >= MAX_RECONNECT) {
                console.log(c.red(`[FATAL] ${MAX_RECONNECT}x gagal, hapus sesi...`));
                try {
                    fs.rmSync('./auth_info', { recursive: true, force: true });
                    console.log(c.yellow('[OK] Sesi dihapus. Restart bot.'));
                } catch (e) {
                    console.log(c.red('[ERR] ' + e.message));
                }
                reconnectAttempts = 0;
                return;
            }

            if (isBadMAC) {
                console.log(c.yellow('[WARN] Bad MAC, reset signal keys...'));
                try {
                    const authDir = './auth_info';
                    if (fs.existsSync(authDir)) {
                        const files = fs.readdirSync(authDir);
                        for (const file of files) {
                            if (file !== 'creds.json') {
                                fs.unlinkSync(path.join(authDir, file));
                            }
                        }
                        console.log(c.yellow('[OK] Signal keys direset.'));
                    }
                } catch (e) {
                    console.log(c.red('[ERR] ' + e.message));
                }
            }

            const delay = statusCode === 515 ? 5000 : 3000;
            console.log(c.yellow(`[RC] ${reconnectAttempts}/${MAX_RECONNECT} (${delay / 1000}s)`));
            setTimeout(connectToWhatsApp, delay);
        } else if (connection === 'open') {
            reconnectAttempts = 0;
            console.log(c.green('\n[ON] NakunBot Hidup!\n'));

            // AUTO-AKTIFKAN AUTO REPLY SAAT STARTUP
            try {
                const replyPath = path.join(__dirname, 'plugins', 'reply.js');
                if (fs.existsSync(replyPath)) {
                    const dbDir = path.join(__dirname, 'database');
                    const dbPath = path.join(dbDir, 'autoreply.json');
                    if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

                    const defaultMsg = 'Halo! Pesan kamu sudah diterima.\nMohon tunggu balasan dari admin.\n\n©NakunStore';
                    let db = { status: true, message: defaultMsg };
                    try {
                        if (fs.existsSync(dbPath)) {
                            const existing = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
                            db.status = true; // Paksa jadi True
                            db.message = existing.message || defaultMsg; // Pakai pesan yg sudah di-edit, atau default
                        }
                    } catch (e) { }

                    fs.writeFileSync(dbPath, JSON.stringify(db, null, 4));
                    console.log(c.cyan('[AR] Auto-Reply ON'));
                }
            } catch (err) {
                console.error('[ERR] Auto-Reply: ' + err.message);
            }

            if (global.isFirstConnection) {
                sock.sendMessage(targetGroup, {
                    text: `╭❰ NOTIFIKASI ❱\n│ - Status: NakunBot UNCE Hidup\n│ - Waktu: ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}\n│ - Pengingat: Aktifkan .unce & .reply\n╰────────────❱\n©NakunStore`
                });
                global.isFirstConnection = false;
            }

            // Jalankan background reporting dari cserver.js
            try {
                const cserver = require('./plugins/cserver');
                if (cserver.startReporting) {
                    cserver.startReporting(sock);
                }
            } catch (err) {
                console.error('[ERR] BG Report: ' + err.message);
            }

            // Jalankan auto-monitor dari terminal.js (laporan sistem per jam ke admin)
            try {
                const terminal = require('./plugins/terminal');
                // Kirim ke nomor bot sendiri (self-chat sebagai log) atau ganti dengan JID admin
                const monitorTarget = sock.user?.id?.split(':')[0] + '@s.whatsapp.net';
                terminal.startAutoMonitor(sock, monitorTarget);
            } catch (err) {
                console.error('[ERR] Auto-Monitor: ' + err.message);
            }

            // --- RE-START TYPING FOREVER ---
            try {
                const typingDbPath = path.join(__dirname, 'database', 'typing.json');
                if (fs.existsSync(typingDbPath)) {
                    const typingData = JSON.parse(fs.readFileSync(typingDbPath, 'utf8'));
                    for (const jid of typingData) {
                        if (global.typingState[jid]) clearInterval(global.typingState[jid]);
                        
                        // Kirim pertama kali
                        sock.sendPresenceUpdate('composing', jid).catch(() => {});
                        
                        global.typingState[jid] = setInterval(async () => {
                            try {
                                await sock.sendPresenceUpdate('composing', jid);
                            } catch (e) {
                                // Jika error (mungkin bot DC), kita abaikan saja, nanti restart saat ON lagi
                            }
                        }, 25000);
                        console.log(c.cyan(`[TYPING] Started for ${jid}`));
                    }
                }
            } catch (err) {
                console.error('[ERR] Restart Typing: ' + err.message);
            }
        }
    });


    // --- PESAN MASUK ---
    sock.ev.on('messages.upsert', async m => {
        if (m.type === 'append') return;
        const msg = m.messages[0];
        if (!msg || !msg.message) return;

        // FILTER ANTI-LOOP: Abaikan pesan yang ID-nya mengandung 'NAKUNBOT'
        if (msg.key.id && msg.key.id.includes('NAKUNBOT')) {
            return;
        }

        const from = msg.key.remoteJid;
        if (!from || from === 'status@broadcast') return;

        // FILTER: Skip pesan protokol WA (read receipt, reaction, dll)
        const msgType = Object.keys(msg.message)[0];
        if (['protocolMessage', 'reactionMessage', 'senderKeyDistributionMessage', 'messageContextInfo'].includes(msgType)) return;

        const isMe = msg.key.fromMe;
        const isGroup = from.endsWith('@g.us');
        // PM bisa @s.whatsapp.net ATAU @lid (Baileys v6+)
        const isPMcheck = !isGroup;

        // DEBUG: Log pesan non-grup (hanya pesan real, bukan protokol)
        if (isPMcheck && !isMe) {
            console.log(`[PM] ${msg.pushName || '?'} (${from})`);
        }

        // DETEKSI FORWARD DARI CHANNEL UNTUK MENDAPATKAN JID
        try {
            const contextInfo = msg.message[msgType]?.contextInfo;
            if (contextInfo?.forwardedNewsletterMessageInfo) {
                const info = contextInfo.forwardedNewsletterMessageInfo;
                console.log(c.green(`\n[CHANNEL DETECTED] JID: ${info.newsletterJid} | Name: ${info.newsletterName}\n`));
                if (isPMcheck && !isMe) {
                    await sock.sendMessage(from, { 
                        text: `╭❰ JID CHANNEL TERDETEKSI ❱\n│ ⟡ Nama : ${info.newsletterName}\n│ ⟡ JID  : ${info.newsletterJid}\n╰────────────❱\nSilakan salin (copy) JID di atas dan masukkan ke file config.js Anda!` 
                    }, { quoted: msg });
                }
            }
        } catch (e) {}

        // ----- FITUR AUTO-REPLY PM -----
        if (isPMcheck) {
            try {
                const replyPluginPath = path.join(__dirname, 'plugins', 'reply.js');
                if (fs.existsSync(replyPluginPath)) {
                    delete require.cache[require.resolve(replyPluginPath)];
                    const replyPlugin = require(replyPluginPath);
                    if (replyPlugin.handlePM) {
                        await replyPlugin.handlePM(sock, msg);
                    }
                }
            } catch (err) {
                console.error('[ERR] AR: ' + err.message);
            }
        }
        // -----------------------------------------------------------

        // ─── RVO: Deteksi & kirim ulang media viewOnceMessageV2 ───
        try {
            const { handleRVO } = require('./plugins/rvo');
            const wasRVO = await handleRVO(sock, msg);
            if (wasRVO) return; // Sudah dihandle, skip sisa pipeline
        } catch (rvoErr) {
            console.error('[ERR] RVO: ' + rvoErr.message);
        }
        // ─────────────────────────────────────────────────────────
        
        let contentText = msg.message.conversation || msg.message.extendedTextMessage?.text || msg.message.imageMessage?.caption || "";
        let content = contentText.toLowerCase();

        // Skip pesan dari bot sendiri KECUALI command
        if (isMe && !contentText.startsWith('.')) return;

        if (!content) return;

        // Hanya proses command yang diawali '.'
        if (!content.startsWith('.')) return;

        const targetGroup = "120363405675223209@g.us";
        const isPM = isPMcheck;
        const isTargetGroup = from === targetGroup;

        // Allow commands if in Target Group or if sender is Owner in PM
        if (!isPM && !isTargetGroup) return;

        // Log Pesan Masuk
        console.log(c.cyan(`[MSG] ${msg.pushName || '?'}: "${content}"`));

        const sender = msg.key.participant || msg.key.remoteJid;

        if (content.startsWith('.')) {
            const argsList = contentText.trim().split(/ +/);
            const command = argsList[0].slice(1).toLowerCase();
            const args = argsList.slice(1);
            const pluginPath = path.join(__dirname, 'plugins', `${command}.js`);

            // --- CEK MODE MAINTENANCE ---
            const maintenancePath = path.join(__dirname, 'database', 'maintenance.json');
            let isMaintenance = false;
            try {
                if (fs.existsSync(maintenancePath)) {
                    const mntData = JSON.parse(fs.readFileSync(maintenancePath, 'utf8'));
                    isMaintenance = mntData.status;
                }
            } catch (e) { }

            if (isMaintenance && command !== 'maintenance') {
                const teksMaint = `╭❰ MAINTENANCE ❱
│ ⟡ Mohon maaf, bot sedang dalam perbaikan.
│ ⟡ Silakan coba beberapa saat lagi.
╰────────────❱
©NakunStore`;
                return sock.sendMessage(from, { text: teksMaint }, { quoted: msg });
            }
            // ----------------------------

            // Auth checks
            const owners = JSON.parse(fs.readFileSync("./Connection/database/owner.json"));
            const murbugs = JSON.parse(fs.readFileSync("./Connection/database/premium.json"));
            const isOwner = owners.includes(sender) || msg.key.fromMe;
            const isMurbug = murbugs.includes(sender) || isOwner;

            // PM hanya untuk owner
            if (isPM && !isOwner) return;

            if (fs.existsSync(pluginPath)) {
                try {
                    delete require.cache[require.resolve(pluginPath)];
                    const plugin = require(pluginPath);

                    // Helpers
                    const reply = (text) => sock.sendMessage(from, { text: String(text) }, { quoted: msg });
                    const react = (jid, emoji) => sock.sendMessage(jid, { react: { text: emoji, key: msg.key } });

                    const context = {
                        args,
                        q: args.join(' '),
                        prefix: '.',
                        command,
                        isOwner,
                        isMurbug,
                        reply,
                        react,
                        pushname: msg.pushName || 'User',
                        runtime,
                        performance: performance.now(),
                        quoted: msg.message.extendedTextMessage?.contextInfo?.quotedMessage || null
                    };

                    await plugin.execute(sock, msg, context);
                    console.log(c.green(`[OK] .${command}`));
                } catch (err) {
                    console.error(c.red(`[ERR] .${command}:`), err.message);
                }
            }
        }
    });
}

init();