const { Markup } = require('telegraf');
const path = require('path');
const fs = require('fs');

module.exports = (bot) => {
    const { sendMainMenu, toSansBold } = require('../lib/menu');
    const userStates = new Map();

    // Load Sherlock database
    const dataPath = path.join(__dirname, '../sherlock-master/sherlock_project/resources/data.json');
    let siteData = {};
    try {
        if (fs.existsSync(dataPath)) {
            const raw = fs.readFileSync(dataPath, 'utf-8');
            siteData = JSON.parse(raw);
            delete siteData['$schema'];
        }
    } catch (e) {
        console.error('Failed to load Sherlock data.json:', e);
    }

    // Helper to shorten URL using is.gd (no token required)
    async function shortenUrl(longUrl) {
        try {
            const res = await fetch(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(longUrl)}`, {
                signal: AbortSignal.timeout(4000)
            });
            if (res.ok) {
                const shortUrl = await res.text();
                if (shortUrl && shortUrl.startsWith('http')) {
                    return shortUrl.trim();
                }
            }
        } catch (e) {
            // Ignore
        }
        return longUrl;
    }

    // Helper to deep interpolate payload parameters
    function interpolate(obj, username) {
        if (typeof obj === 'string') {
            return obj.replace(/\{\}/g, username);
        } else if (Array.isArray(obj)) {
            return obj.map(item => interpolate(item, username));
        } else if (obj !== null && typeof obj === 'object') {
            const res = {};
            for (const key in obj) {
                res[key] = interpolate(obj[key], username);
            }
            return res;
        }
        return obj;
    }

    // Helper to check username existence on a site using Sherlock rules
    async function checkUsernameOnSite(username, siteName, info) {
        const url = info.url.replace('{}', encodeURIComponent(username));
        const probeUrl = info.urlProbe ? info.urlProbe.replace('{}', encodeURIComponent(username)) : url;
        const errorTypes = Array.isArray(info.errorType) ? info.errorType : [info.errorType];

        // Regex check validation
        if (info.regexCheck) {
            try {
                const regex = new RegExp(info.regexCheck);
                if (!regex.test(username)) {
                    return { siteName, url, isClaimed: false };
                }
            } catch (e) {
                // Ignore regex parsing error
            }
        }

        const options = {
            method: info.request_method || (errorTypes.includes('status_code') && !info.request_payload ? 'HEAD' : 'GET'),
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
                ...(info.headers || {})
            },
            signal: AbortSignal.timeout(5000) // 5s timeout
        };

        if (info.request_payload) {
            const bodyObj = interpolate(info.request_payload, username);
            options.body = JSON.stringify(bodyObj);
            options.headers['Content-Type'] = 'application/json';
        }

        try {
            const res = await fetch(probeUrl, options);
            let isClaimed = true;

            // 1. Basic Status check (Sherlock assumes >=300 or <200 is available)
            if (res.status < 200 || res.status >= 300) {
                isClaimed = false;
            }

            // 2. Specific status code check
            if (errorTypes.includes('status_code')) {
                const errorCodes = info.errorCode;
                if (errorCodes !== undefined) {
                    const codes = Array.isArray(errorCodes) ? errorCodes : [errorCodes];
                    if (codes.includes(res.status)) {
                        isClaimed = false;
                    }
                }
            }

            // 3. Response body message check
            if (isClaimed && errorTypes.includes('message')) {
                const body = await res.text();
                const errorMsgs = Array.isArray(info.errorMsg) ? info.errorMsg : [info.errorMsg];
                const hasErrorMsg = errorMsgs.some(msg => body.includes(msg));
                if (hasErrorMsg) {
                    isClaimed = false;
                }
            }

            return { siteName, url, isClaimed };
        } catch (e) {
            return { siteName, url, isClaimed: false };
        }
    }

    // OSINT Menu Trigger
    bot.action('osint_menu', async (ctx) => {
        const { getUserByTelegramId } = require('../lib/db');
        const userData = await getUserByTelegramId(ctx.from.id);
        if (!userData) return ctx.answerCbQuery('⚠️ Silakan login terlebih dahulu!', { show_alert: true });

        const message = `
───────『𝐎𝐒𝐈𝐍𝐓 𝐌𝐄𝐍𝐔』───────

𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐭𝐨 𝐍𝐚𝐤𝐮𝐧𝐓𝐨𝐨𝐥𝐬 𝐎𝐒𝐈𝐍𝐓!
Fitur ini melacak keberadaan sebuah username di puluhan jejaring sosial populer secara instan.

✍️ 𝐒𝐢𝐥𝐚𝐤𝐚𝐧 𝐤𝐞𝐭𝐢𝐤 𝐮𝐬𝐞𝐫𝐧𝐚𝐦𝐞 𝐭𝐚𝐫𝐠𝐞𝐭 𝐲𝐚𝐧𝐠 𝐢𝐧𝐠𝐢𝐧 𝐝𝐢𝐥𝐚𝐜𝐚𝐤:
        `.trim();

        userStates.set(ctx.from.id, { step: 'WAITING_OSINT_USER' });
        await ctx.answerCbQuery();
        await ctx.editMessageCaption(message, {
            ...Markup.inlineKeyboard([
                [Markup.button.callback('𝐋𝐈𝐒𝐓 𝐒𝐎𝐒𝐈𝐀𝐋 𝐌𝐄𝐃𝐈𝐀', 'osint_list_sites')],
                [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'sub_tools_menu')]
            ])
        }).catch(() => { });
    });

    // OSINT List Sites Handler with Pagination
    bot.action(/^osint_list_sites:(\d+)$/, async (ctx) => {
        const { getUserByTelegramId } = require('../lib/db');
        const userData = await getUserByTelegramId(ctx.from.id);
        if (!userData) return ctx.answerCbQuery('⚠️ Silakan login terlebih dahulu!', { show_alert: true });

        const page = parseInt(ctx.match[1]);
        const targetSites = Object.entries(siteData)
            .filter(([name, info]) => !info.isNSFW);

        const pageSize = 45;
        const totalPages = Math.ceil(targetSites.length / pageSize);
        const startIndex = page * pageSize;
        const pageSites = targetSites.slice(startIndex, startIndex + pageSize);

        let listText = `─────『𝐒𝐎𝐒𝐈𝐀𝐋 𝐌𝐄𝐃𝐈𝐀 𝐋𝐈𝐒𝐓』─────\n\n`;
        listText += `Menampilkan halaman *${page + 1}/${totalPages}* (${targetSites.length} total situs):\n\n`;

        listText += '```\n';
        const names = pageSites.map(([name]) => name).sort();
        for (let i = 0; i < names.length; i += 3) {
            const c1 = (names[i] || '').padEnd(12).slice(0, 12);
            const c2 = (names[i + 1] || '').padEnd(12).slice(0, 12);
            const c3 = (names[i + 2] || '').padEnd(12).slice(0, 12);
            listText += `${c1}  ${c2}  ${c3}\n`;
        }
        listText += '```';

        const navRow = [];
        if (page > 0) {
            navRow.push(Markup.button.callback('⬅️ Prev', `osint_list_sites:${page - 1}`));
        }
        if (startIndex + pageSize < targetSites.length) {
            navRow.push(Markup.button.callback('Next ➡️', `osint_list_sites:${page + 1}`));
        }

        await ctx.answerCbQuery();
        await ctx.editMessageCaption(listText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                navRow,
                [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'osint_menu')]
            ])
        }).catch((err) => {
            console.error('Failed to edit caption in OSINT list:', err);
        });
    });

    // Handle initial list view
    bot.action('osint_list_sites', async (ctx) => {
        ctx.match = ['osint_list_sites:0', '0'];
        const handler = bot.callbackQuery;
        // Trigger page 0 logic
        const { getUserByTelegramId } = require('../lib/db');
        const userData = await getUserByTelegramId(ctx.from.id);
        if (!userData) return ctx.answerCbQuery('⚠️ Silakan login terlebih dahulu!', { show_alert: true });

        const targetSites = Object.entries(siteData)
            .filter(([name, info]) => !info.isNSFW);

        const pageSize = 45;
        const totalPages = Math.ceil(targetSites.length / pageSize);

        let listText = `──────『𝐒𝐎𝐒𝐈𝐀𝐋 𝐌𝐄𝐃𝐈𝐀 𝐋𝐈𝐒𝐓』──────\n\n`;
        listText += `Menampilkan halaman *1/${totalPages}* (${targetSites.length} total situs):\n\n`;

        listText += '```\n';
        const pageSites = targetSites.slice(0, pageSize);
        const names = pageSites.map(([name]) => name).sort();
        for (let i = 0; i < names.length; i += 3) {
            const c1 = (names[i] || '').padEnd(12).slice(0, 12);
            const c2 = (names[i + 1] || '').padEnd(12).slice(0, 12);
            const c3 = (names[i + 2] || '').padEnd(12).slice(0, 12);
            listText += `${c1}  ${c2}  ${c3}\n`;
        }
        listText += '```';

        const navRow = [];
        if (targetSites.length > pageSize) {
            navRow.push(Markup.button.callback('Next ➡️', `osint_list_sites:1`));
        }

        await ctx.answerCbQuery();
        await ctx.editMessageCaption(listText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                navRow,
                [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'osint_menu')]
            ])
        }).catch((err) => {
            console.error('Failed to edit caption in OSINT list page 0:', err);
        });
    });

    // Handle OSINT Input
    bot.on('text', async (ctx, next) => {
        const state = userStates.get(ctx.from.id);
        if (state && state.step === 'WAITING_OSINT_USER') {
            // Jika owner sedang dalam mode broadcast, jangan telan pesannya
            const { broadcastStates } = require('../lib/broadcast');
            if (broadcastStates && broadcastStates.has(ctx.from.id)) return next();
            const username = ctx.message.text.trim();
            userStates.delete(ctx.from.id);

            if (!/^[a-zA-Z0-9_.-]+$/.test(username)) {
                return ctx.reply('❌ 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞 𝐭𝐢𝐝𝐚𝐤 𝐯𝐚𝐥𝐢𝐝! Harap gunakan huruf, angka, titik, atau garis bawah.');
            }

            const targetSites = Object.entries(siteData)
                .filter(([name, info]) => !info.isNSFW)
                .slice(0, 60); // 60 high-quality sites for rapid premium checks

            if (targetSites.length === 0) {
                return ctx.reply('❌ Database OSINT kosong. Harap hubungi Owner.');
            }

            const loadingMsg = await ctx.reply(`⏳ 𝐏𝐫𝐞𝐩𝐚𝐫𝐢𝐧𝐠 𝐎𝐒𝐈𝐍𝐓 𝐒𝐜𝐚𝐧 𝐟𝐨𝐫 @${username}...`);

            const getProgressBar = (percent) => {
                const total = 10;
                const active = Math.round((percent / 100) * total);
                const inactive = total - active;
                return '█'.repeat(active) + '░'.repeat(inactive);
            };

            const results = [];
            const concurrencyLimit = 12; // High-performance concurrent processing
            let checkedCount = 0;

            let lastUpdate = 0;
            const updateProgress = async (force = false) => {
                const now = Date.now();
                if (!force && now - lastUpdate < 1500) return; // Throttle to 1.5s
                lastUpdate = now;

                const percent = Math.round((checkedCount / targetSites.length) * 100);
                const progress = getProgressBar(percent);
                const caption = `
───────『𝐎𝐒𝐈𝐍𝐓 𝐒𝐂𝐀𝐍𝐍𝐈𝐍𝐆』───────

👤 𝐓𝐚𝐫𝐠𝐞𝐭 : @${username}
📊 𝐏𝐫𝐨𝐠𝐫𝐞𝐬𝐬 : ${percent}%
⏱️ 𝐒𝐭𝐚𝐭𝐮𝐬 : Scanning target sites...

[${progress}]
                `.trim();

                await ctx.telegram.editMessageText(ctx.chat.id, loadingMsg.message_id, null, caption).catch(() => { });
            };

            const runScan = async () => {
                const queue = [...targetSites];
                const workers = Array(concurrencyLimit).fill(null).map(async () => {
                    while (queue.length > 0) {
                        const item = queue.shift();
                        if (!item) break;
                        const [name, info] = item;
                        const res = await checkUsernameOnSite(username, name, info);
                        results.push(res);
                        checkedCount++;

                        await updateProgress(false);
                    }
                });
                await Promise.all(workers);
                await updateProgress(true); // Final update
            };

            try {
                await runScan();

                // Process results & Shorten links
                const found = results.filter(r => r.isClaimed);

                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    loadingMsg.message_id,
                    null,
                    `⚡ 𝐒𝐜𝐚𝐧 𝐒𝐞𝐥𝐞𝐬𝐚𝐢! 𝐒𝐞𝐝𝐚𝐧𝐠 𝐦𝐞𝐧𝐲𝐢𝐧𝐠𝐤𝐚𝐭 𝐥𝐢𝐧𝐤 𝐡𝐚𝐬𝐢𝐥...`
                ).catch(() => { });

                const shortened = await Promise.all(found.map(async (item) => {
                    const short = await shortenUrl(item.url);
                    return { name: item.siteName, url: short };
                }));

                let resultText = `──────『𝐎𝐒𝐈𝐍𝐓 𝐑𝐄𝐒𝐔𝐋𝐓𝐒』──────\n\n`;
                resultText += `👤 𝐓𝐚𝐫𝐠𝐞𝐭: @${username}\n`;
                resultText += `🎯 𝐓𝐨𝐭𝐚𝐥 𝐅𝐨𝐮𝐧𝐝: ${shortened.length} Jejaring Sosial\n\n`;

                if (shortened.length > 0) {
                    shortened.forEach(item => {
                        resultText += `╰┈➤ *${item.name}*: ${item.url}\n`;
                    });
                } else {
                    resultText += `❌ Tidak ditemukan akun dengan username tersebut.`;
                }

                await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => { });

                await ctx.reply(resultText, {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([[Markup.button.callback('« 𝐊𝐄𝐌𝐁𝐀𝐋𝐈 𝐊𝐄 𝐌𝐄𝐍𝐔', 'sub_tools_menu')]])
                });
            } catch (err) {
                console.error('OSINT Error:', err);
                ctx.reply('❌ Terjadi kesalahan saat menjalankan OSINT.');
            }
        } else {
            return next();
        }
    });
};
