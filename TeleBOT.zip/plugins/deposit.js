const { Markup } = require('telegraf');
const path = require('path');
const fs = require('fs');
const https = require('https');

// Helper to check and mark processed deposits to prevent double-claiming
const processedFile = path.join(__dirname, '../database/processed_deposits.json');

function isOrderProcessed(orderId) {
    if (!fs.existsSync(processedFile)) return false;
    try {
        const data = JSON.parse(fs.readFileSync(processedFile, 'utf8') || '{}');
        return !!data[orderId];
    } catch (e) {
        return false;
    }
}

function markOrderProcessed(orderId) {
    let data = {};
    if (fs.existsSync(processedFile)) {
        try {
            data = JSON.parse(fs.readFileSync(processedFile, 'utf8') || '{}');
        } catch (e) {
            data = {};
        }
    }
    data[orderId] = { processedAt: new Date().toISOString() };
    fs.writeFileSync(processedFile, JSON.stringify(data, null, 2), 'utf8');
}

function fetchPakasirStatus(slug, amount, orderId, apiKey) {
    return new Promise((resolve) => {
        const url = `https://app.pakasir.com/api/transactiondetail?project=${slug}&amount=${amount}&order_id=${orderId}&api_key=${apiKey}`;
        https.get(url, (res) => {
            let data = '';
            res.on('data', (chunk) => { data += chunk; });
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    resolve(parsed);
                } catch (e) {
                    resolve(null);
                }
            });
        }).on('error', (err) => {
            console.error('Pakasir API Error:', err);
            resolve(null);
        });
    });
}

function createPakasirTransaction(slug, amount, orderId, apiKey) {
    return new Promise((resolve) => {
        const url = 'https://app.pakasir.com/api/transactioncreate/qris';
        const payload = JSON.stringify({
            project: slug,
            order_id: orderId,
            amount: amount,
            api_key: apiKey
        });

        const parsedUrl = new URL(url);
        const options = {
            hostname: parsedUrl.hostname,
            path: parsedUrl.pathname,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(payload)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => { data += chunk; });
            res.on('end', () => {
                console.log(`[PAKASIR API] POST transactioncreate/qris - Status: ${res.statusCode}`);
                console.log(`[PAKASIR API] Response Data:`, data);
                try {
                    const parsed = JSON.parse(data);
                    resolve(parsed);
                } catch (e) {
                    console.error('[PAKASIR API] JSON Parse Error:', e.message);
                    resolve(null);
                }
            });
        });

        req.on('error', (err) => {
            console.error('Pakasir Transaction Create Error:', err);
            resolve(null);
        });

        req.write(payload);
        req.end();
    });
}

module.exports = (bot) => {
    const { sendMainMenu } = require('../lib/menu');
    const userStates = new Map();

    bot.action('deposit', async (ctx) => {
        const { getUserByTelegramId } = require('../lib/db');
        const userData = await getUserByTelegramId(ctx.from.id);
        if (!userData) return ctx.answerCbQuery('⚠️ Silakan login terlebih dahulu!', { show_alert: true });

        const message = `
───────『𝐃𝐄𝐏𝐎𝐒𝐈𝐓 𝐌𝐄𝐍𝐔』───────

════════════════════════════
╰┈➤ 𝐒𝐭𝐚𝐭𝐮sw : 𝐎𝐧𝐥𝐢𝐧𝐞 🟢
╰┈➤ 𝐌𝐞𝐭𝐨𝐝𝐞 : 𝐐𝐑𝐈𝐒 (𝐎𝐭𝐨𝐦𝐚𝐭𝐢𝐬)
════════════════════════════
 Silakan pilih salah satu metode deposit
 di bawah ini untuk melanjutkan.
        `.trim();

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('𝐐𝐑𝐈𝐒 𝐎𝐭𝐨𝐦𝐚𝐭𝐢𝐬', 'pay_qris')],
            [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'back_start')]
        ]);

        try {
            await ctx.editMessageCaption(
                message.replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1'),
                {
                    parse_mode: 'MarkdownV2',
                    ...keyboard
                }
            );
        } catch (e) {
            await ctx.editMessageText(
                message.replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1'),
                {
                    parse_mode: 'MarkdownV2',
                    ...keyboard
                }
            ).catch(() => { });
        }
    });

    // QRIS Flow
    bot.action('pay_qris', async (ctx) => {
        userStates.set(ctx.from.id, { step: 'WAITING_NOMINAL', type: 'QRIS' });
        await ctx.answerCbQuery();
        await ctx.reply(`
✍️ *𝐒𝐈𝐋𝐀𝐊𝐀𝐍 𝐌𝐀𝐒𝐔𝐊𝐊𝐀𝐍 𝐍𝐎𝐌𝐈𝐍𝐀𝐋*

Silakan ketik jumlah nominal deposit yang Anda inginkan (Tanpa tanda titik/koma).
        `.trim(), { parse_mode: 'Markdown' });
    });

    bot.on('text', async (ctx, next) => {
        const state = userStates.get(ctx.from.id);
        if (state && state.step === 'WAITING_NOMINAL' && state.type === 'QRIS') {
            // Jika owner sedang dalam mode broadcast, jangan telan pesannya
            const { broadcastStates } = require('../lib/broadcast');
            if (broadcastStates && broadcastStates.has(ctx.from.id)) return next();
            const amount = parseInt(ctx.message.text.replace(/\D/g, ''));
            if (isNaN(amount) || amount < 1000) {
                return ctx.reply('⚠️ 𝐍𝐨𝐦𝐢𝐧𝐚𝐥 𝐭𝐢𝐝𝐚𝐤 𝐯𝐚𝐥𝐢𝐝. 𝐌𝐢𝐧𝐢𝐦𝐚𝐥 𝐝𝐞𝐩𝐨𝐬𝐢𝐭 𝐚𝐝𝐚𝐥𝐚𝐡 𝐑𝐩 𝟏.𝟎𝟎𝟎');
            }

            userStates.delete(ctx.from.id); // clear state immediately

            const orderId = `DEP-${Date.now()}-${ctx.from.id}`;
            const slug = process.env.PAKASIR_SLUG || 'nakun-store';
            const apiKey = process.env.PAKASIR;
            const paymentUrl = `https://app.pakasir.com/pay/${slug}/${amount}?order_id=${orderId}&qris_only=1`;

            if (!apiKey) {
                return ctx.reply('❌ Kesalahan Konfigurasi: API Key Pakasir tidak ditemukan pada server.');
            }

            const loadingMsg = await ctx.reply('⏳ Sedang memproses request QRIS Pakasir...');

            try {
                const result = await createPakasirTransaction(slug, amount, orderId, apiKey);
                let sentMsg = null;
                let isPhoto = false;

                const invoiceText = (status) => `
\`\`\`
════════════════════════════
QRIS BILLING INVOICE         
════════════════════════════
Order ID : ${orderId}
Nominal  : Rp ${amount.toLocaleString('id-ID')}
Metode   : QRIS Otomatis (Pakasir)
Status   : ${status}
════════════════════════════
\`\`\`
                `.trim();

                if (result && result.payment && result.payment.payment_number) {
                    isPhoto = true;
                    let qrString = result.payment.payment_number;
                    if (qrString.includes('000201')) {
                        qrString = qrString.substring(qrString.indexOf('000201'));
                    }
                    const { buildQRImage } = require('../lib/qris');
                    const qrBuffer = await buildQRImage(qrString);

                    // Delete loading message
                    await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});

                    const keyboard = Markup.inlineKeyboard([
                        [Markup.button.url('🌐 BUKA HALAMAN PEMBAYARAN', paymentUrl)],
                        [Markup.button.callback('CEK STATUS PEMBAYARAN', `check_pay:${orderId}:${amount}`)]
                    ]);

                    sentMsg = await ctx.replyWithPhoto({ source: qrBuffer }, {
                        caption: invoiceText('Menunggu Pembayaran (5 Mnt)'),
                        parse_mode: 'Markdown',
                        ...keyboard
                    });
                } else {
                    // Fallback to URL checkout page if API creation fails
                    await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});

                    const keyboard = Markup.inlineKeyboard([
                        [Markup.button.url('BAYAR SEKARANG', paymentUrl)],
                        [Markup.button.callback('CEK STATUS PEMBAYARAN', `check_pay:${orderId}:${amount}`)]
                    ]);

                    sentMsg = await ctx.reply(invoiceText('Menunggu Pembayaran (5 Mnt)'), {
                        parse_mode: 'Markdown',
                        ...keyboard
                    });
                }

                // Background Auto-Polling (checks every 7 seconds)
                const pollingInterval = setInterval(async () => {
                    if (isOrderProcessed(orderId)) {
                        clearInterval(pollingInterval);
                        return;
                    }

                    const checkResult = await fetchPakasirStatus(slug, amount, orderId, apiKey);
                    if (checkResult && checkResult.transaction && checkResult.transaction.status === 'completed') {
                        clearInterval(pollingInterval);
                        markOrderProcessed(orderId);

                        try {
                            const { updateBalance } = require('../lib/db');
                            const newBalance = await updateBalance(ctx.from.id, amount);

                            const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
                            const timeString = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

                            const successInvoice = `
\`\`\`
════════════════════════════
    DEPOSIT BERHASIL!           
════════════════════════════

════════════════════════════
    RESI / INVOICE DEPOSIT       
════════════════════════════
Order ID : ${orderId}
Nominal  : Rp ${amount.toLocaleString('id-ID')}
Metode   : QRIS (Pakasir)
Waktu    : ${timeString} WIB
Status   : Sukses (Lunas)
════════════════════════════

════════════════════════════
    DETAIL SALDO USER          
════════════════════════════
Pengguna : ${username}
Saldo    : Rp ${amount.toLocaleString('id-ID')}
Total    : Rp ${newBalance.toLocaleString('id-ID')}

\`\`\`
                            `.trim();

                            if (isPhoto) {
                                await ctx.telegram.editMessageCaption(sentMsg.chat.id, sentMsg.message_id, null, successInvoice, {
                                    parse_mode: 'Markdown'
                                }).catch(() => { });
                            } else {
                                await ctx.telegram.editMessageText(sentMsg.chat.id, sentMsg.message_id, null, successInvoice, {
                                    parse_mode: 'Markdown'
                                }).catch(() => { });
                            }

                            await ctx.reply(`✅ *DEPOSIT BERHASIL!* Rp ${amount.toLocaleString('id-ID')} telah ditambahkan ke saldo Anda.`, { parse_mode: 'Markdown' }).catch(() => { });
                        } catch (err) {
                            console.error(err);
                        }
                    }
                }, 7000);

                // Auto-expire invoice after 5 minutes (300,000 ms)
                setTimeout(async () => {
                    clearInterval(pollingInterval);
                    if (isOrderProcessed(orderId)) return;
                    try {
                        const expiredInvoice = invoiceText('EXPIRED (Kedaluwarsa)');
                        if (isPhoto) {
                            // Delete photo and send plain text warning to prevent scanning expired QR code
                            await ctx.telegram.deleteMessage(sentMsg.chat.id, sentMsg.message_id).catch(() => {});
                            await ctx.reply(expiredInvoice, { parse_mode: 'Markdown' }).catch(() => {});
                        } else {
                            await ctx.telegram.editMessageText(sentMsg.chat.id, sentMsg.message_id, null, expiredInvoice, {
                                parse_mode: 'Markdown'
                            }).catch(() => {});
                        }
                    } catch (e) {
                        // Suppress error if message was deleted or already edited
                    }
                }, 5 * 60 * 1000);

            } catch (err) {
                console.error(err);
                await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
                ctx.reply('❌ Terjadi kesalahan saat membuat tautan pembayaran.');
            }
        } else {
            return next();
        }
    });

    bot.action(/^check_pay:(DEP-\d+-\d+):(\d+)$/, async (ctx) => {
        const orderId = ctx.match[1];
        const amount = parseInt(ctx.match[2]);
        const userId = ctx.from.id;

        if (isOrderProcessed(orderId)) {
            return ctx.answerCbQuery('⚠️ Deposit ini sudah pernah diproses sebelumnya.', { show_alert: true });
        }

        // Security check: Expiry after 5 minutes based on timestamp in order ID
        const orderTime = parseInt(orderId.split('-')[1]);
        if (isNaN(orderTime) || Date.now() - orderTime > 5 * 60 * 1000) {
            try {
                const expiredInvoice = `
\`\`\`
════════════════════════════
QRIS BILLING INVOICE         
════════════════════════════
Order ID : ${orderId}
Nominal  : Rp ${amount.toLocaleString('id-ID')}
Metode   : QRIS Otomatis (Pakasir)
Status   : EXPIRED (Kedaluwarsa)
════════════════════════════
\`\`\`
                `.trim();
                
                if (ctx.callbackQuery.message.photo) {
                    await ctx.deleteMessage().catch(() => {});
                    await ctx.reply(expiredInvoice, { parse_mode: 'Markdown' }).catch(() => {});
                } else {
                    await ctx.editMessageText(expiredInvoice, {
                        parse_mode: 'Markdown'
                    }).catch(() => { });
                }
            } catch (e) { }
            return ctx.answerCbQuery('⚠️ Invoice ini telah kedaluwarsa (Batas waktu 5 menit).', { show_alert: true });
        }

        const apiKey = process.env.PAKASIR;
        const slug = process.env.PAKASIR_SLUG || 'nakun-store';

        if (!apiKey) {
            return ctx.reply('❌ Kesalahan Konfigurasi: API Key Pakasir tidak ditemukan pada server.');
        }

        await ctx.answerCbQuery('⏳ Sedang memverifikasi pembayaran...');

        const result = await fetchPakasirStatus(slug, amount, orderId, apiKey);

        if (result && result.transaction && result.transaction.status === 'completed') {
            markOrderProcessed(orderId);

            try {
                const { updateBalance } = require('../lib/db');
                const newBalance = await updateBalance(userId, amount);

                const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
                const timeString = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

                const successInvoice = `
\`\`\`
════════════════════════════
    DEPOSIT BERHASIL!           
════════════════════════════

════════════════════════════
    RESI / INVOICE DEPOSIT       
════════════════════════════
Order ID : ${orderId}
Nominal  : Rp ${amount.toLocaleString('id-ID')}
Metode   : QRIS (Pakasir)
Waktu    : ${timeString} WIB
Status   : Sukses (Lunas)
════════════════════════════

════════════════════════════
    DETAIL SALDO USER          
════════════════════════════
Pengguna : ${username}
Saldo    : Rp ${amount.toLocaleString('id-ID')}
Total    : Rp ${newBalance.toLocaleString('id-ID')}

\`\`\`
                `.trim();

                // Update original invoice message to show paid
                if (ctx.callbackQuery.message.photo) {
                    await ctx.editMessageCaption(successInvoice, {
                        parse_mode: 'Markdown'
                    }).catch(() => { });
                } else {
                    await ctx.editMessageText(successInvoice, {
                        parse_mode: 'Markdown'
                    }).catch(() => { });
                }

                // Success notification alert pop-up
                await ctx.answerCbQuery('✅ Deposit Berhasil Terverifikasi!', { show_alert: true }).catch(() => { });
            } catch (err) {
                console.error(err);
                ctx.reply('❌ Terjadi kesalahan saat mengupdate saldo Anda.');
            }
        } else {
            await ctx.answerCbQuery('⚠️ Pembayaran belum terdeteksi. Silakan bayar terlebih dahulu atau tunggu beberapa saat lalu coba lagi.', { show_alert: true }).catch(() => { });
        }
    });

    bot.action('back_start', async (ctx) => {
        await ctx.answerCbQuery();
        await sendMainMenu(ctx, true);
    });
};
