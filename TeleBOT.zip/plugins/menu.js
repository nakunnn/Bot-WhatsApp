const { Markup } = require('telegraf');
const { getUserByTelegramId, updateBalance, isVip, setVipStatus, claimCheckin } = require('../lib/db');
const { sendMainMenu, toSansBold } = require('../lib/menu');

module.exports = (bot) => {
    const ownerID = '7548346607';
    const bugPurchaseStates = new Map();

    const getProgressBar = (percent) => {
        const total = 10;
        const active = Math.round((percent / 100) * total);
        const inactive = total - active;
        return '█'.repeat(active) + '░'.repeat(inactive);
    };

    // Main Menu Trigger
    bot.action('main_menu', async (ctx) => {
        await sendMainMenu(ctx, true);
    });

    bot.action('back_start', async (ctx) => {
        await sendMainMenu(ctx, true);
    });

    // VIP MENU
    bot.action('vip_menu', async (ctx) => {
        const message = `
🌟 ───────『𝐕𝐈𝐏 𝐌𝐄𝐍𝐔』─────── 🌟

𝐊𝐞𝐮𝐧𝐠𝐠𝐮𝐥𝐚𝐧 𝐕𝐈𝐏:
✅ 𝐃𝐢𝐬𝐤𝐨𝐧 𝟐𝟎% 𝐬𝐞𝐦𝐮𝐚 𝐛𝐮𝐠
✅ 𝐑𝐞𝐬𝐩𝐨𝐧 𝐛𝐨𝐭 𝐥𝐞𝐛𝐢𝐡 𝐜𝐞𝐩𝐚𝐭
✅ 𝐑𝐚𝐭𝐞 𝐛𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐥𝐞𝐛𝐢𝐡 𝐭𝐢𝐧𝐠𝐠𝐢
✅ 𝐒𝐚𝐥𝐝𝐨 𝐇𝐚𝐫𝐢𝐚𝐧 𝐑𝐩 𝟏𝟎𝟎

𝐏𝐢𝐥𝐢𝐡 𝐏𝐚𝐤𝐞𝐭:
        `.trim();

        await ctx.editMessageCaption(message, {
            ...Markup.inlineKeyboard([
                [Markup.button.callback('𝐌𝐢𝐧𝐠𝐠𝐮𝐚𝐧 (𝐑𝐩 𝟏𝟓.𝟎𝟎𝟎)', 'confirm_vip:7:15000')],
                [Markup.button.callback('𝐁𝐮𝐥𝐚𝐧𝐚𝐧 (𝐑𝐩 𝟐𝟎.𝟎𝟎𝟎)', 'confirm_vip:30:20000')],
                [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'back_start')]
            ])
        });
    });

    // CHECKIN
    bot.action('checkin', async (ctx) => {
        const res = await claimCheckin(ctx.from.id);
        if (res.success) {
            await ctx.answerCbQuery(`✅ Berhasil checkin! +Rp ${res.amount}`, { show_alert: true });
            await sendMainMenu(ctx, true);
        } else {
            await ctx.answerCbQuery(`❌ ${res.message}`, { show_alert: true });
        }
    });

    // GACHA MENU
    bot.action('gacha_menu', async (ctx) => {
        const message = `
───────『𝐆𝐀𝐂𝐇𝐀 𝐌𝐄𝐍𝐔』───────

🎁 𝐏𝐨𝐭𝐞𝐧𝐬𝐢 𝐇𝐚𝐝𝐢𝐚𝐡:
• 𝟏𝟎𝟎 : 𝟕𝟎%
• 𝟐𝟓𝟎 : 𝟐𝟓%
• 𝟓𝟎𝟎 : 𝟒%
• 𝟏𝟎𝟎𝟎 : 𝟏%
• 𝐕𝐈𝐏 𝐌𝐄𝐌𝐁𝐄𝐑 : 𝟎,𝟏%

💰 𝐇𝐚𝐫𝐠𝐚:
• 𝟏𝐱 𝐆𝐚𝐜𝐡𝐚 : 𝐑𝐩 𝟓𝟎𝟎
• 𝟏𝟎𝐱 𝐆𝐚𝐜𝐡𝐚 : 𝐑𝐩 𝟒.𝟎𝟎𝟎

𝐒𝐢𝐥𝐚𝐤𝐚𝐧 𝐩𝐢𝐥𝐢𝐡 𝐣𝐮𝐦𝐥𝐚𝐡 𝐠𝐚𝐜𝐡𝐚:
        `.trim();

        await ctx.editMessageCaption(message, {
            ...Markup.inlineKeyboard([
                [Markup.button.callback('𝟏𝐱 𝐆𝐚𝐜𝐡𝐚 (𝐑𝐩 𝟓𝟎𝟎)', 'buy_gacha:1:500'), Markup.button.callback('𝟏𝟎𝐱 𝐆𝐚𝐜𝐡𝐚 (𝐑𝐩 𝟒.𝟎𝟎𝟎)', 'buy_gacha:10:4000')],
                [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'back_start')]
            ])
        });
    });

    // HANDLE GACHA
    bot.action(/^buy_gacha:(\d+):(\d+)$/, async (ctx) => {
        const count = parseInt(ctx.match[1]);
        const price = parseInt(ctx.match[2]);
        const user = await getUserByTelegramId(ctx.from.id);

        if (!user || user.Balance < price) {
            return ctx.answerCbQuery('⚠️ Saldo Anda tidak cukup!', { show_alert: true });
        }

        await updateBalance(ctx.from.id, -price);

        const rewards = [];
        let totalWin = 0;
        let vipWin = 0;

        for (let i = 0; i < count; i++) {
            const rand = Math.random() * 100; // 0.0 to 100.0

            if (rand <= 0.1) { // 0.1%
                vipWin++;
                rewards.push('🌟 VIP Membership (1 Hari)');
            } else if (rand <= 1.1) { // 1.0%
                totalWin += 1000;
                rewards.push('💰 1000');
            } else if (rand <= 5.1) { // 4.0%
                totalWin += 500;
                rewards.push('💰 500');
            } else if (rand <= 30.1) { // 25.0%
                totalWin += 250;
                rewards.push('💰 250');
            } else { // ~70%
                totalWin += 100;
                rewards.push('💰 100');
            }
        }

        if (totalWin > 0) await updateBalance(ctx.from.id, totalWin);
        if (vipWin > 0) await setVipStatus(ctx.from.id, vipWin);

        let resultText = `──────『𝐆𝐀𝐂𝐇𝐀 𝐑𝐄𝐒𝐔𝐋𝐓』──────\n\n`;
        if (count === 1) {
            resultText += `𝐀𝐧𝐝𝐚 𝐦𝐞𝐧𝐝𝐚𝐩𝐚𝐭𝐤𝐚𝐧:\n╰┈➤ ${rewards[0]}`;
        } else {
            resultText += `𝐀𝐧𝐝𝐚 𝐦𝐞𝐧𝐝𝐚𝐩𝐚𝐭𝐤𝐚𝐧:\n`;
            const summary = rewards.reduce((acc, curr) => {
                acc[curr] = (acc[curr] || 0) + 1;
                return acc;
            }, {});

            for (const [reward, qty] of Object.entries(summary)) {
                resultText += `╰┈➤ ${reward} x${qty}\n`;
            }
            resultText += `\n𝐓𝐨𝐭𝐚𝐥 𝐒𝐚𝐥𝐝𝐨 : +𝐑𝐩 ${toSansBold(totalWin.toLocaleString('id-ID'))}`;
            if (vipWin > 0) resultText += `\n𝐓𝐨𝐭𝐚𝐥 𝐕𝐈𝐏   : +${toSansBold(vipWin)} 𝐇𝐚𝐫𝐢`;
        }

        await ctx.editMessageCaption(resultText, {
            ...Markup.inlineKeyboard([[Markup.button.callback('« 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'gacha_menu')]])
        });
    });

    // Handle VIP Confirmation
    bot.action(/^confirm_vip:(\d+):(\d+)$/, async (ctx) => {
        const days = parseInt(ctx.match[1]);
        const price = parseInt(ctx.match[2]);
        const user = await getUserByTelegramId(ctx.from.id);

        if (!user || user.Balance < price) {
            return ctx.answerCbQuery('⚠️ Saldo Anda tidak cukup!', { show_alert: true });
        }

        await updateBalance(ctx.from.id, -price);
        const expiry = await setVipStatus(ctx.from.id, days);

        await ctx.answerCbQuery('Berhasil membeli VIP!');
        await ctx.editMessageCaption(`✅ 𝐒𝐞𝐥𝐚𝐦𝐚𝐭! 𝐀𝐧𝐝𝐚 𝐬𝐞𝐤𝐚𝐫𝐚𝐧𝐠 𝐚𝐝𝐚𝐥𝐚𝐡 𝐕𝐈𝐏.\n\nMasa aktif hingga: ${expiry.toLocaleDateString('id-ID')}`, {
            ...Markup.inlineKeyboard([[Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'back_start')]])
        });
    });

    // SUB-MENU TOOLS
    bot.action('sub_tools_menu', async (ctx) => {
        const isOwner = ctx.from.id.toString() === ownerID;
        const user = await getUserByTelegramId(ctx.from.id);
        if (!user && !isOwner) return ctx.answerCbQuery('⚠️ Silakan login terlebih dahulu!', { show_alert: true });

        const message = `
───────『𝐓𝐎𝐎𝐋𝐒 𝐌𝐄𝐍𝐔』───────

Silakan pilih perkakas di bawah ini untuk memulai:
        `.trim();

        await ctx.editMessageCaption(message, {
            ...Markup.inlineKeyboard([
                [Markup.button.callback('𝐁𝐔𝐆 𝐌𝐄𝐍𝐔', 'bug_menu'), Markup.button.callback('𝐎𝐒𝐈𝐍𝐓', 'osint_menu')],
                [Markup.button.callback('𝐌𝐄𝐍𝐔 𝐎𝐖𝐍𝐄𝐑', 'owner_menu'), Markup.button.callback('𝐀𝐃𝐌𝐈𝐍 𝐌𝐄𝐍𝐔', 'tools_menu')],
                [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'back_start')]
            ])
        }).catch(() => { });
    });

    // BUG MENU
    bot.action('bug_menu', async (ctx) => {
        const isOwner = ctx.from.id.toString() === ownerID;
        const user = await getUserByTelegramId(ctx.from.id);
        if (!user && !isOwner) return ctx.answerCbQuery('⚠️ Silakan login terlebih dahulu!', { show_alert: true });

        const vip = await isVip(ctx.from.id);
        const discount = vip ? 0.8 : 1;

        const message = `
────────『𝐁𝐔𝐆 𝐌𝐄𝐍𝐔』────────

𝐒𝐢𝐥𝐚𝐤𝐚𝐧 𝐩𝐢𝐥𝐢𝐡 𝐣𝐞𝐧𝐢𝐬 𝐛𝐮𝐠 𝐲𝐚𝐧𝐠 𝐢𝐧𝐠𝐢𝐧 𝐝𝐢𝐠𝐮𝐧𝐚𝐤𝐚𝐧.
${vip ? '✨ Diskon VIP 20% Aktif!' : ''}
        `.trim();

        await ctx.editMessageCaption(
            message.replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1'),
            {
                parse_mode: 'MarkdownV2',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback(`𝐑𝐢𝐧𝐠𝐚𝐧 (Rp ${(2000 * discount)})`, 'confirm_bug:ringan:2000'), Markup.button.callback(`𝐍𝐨𝐫𝐦𝐚𝐥 (Rp ${(3000 * discount)})`, 'confirm_bug:normal:3000')],
                    [Markup.button.callback(`𝐁𝐥𝐚𝐧𝐤 (Rp ${(4000 * discount)})`, 'confirm_bug:blank:4000'), Markup.button.callback(`𝐂𝐫𝐚𝐬𝐡 (Rp ${(5000 * discount)})`, 'confirm_bug:crash:5000')],
                    [Markup.button.callback(`𝐈𝐧𝐯𝐢𝐬𝐢𝐛𝐥𝐞 (Rp ${(10000 * discount)})`, 'confirm_bug:invisible:10000'), Markup.button.callback(`𝐈𝐏 (Rp ${(10000 * discount)})`, 'confirm_bug:ip:10000')],
                    [Markup.button.callback(`𝐊𝐄𝐍𝐎𝐍 (Rp ${(20000 * discount)})`, 'confirm_bug:kenon:20000')],
                    [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'sub_tools_menu')]
                ])
            }
        ).catch(() => { });
    });

    // Handle Confirmation Step
    bot.action(/^confirm_bug:(.+):(\d+)$/, async (ctx) => {
        const bugType = ctx.match[1];
        let price = parseInt(ctx.match[2]);

        const vip = await isVip(ctx.from.id);
        if (vip) price = Math.round(price * 0.8);

        const message = `
───────『𝐂𝐎𝐍𝐅𝐈𝐑𝐌𝐀𝐓𝐈𝐎𝐍』───────

📦 𝐏𝐫𝐨𝐝𝐮𝐤: 𝐁𝐮𝐠 ${bugType.toUpperCase()}
💰 𝐇𝐚𝐫𝐠𝐚: Rp ${price.toLocaleString('id-ID')} ${vip ? '(VIP Discount)' : ''}

𝐀𝐩𝐚𝐤𝐚𝐡 𝐀𝐧𝐝𝐚 𝐲𝐚𝐤𝐢𝐧 𝐢𝐧𝐠𝐢𝐧 𝐦𝐞𝐦𝐛𝐞𝐥𝐢?
        `.trim();

        await ctx.editMessageCaption(
            message.replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1'),
            {
                parse_mode: 'MarkdownV2',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('𝐂𝐎𝐍𝐅𝐈𝐑𝐌𝐀𝐒𝐈', `start_buy:${bugType}:${price}`)],
                    [Markup.button.callback('𝐁𝐀𝐓𝐀𝐋', 'bug_menu')]
                ])
            }
        ).catch(() => { });
    });

    // Start Purchase Flow
    bot.action(/^start_buy:(.+):(\d+)$/, async (ctx) => {
        const bugType = ctx.match[1];
        const price = parseInt(ctx.match[2]);
        const user = await getUserByTelegramId(ctx.from.id);
        const isOwner = ctx.from.id.toString() === ownerID;

        if (!isOwner && (!user || user.Balance < price)) {
            return ctx.answerCbQuery('⚠️ Saldo Anda tidak cukup!', { show_alert: true });
        }

        bugPurchaseStates.set(ctx.from.id, { step: 'WAIT_WA', bugType, price });
        await ctx.answerCbQuery();
        await ctx.reply(`✍️ 𝐒𝐢𝐥𝐚𝐤𝐚𝐧 𝐦𝐚𝐬𝐮𝐤𝐤𝐚𝐧 𝐧𝐨𝐦𝐨𝐫 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩 𝐓𝐚𝐫𝐠𝐞𝐭:\n\n⚠️ 𝐖𝐚𝐣𝐢𝐛 𝐚𝐰𝐚𝐥𝐢 𝐝𝐞𝐧𝐠𝐚𝐧 𝟔𝟐 (𝐂𝐨𝐧𝐭𝐨𝐡: 𝟔𝟐𝟖𝟓𝟏𝐱𝐱𝐱)\n❌ 𝐉𝐚𝐧𝐠𝐚𝐧 𝐚𝐰𝐚𝐥𝐢 𝐝𝐞𝐧𝐠𝐚𝐧 𝟎𝟖`);
    });

    bot.on('text', async (ctx, next) => {
        const state = bugPurchaseStates.get(ctx.from.id);
        if (!state || state.step !== 'WAIT_WA') return next();

        // Jika owner sedang dalam mode broadcast, jangan telan pesannya
        const { broadcastStates } = require('../lib/broadcast');
        if (broadcastStates && broadcastStates.has(ctx.from.id)) return next();

        const waNumber = ctx.message.text.trim();

        // Validation: Must start with 62
        if (!waNumber.startsWith('62')) {
            return ctx.reply('❌ 𝐅𝐨𝐫𝐦𝐚𝐭 𝐒𝐚𝐥𝐚𝐡! Nomor harus diawali dengan 62.\n\nContoh: 6285123456789\nSilakan masukkan ulang:');
        }

        const { bugType, price } = state;
        const isOwner = ctx.from.id.toString() === ownerID;

        // VERIFIKASI ASLI (WhatsApp Server Check)
        const waitVerif = await ctx.reply('🔍 𝐒𝐞𝐝𝐚𝐧𝐠 𝐦𝐞𝐦𝐯𝐞𝐫𝐢𝐟𝐢𝐤𝐚𝐬𝐢 𝐧𝐨𝐦𝐨𝐫 𝐝𝐢 𝐬𝐞𝐫𝐯𝐞𝐫 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩...');
        const { checkNumber } = require('../lib/wa');
        const verif = await checkNumber(waNumber);

        if (!verif.exists) {
            await ctx.telegram.deleteMessage(ctx.from.id, waitVerif.message_id).catch(() => { });
            return ctx.reply(`❌ 𝐕𝐞𝐫𝐢𝐟𝐢𝐤𝐚𝐬𝐢 𝐆𝐚𝐠𝐚𝐥!\n\nNomor ${waNumber} tidak terdaftar di WhatsApp. Proses dihentikan.`);
        }

        // Jika nomor ada, baru lanjut
        bugPurchaseStates.delete(ctx.from.id);

        try {
            await ctx.telegram.deleteMessage(ctx.from.id, waitVerif.message_id).catch(() => { });
            if (!isOwner) await updateBalance(ctx.from.id, -price);

            const loadingMsg = await ctx.reply('⏳ 𝐏𝐫𝐞𝐩𝐚𝐫𝐢𝐧𝐠...');

            const totalDuration = Math.floor(Math.random() * (45 - 25 + 1)) + 25;
            let elapsedSeconds = 0;
            const interval = setInterval(async () => {
                if (elapsedSeconds > totalDuration) {
                    clearInterval(interval);
                    return;
                }

                const percent = Math.round((elapsedSeconds / totalDuration) * 100);
                const progress = getProgressBar(percent);

                let status = '🔍 𝐌𝐞𝐦𝐯𝐞𝐫𝐢𝐟𝐢𝐤𝐚𝐬𝐢 𝐚𝐤𝐮𝐧 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩...';
                if (percent > 15) status = '🛡️ 𝐀𝐤𝐮𝐧 𝐭𝐞𝐫𝐯𝐞𝐫𝐢𝐟𝐢𝐤𝐚𝐬𝐢! 𝐁𝐲𝐩𝐚𝐬𝐬𝐢𝐧𝐠...';
                if (percent > 30) status = '🚀 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐩𝐚𝐤𝐞𝐭 𝐛𝐮𝐠...';
                if (percent > 50 && percent < 60) status = '❌ 𝐆𝐚𝐠𝐚𝐥! 𝐌𝐞𝐧𝐜𝐨𝐛𝐚 𝐤𝐞𝐦𝐛𝐚𝐥𝐢...';
                if (percent >= 60) status = '♻️ 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐮𝐥𝐚𝐧𝐠 𝐝𝐚𝐭𝐚...';
                if (percent > 90) status = '✅ 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐝𝐢𝐤𝐢𝐫𝐢𝐦!';
                if (percent === 100) status = '🏁 𝐒𝐞𝐥𝐞𝐬𝐚𝐢! 𝐁𝐮𝐠 𝐭𝐞𝐥𝐚𝐡 𝐚𝐤𝐭𝐢𝐟.';

                const caption = `
────────『𝐏𝐑𝐎𝐂𝐄𝐒𝐒𝐈𝐍𝐆』────────

📦 𝐏𝐫𝐨𝐝𝐮𝐤: 𝐁𝐮𝐠 ${bugType.toUpperCase()}
📱 𝐓𝐚𝐫𝐠𝐞𝐭: ${waNumber}
⏳ 𝐒𝐭𝐚𝐭𝐮𝐬: ${status}
⏱️ 𝐖𝐚𝐤𝐭𝐮 𝐏𝐫𝐨𝐬𝐞𝐬: ${elapsedSeconds} 𝐃𝐞𝐭𝐢𝐤

[${progress}] ${percent}%
                `.trim();

                const options = { parse_mode: 'Markdown' };
                if (elapsedSeconds === totalDuration) {
                    options.reply_markup = Markup.inlineKeyboard([[Markup.button.callback('« 𝐊𝐄𝐌𝐁𝐀𝐋𝐈 𝐊𝐄 𝐌𝐄𝐍𝐔', 'back_start')]]).reply_markup;
                }

                await ctx.telegram.editMessageText(ctx.from.id, loadingMsg.message_id, null, caption, options).catch(() => { });
                elapsedSeconds++;
            }, 1000);

        } catch (err) {
            console.error(err);
            ctx.reply('❌ Terjadi kesalahan saat memproses pembelian.');
        }
    });

    bot.action('tools_menu', async (ctx) => {
        const isOwner = ctx.from.id.toString() === ownerID;
        const user = await getUserByTelegramId(ctx.from.id);
        if (!user && !isOwner) return ctx.answerCbQuery('⚠️ Silakan login terlebih dahulu!', { show_alert: true });
        const role = user ? user.Role.toLowerCase() : (isOwner ? 'owner' : 'user');
        if (role !== 'admin' && role !== 'owner') return ctx.answerCbQuery('❌ Maaf, menu ini hanya untuk Admin!', { show_alert: true });

        await ctx.editMessageCaption('────────『𝐀𝐃𝐌𝐈𝐍 𝐌𝐄𝐍𝐔』────────', {
            ...Markup.inlineKeyboard([
                [Markup.button.callback('𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐔𝐒𝐄𝐑', 'create_user_admin')],
                [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'sub_tools_menu')]
            ])
        }).catch(() => { });
    });

    bot.action('owner_menu', async (ctx) => {
        const isOwner = ctx.from.id.toString() === ownerID;
        const user = await getUserByTelegramId(ctx.from.id);
        if (!user && !isOwner) return ctx.answerCbQuery('⚠️ Silakan login terlebih dahulu!', { show_alert: true });
        const role = user ? user.Role.toLowerCase() : (isOwner ? 'owner' : 'user');
        if (role !== 'owner') return ctx.answerCbQuery('❌ Maaf, menu ini hanya untuk Owner!', { show_alert: true });

        await ctx.editMessageCaption('────────『𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔』────────', {
            ...Markup.inlineKeyboard([
                [Markup.button.callback('𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐀𝐃𝐌𝐈𝐍', 'create_admin_owner')],
                [Markup.button.callback('𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐔𝐒𝐄𝐑', 'create_user_owner')],
                [Markup.button.callback('𝐇𝐀𝐏𝐔𝐒 𝐀𝐊𝐔𝐍', 'delete_account_owner')],
                [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'sub_tools_menu')]
            ])
        }).catch(() => { });
    });
};
