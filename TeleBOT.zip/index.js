require('dotenv').config();
const https = require('https');

// Force all HTTPS requests globally to use IPv4 & keepAlive to prevent slow connection / ETIMEDOUT (IPv6 issues)
https.globalAgent = new https.Agent({
    family: 4,
    keepAlive: true
});

// Optimize DNS resolution to prefer IPv4
const dns = require('dns');
if (typeof dns.setDefaultResultOrder === 'function') {
    dns.setDefaultResultOrder('ipv4first');
}

const { Telegraf } = require('telegraf');
const fs = require('fs');
const path = require('path');
const logger = require('./lib/logger');

const bot = new Telegraf(process.env.BOT_TOKEN, {
    telegram: {
        agent: https.globalAgent,
        timeout: 90000 // 90 seconds timeout to prevent timeouts on slow uploads/large GIFs
    }
});

// Init WhatsApp
const { connectToWhatsApp } = require('./lib/wa');
connectToWhatsApp();

// ── Broadcast middleware (harus dipasang SEBELUM semua plugin) ────────────────
require('./lib/broadcast')(bot);

// Plugin Loader
const pluginsPath = path.join(__dirname, 'plugins');
const pluginFiles = fs.readdirSync(pluginsPath).filter(file => file.endsWith('.js'));

logger.setColor('#ffb86c');
logger.add('Starting plugin initialization...');
logger.add(''); // Placeholder for loading progress line

pluginFiles.forEach((file, index) => {
    const plugin = require(path.join(pluginsPath, file));
    if (typeof plugin === 'function') {
        plugin(bot);
        logger.updateLastLine(`Loading plugin: ${file} (${index + 1}/${pluginFiles.length})...`);
    }
});
logger.updateLastLine(`All ${pluginFiles.length} plugins loaded successfully!`);

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// Resilient auto-reconnect engine
let reconnecting = false;
function reconnectBot() {
    if (reconnecting) return;
    reconnecting = true;

    try {
        bot.stop();
    } catch (e) {
        // Ignore stop error
    }

    let seconds = 5;
    const interval = setInterval(() => {
        if (seconds > 0) {
            logger.setColor('#ff5555'); // Red error border
            logger.updateLastLine(`Reconnecting in ${seconds} seconds...`);
            seconds--;
        } else {
            clearInterval(interval);
            logger.setColor('#ffb86c'); // Orange status border
            logger.updateLastLine('Reconnecting now...');
            reconnecting = false;
            startBot();
        }
    }, 1000);
}

// Global exception/rejection interceptors to prevent crashes on network outages
process.on('unhandledRejection', (reason) => {
    const msg = reason && reason.message ? reason.message : String(reason);
    logger.setColor('#ff5555');
    logger.updateLastLine(`Unhandled failure: ${msg}`);
    if (msg.toLowerCase().includes('timeout') || msg.toLowerCase().includes('socket') || msg.toLowerCase().includes('network') || msg.toLowerCase().includes('econn') || msg.toLowerCase().includes('etimedout')) {
        reconnectBot();
    }
});

process.on('uncaughtException', (err) => {
    logger.setColor('#ff5555');
    logger.updateLastLine(`Uncaught exception: ${err.message}`);
    if (err.message.toLowerCase().includes('timeout') || err.message.toLowerCase().includes('socket') || err.message.toLowerCase().includes('network') || err.message.toLowerCase().includes('econn') || err.message.toLowerCase().includes('etimedout')) {
        reconnectBot();
    }
});

// Launch Bot with Auto-Retry
async function startBot() {
    try {
        await delay(800); // Brief delay so the user can see the success status
        logger.add('Connecting to Telegram API...');
        
        // Clear old webhook/sessions to resolve 409 Conflict with old token instances
        try {
            await bot.telegram.deleteWebhook({ drop_pending_updates: true });
        } catch (e) {
            // Ignore
        }

        // Verify connection using getMe to confirm it's connected successfully
        await bot.telegram.getMe();

        // Launch in background so it doesn't block the execution flow
        bot.launch().catch(err => {
            logger.setColor('#ff5555'); // Error neon red border
            logger.updateLastLine(`Bot runtime error: ${err.message}`);
            reconnectBot();
        });

        logger.setColor('#50fa7b'); // Success neon green border
        logger.updateLastLine('TeleBUG Bot connected successfully!');
    } catch (err) {
        logger.setColor('#ff5555'); // Error neon red border
        logger.updateLastLine(`Failed to connect: ${err.message}`);
        reconnectBot();
    }
}

startBot();

// Enable graceful stop
process.once('SIGINT', () => {
    logger.log('\n[ SYSTEM ] Stopping bot gracefully...');
    try {
        bot.stop('SIGINT');
    } catch (e) {
        // Suppress "Bot is not running" error
    }
    process.exit(0);
});
process.once('SIGTERM', () => {
    logger.log('\n[ SYSTEM ] Stopping bot gracefully...');
    try {
        bot.stop('SIGTERM');
    } catch (e) {
        // Suppress
    }
    process.exit(0);
});
