const { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeCacheableSignalKeyStore 
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const readline = require("readline");

// Import Modules
const { getStockData } = require('./lib/sheets');
const { getKimiResponse } = require('./lib/kimi');
const { getHistory, addMessage } = require('./lib/history');
const { createQRISBuffer } = require('./lib/qris');

// --- LOAD .env FILE (Adaptasi MarinMD) ---
try {
    const envPath = path.join(__dirname, '.env');
    if (fs.existsSync(envPath)) {
        fs.readFileSync(envPath, 'utf8').split('\n').forEach(line => {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('#')) return;
            const [key, ...val] = trimmed.split('=');
            if (key && val.length) process.env[key.trim()] = val.join('=').trim();
        });
        console.log('\x1b[32m[OK] .env loaded successfully.\x1b[0m');
    }
} catch (_) { }

// Setup Readline untuk Pairing Code
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

// --- CUSTOM PAIRING CODE (Adaptasi MarinMD) ---
const CUSTOM_PAIRING_CODE = process.env.CUSTOM_PAIRING_CODE || 'NAKUNBOT';

// --- FILTER LOG SISTEM (Adaptasi MarinMD) ---
const originalLog = console.log;
const logFilter = (args) => {
    const msg = args[0];
    if (typeof msg === 'string' && (
        msg.includes('Closing session') ||
        msg.includes('incoming prekey bundle') ||
        msg.includes('SessionEntry')
    )) return true;
    return false;
};
console.log = function () { if (!logFilter(arguments)) originalLog.apply(console, arguments); };

// Custom UI Colors
const c = {
    cyan: (text) => `\x1b[36m${text}\x1b[0m`,
    yellow: (text) => `\x1b[33m${text}\x1b[0m`,
    green: (text) => `\x1b[32m${text}\x1b[0m`,
    red: (text) => `\x1b[31m${text}\x1b[0m`,
    magenta: (text) => `\x1b[35m${text}\x1b[0m`,
};

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');
    const { version } = await fetchLatestBaileysVersion();
    
    const sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: 'fatal' }),
        browser: ["Ubuntu", "Chrome", "20.0.04"],
    });

    // --- CUSTOM: Inject CUSTOM_PAIRING_CODE ke Message ID (Mencegah Loop) ---
    const originalSendMessage = sock.sendMessage;
    sock.sendMessage = async (jid, content, options = {}) => {
        if (!options.messageId) {
            options.messageId = CUSTOM_PAIRING_CODE + Math.random().toString(36).substring(2, 10).toUpperCase();
        }
        return originalSendMessage.call(sock, jid, content, options);
    };

    // LOGIKA PAIRING CODE
    if (!state.creds.registered) {
        console.clear();
        console.log(c.cyan('╔════════════════════════════════════════╗'));
        console.log(c.cyan('║       NAKUNSTORE CS BOT - LOGIN        ║'));
        console.log(c.cyan('╚════════════════════════════════════════╝'));
        console.log(c.yellow('\n[!] Gunakan nomor yang diawali kode negara (cth: 628xxx)'));
        const phoneNumber = await question(c.green('Masukkan Nomor WhatsApp Bot: '));
        
        console.log(c.yellow('\n[PAIR] Meminta kode pairing...'));
        setTimeout(async () => {
            try {
                // Menggunakan CUSTOM_PAIRING_CODE sebagai argumen kedua (Fitur Custom Baileys Fork)
                let code = await sock.requestPairingCode(phoneNumber.replace(/[^0-9]/g, ''), CUSTOM_PAIRING_CODE);
                code = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(c.magenta(`\n[PAIR] KODE ANDA: ${code}`));
                console.log(c.magenta('[PAIR] Masukkan kode ini di: WA > Perangkat Tertaut > Tautkan Perangkat > Tautkan dengan nomor telepon saja\n'));
            } catch (err) {
                console.log(c.red('[ERR] Gagal meminta kode: ' + err.message));
            }
        }, 3000);
    }

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect.error instanceof Boom) ? 
                lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut : true;
            console.log(c.red(`[DC] Koneksi terputus. Reconnecting: ${shouldReconnect}`));
            if (shouldReconnect) connectToWhatsApp();
        } else if (connection === 'open') {
            console.log(c.green('\n[ON] Bot Customer Service NakunStore Aktif!'));
        }
    });

    // HANDLE PESAN MASUK
    sock.ev.on('messages.upsert', async m => {
        const msg = m.messages[0];
        if (!msg.message || msg.key.fromMe) return;

        // FILTER ANTI-LOOP: Abaikan pesan yang mengandung CUSTOM_PAIRING_CODE di ID-nya
        if (msg.key.id && msg.key.id.includes(CUSTOM_PAIRING_CODE)) return;

        const from = msg.key.remoteJid;
        if (!from || from === 'status@broadcast') return;

        const body = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
        if (!body) return;

        console.log(c.cyan(`[MSG] ${msg.pushName || 'User'}: "${body}"`));

        await sock.sendPresenceUpdate('composing', from);
        
        // Ambil Data & History
        const currentStock = await getStockData();
        const history = getHistory(from);
        const historyText = history.length > 0 ? `\n\nRiwayat Chat:\n${history.join('\n')}` : "";

        // Gabungkan Prompt Sesuai Instruksi User (SUPER KETAT)
        const systemInstruction = `Kamu adalah CS NakunStore. Jawab SEPENDEK MUNGKIN.
- Jika disapa (halo/p), jawab saja: "Halo kak, ada yang bisa dibantu?" (JANGAN kasih daftar produk).
- JANGAN berikan daftar produk kecuali pelanggan bertanya "apa saja produknya" atau sejenisnya.
- JANGAN sebutkan stok.
- Pembayaran WAJIB QRIS. Jika pelanggan ingin bayar, tanya: "Nominal berapa kak?"
- Jika pelanggan kasih angka setelah ditanya nominal, jawab: "Ini QRIS-nya: [ORDER_QRIS: angka]"
- Pengetahuan produk (gunakan HANYA jika ditanya): [${currentStock}]
- DILARANG menggunakan kata-kata pembuka/penutup yang panjang. Langsung ke inti.`;

        const prompt = `${systemInstruction}${historyText}\n\nPertanyaan pelanggan: [${body}]`;
        
        let aiResponse = await getKimiResponse(prompt);

        // FITUR QRIS ASLI (MarinMD)
        if (aiResponse.includes('[ORDER_QRIS:')) {
            const nominalStr = aiResponse.match(/\[ORDER_QRIS: (.*?)\]/)?.[1] || "0";
            const nominal = parseInt(nominalStr.replace(/[^0-9]/g, '')) || 0;
            aiResponse = aiResponse.replace(/\[ORDER_QRIS: .*?\]/, "").trim(); // Hapus kode dari chat user
            
            // Kirim Jawaban AI
            await sock.sendMessage(from, { text: aiResponse }, { quoted: msg });
            
            if (nominal >= 100) {
                // Generate QRIS Asli dengan Frame
                const imageBuffer = await createQRISBuffer(nominal);
                
                await sock.sendMessage(from, { 
                    image: imageBuffer, 
                    caption: `*QRIS DINAMIS NAKUNSTORE*\nNominal: Rp${nominal.toLocaleString('id-ID')}\n\n_Silakan scan menggunakan e-wallet (Dana, OVO, ShopeePay, m-Banking, dll) dan kirim bukti transfer ke sini._`
                });
            }
        } else {
            await sock.sendMessage(from, { text: aiResponse }, { quoted: msg });
        }
        await sock.sendPresenceUpdate('paused', from);
    });
}

connectToWhatsApp().catch(err => console.error(c.red("[FATAL ERROR]"), err));

