const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

// --- LOAD .env FILE ---
try {
    const envPath = path.join(__dirname, '.env');
    if (fs.existsSync(envPath)) {
        fs.readFileSync(envPath, 'utf8').split('\n').forEach(line => {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('#')) return;
            const [key, ...val] = trimmed.split('=');
            if (key && val.length) process.env[key.trim()] = val.join('=').trim();
        });
        console.log('\x1b[32m[OK] .env loaded successfully for Telegram Bot.\x1b[0m');
    }
} catch (_) { }

// Import Modules
const { getStockData } = require('./lib/sheets');
const { getKimiResponse } = require('./lib/kimi');
const { getHistory, addMessage } = require('./lib/history');

// Konfigurasi
const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) {
    console.error('\x1b[31m[ERR] TELEGRAM_BOT_TOKEN tidak ditemukan di .env!\x1b[0m');
    process.exit(1);
}

// Inisialisasi Bot Telegram
const bot = new TelegramBot(token, { polling: true });

console.log('\x1b[36m[ON] Telegram Bot untuk Testing NakunStore Aktif!\x1b[0m');

// Handle Pesan Masuk
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    if (!text) return;

    // Abaikan command start
    if (text === '/start') {
        return bot.sendMessage(chatId, "Halo! Saya adalah bot testing NakunStore. Silakan tanya apa saja mengenai produk atau stok kami.");
    }

    console.log(`\x1b[36m[TG MSG] ${msg.from.first_name || 'User'}: "${text}"\x1b[0m`);

    // 1. Tampilkan status 'typing'
    bot.sendChatAction(chatId, 'typing');

    // 2. Ambil data & history
    const currentStock = await getStockData();
    const history = getHistory(String(chatId));
    const historyText = history.length > 0 ? `\n\nRiwayat Chat:\n${history.join('\n')}` : "";

    // 3. Gabungkan Prompt Sesuai Instruksi User
    const systemInstruction = "Kamu adalah CS otomatis NakunStore yang ramah dan singkat. Jawab pertanyaan pelanggan dengan padat, langsung ke inti, dan gunakan bullet-points jika memberikan daftar. ";
    const prompt = `${systemInstruction}HANYA gunakan data berikut untuk menjawab: [${currentStock}]${historyText}\n\nPertanyaan pelanggan: [${text}]`;

    // 4. Dapatkan respon dari Kimi
    const aiResponse = await getKimiResponse(prompt);

    // 5. Simpan riwayat
    addMessage(String(chatId), 'User', text);
    addMessage(String(chatId), 'AI', aiResponse);

    // 7. Kirim Balasan
    bot.sendMessage(chatId, aiResponse, { parse_mode: 'Markdown' });
});

// Handle Errors
bot.on('polling_error', (error) => {
    console.error(`[TG ERR] Polling error: ${error.code} - ${error.message}`);
});
