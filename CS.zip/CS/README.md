# NakunStore Customer Service Bot

Bot WhatsApp otomatis berbasis Node.js yang terintegrasi dengan Gemini API (Gemini 2.5 Flash) dan Google Sheets untuk manajemen stok realtime.

## Fitur Utama
- **Pairing Code Login**: Koneksi ke WhatsApp tanpa scan QR, cukup masukkan nomor telepon di terminal.
- **Gemini AI Integration**: Menggunakan model `gemini-2.5-flash` untuk respon yang hemat dan efisien.
- **Realtime Google Sheets**: Mengambil data stok produk langsung dari spreadsheet setiap kali ada pesan masuk.
- **Smart History**: Mengingat 4-6 pesan terakhir untuk menjaga konteks percakapan tetap relevan namun hemat token.
- **Anti-Loop System**: Menggunakan custom message ID (pattern MarinMD) untuk mencegah bot merespons pesannya sendiri.

## Cara Instalasi

1. **Persiapan Folder**:
   Pastikan Anda berada di direktori proyek ini.

2. **Instal Dependensi**:
   ```bash
   npm install
   ```

3. **Konfigurasi Lingkungan (.env)**:
   Semua kredensial sensitif kini disimpan di file `.env`. 
   - `GEMINI_API_KEY`: API Key untuk Gemini.
   - `SPREADSHEET_ID`: ID Google Sheets data produk.
   - `GOOGLE_APPLICATION_CREDENTIALS`: Nama file JSON kredensial Google.

4. **Kredensial Google Sheets**:
   Pastikan file JSON kredensial (cth: `optical-mode-435812-m2-f1e797ae5615.json`) ada di direktori utama.

5. **Keamanan**:
   File `.gitignore` sudah disediakan untuk memastikan `.env` dan `auth_info` tidak terunggah ke repositori publik.

## Cara Menjalankan

### Mode Pengembangan (Terminal Aktif)
Gunakan mode ini untuk pertama kali login agar bisa memasukkan nomor telepon dan melihat kode pairing.
```bash
npm start
```
Ikuti instruksi di terminal:
1. Masukkan nomor WhatsApp bot (contoh: `628123456789`).
2. Tunggu hingga kode pairing muncul (contoh: `ABCD-EFGH`).
3. Di WhatsApp: **Perangkat Tertaut** > **Tautkan Perangkat** > **Tautkan dengan nomor telepon saja**.
4. Masukkan kode tersebut.

### Mode Produksi (Background dengan PM2)
Setelah berhasil login satu kali dan folder `auth_info` terbentuk, Anda bisa menjalankannya di background.
```bash
npx pm2 start index.js --name "nakun-cs-bot"
```

Untuk melihat log:
```bash
npx pm2 logs nakun-cs-bot
```

Untuk menghentikan bot:
```bash
npx pm2 stop nakun-cs-bot
```

## Struktur Proyek
- `index.js`: Entry point dan logika koneksi WhatsApp.
- `lib/sheets.js`: Modul integrasi Google Sheets.
- `lib/gemini.js`: Modul integrasi Gemini AI.
- `lib/history.js`: Manajemen riwayat chat pelanggan.
- `auth_info/`: Folder penyimpanan sesi WhatsApp (terbuat otomatis).
