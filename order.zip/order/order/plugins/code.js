const fs = require('fs');
const path = require('path');

const codesFile = path.join(__dirname, '../database/claim_codes.json');
const { saveCodeClaimToSheet } = require('../lib/gsheets');

// Ensure database directory and file exist
function getCodes() {
    if (!fs.existsSync(codesFile)) {
        const dir = path.dirname(codesFile);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(codesFile, JSON.stringify({}, null, 2), 'utf8');
        return {};
    }
    try {
        return JSON.parse(fs.readFileSync(codesFile, 'utf8') || '{}');
    } catch (e) {
        return {};
    }
}

function saveCodes(data) {
    fs.writeFileSync(codesFile, JSON.stringify(data, null, 2), 'utf8');
}

module.exports = {
    name: 'code',
    match: (body, state) => {
        const lowerBody = body.trim().toLowerCase();
        return lowerBody.startsWith('.code ') || 
               lowerBody.startsWith('.addcode ') || 
               lowerBody.startsWith('.delcode ') || 
               lowerBody === '.listcode';
    },
    execute: async (sock, m, context) => {
        const { from, sender, body, userStates, formatRupiah, checkUserDailyClaimLimit } = context;

        const senderNum = (sender || '').split('@')[0].split(':')[0];
        const isOwner = senderNum === '6285726013874';
        const cleanBody = body.trim();

        // ==========================================
        // 1. ADMIN COMMAND: .addcode [code] [discount_amount]
        // ==========================================
        if (cleanBody.toLowerCase().startsWith('.addcode ')) {
            if (!isOwner) {
                await sock.sendMessage(from, { text: '⚠️ Akses ditolak! Perintah ini khusus untuk Owner Bot.' });
                return;
            }

            const content = cleanBody.substring(9).trim();
            const spaceIdx = content.indexOf(' ');
            if (spaceIdx === -1) {
                await sock.sendMessage(from, { 
                    text: '⚠️ Format salah!\n\nGunakan: `.addcode [NAMA_CODE] [NOMINAL_DISKON]`\n\nContoh:\n`.addcode NAKUNHEMAT 1000` (diskon Rp 1.000)' 
                });
                return;
            }

            const codeName = content.substring(0, spaceIdx).trim().toUpperCase();
            const discountStr = content.substring(spaceIdx).trim();
            const discount = parseInt(discountStr.replace(/[^0-9]/g, ''));

            if (!codeName) {
                await sock.sendMessage(from, { text: '⚠️ Nama kode tidak boleh kosong!' });
                return;
            }

            if (isNaN(discount) || discount <= 0) {
                await sock.sendMessage(from, { text: '⚠️ Nominal diskon harus berupa angka positif yang valid!' });
                return;
            }

            const db = getCodes();
            db[codeName] = {
                discount,
                claimed: db[codeName] ? db[codeName].claimed : []
            };
            saveCodes(db);

            await sock.sendMessage(from, { 
                text: `✅ *KODE DISKON BERHASIL DIBUAT*\n\n🔑 Kode: *${codeName}*\n💰 Potongan: *${formatRupiah(discount)}*` 
            });
            return;
        }

        // ==========================================
        // 2. ADMIN COMMAND: .delcode [code]
        // ==========================================
        if (cleanBody.toLowerCase().startsWith('.delcode ')) {
            if (!isOwner) {
                await sock.sendMessage(from, { text: '⚠️ Akses ditolak! Perintah ini khusus untuk Owner Bot.' });
                return;
            }

            const codeName = cleanBody.substring(9).trim().toUpperCase();
            if (!codeName) {
                await sock.sendMessage(from, { text: '⚠️ Harap masukkan nama kode yang ingin dihapus!' });
                return;
            }

            const db = getCodes();
            if (!db[codeName]) {
                await sock.sendMessage(from, { text: `❌ Kode *${codeName}* tidak ditemukan.` });
                return;
            }

            delete db[codeName];
            saveCodes(db);

            await sock.sendMessage(from, { text: `✅ Kode *${codeName}* berhasil dihapus dari database.` });
            return;
        }

        // ==========================================
        // 3. ADMIN COMMAND: .listcode
        // ==========================================
        if (cleanBody.toLowerCase() === '.listcode') {
            if (!isOwner) {
                await sock.sendMessage(from, { text: '⚠️ Akses ditolak! Perintah ini khusus untuk Owner Bot.' });
                return;
            }

            const db = getCodes();
            const keys = Object.keys(db);

            if (keys.length === 0) {
                await sock.sendMessage(from, { text: 'ℹ️ Tidak ada kode diskon aktif saat ini.' });
                return;
            }

            let txt = `🔑 *DAFTAR KODE DISKON AKTIF (${keys.length}):*\n────────────────────────\n`;
            keys.forEach((k, i) => {
                txt += `${i + 1}. *${k}*\n   💰 Potongan: *${formatRupiah(db[k].discount)}*\n   👥 Di-klaim: *${db[k].claimed.length} user*\n────────────────────────\n`;
            });

            await sock.sendMessage(from, { text: txt.trim() });
            return;
        }

        // ==========================================
        // 4. USER COMMAND: .code [codename] (Apply Discount)
        // ==========================================
        if (cleanBody.toLowerCase().startsWith('.code ')) {
            const codeName = cleanBody.substring(6).trim().toUpperCase();
            if (!codeName) {
                await sock.sendMessage(from, { text: '⚠️ Harap masukkan kode diskon Anda!\n\nContoh: `.code NAKUNHEMAT`' });
                return;
            }

            const db = getCodes();
            const codeData = db[codeName];

            if (!codeData) {
                await sock.sendMessage(from, { text: '❌ *KODE DISKON TIDAK VALID*\n\nKode tersebut salah, tidak terdaftar, atau telah dinonaktifkan.' });
                return;
            }

            const rawNumber = (sender || from).split('@')[0].split(':')[0];
            
            // Check Daily Claim Limit in Google Sheet (Max 1x per 24 hours)
            const dailyCheck = await checkUserDailyClaimLimit(rawNumber);
            if (!dailyCheck.allowed) {
                await sock.sendMessage(from, { text: `❌ *BATAS KLAIM HARIAN TERPENUHI*\n\nAnda hanya diperbolehkan mengklaim kupon diskon maksimal *1 kali dalam 24 jam*.\n\nHarap tunggu *${dailyCheck.remainingHours} jam* lagi sebelum mengklaim kode kembali.` });
                return;
            }

            if (codeData.claimed.includes(rawNumber)) {
                await sock.sendMessage(from, { text: '❌ *BATAS KLAIM TERPENUHI*\n\nAnda sudah pernah menggunakan kode diskon ini sebelumnya (maksimal 1x per user).' });
                return;
            }

            // Mark discount code claimed instantly in local JSON database
            codeData.claimed.push(rawNumber);
            saveCodes(db);

            // Apply to active user state session
            const currentState = userStates.get(from) || {};
            userStates.set(from, {
                ...currentState,
                activeDiscount: {
                    code: codeName,
                    amount: codeData.discount
                }
            });

            // Save to Google Sheet instantly!
            const waktu = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
            saveCodeClaimToSheet({
                waktu,
                nomor: rawNumber,
                kode: codeName,
                diskon: codeData.discount
            }).catch(e => console.error('[GSheets Claim Sync Error]:', e));

            const successMsg = `
🎉 *KODE DISKON BERHASIL DITERAPKAN!*
────────────────────────
  🔑 Kode     : *${codeName}*
  💰 Potongan : *${formatRupiah(codeData.discount)}*
────────────────────────
Potongan harga akan otomatis digunakan pada transaksi/pesanan Anda berikutnya di bot ini!
            `.trim();

            await sock.sendMessage(from, { text: successMsg });
            return;
        }
    }
};
