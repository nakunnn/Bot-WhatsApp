const fs = require('fs');
const path = require('path');
const { getDoc } = require('../lib/gsheets');

module.exports = {
    name: 'cek',
    description: 'Mengecek status transaksi berdasarkan Order ID',
    match(body) {
        const clean = body.trim().toLowerCase();
        return clean.startsWith('.cek') || clean.startsWith('cek');
    },
    execute: async (sock, m, context) => {
        const { from, body, lowerBody, formatRupiah } = context;

        const parts = body.trim().split(/\s+/);
        if (parts.length < 2) {
            await sock.sendMessage(from, { text: '⚠️ *FORMAT SALAH*\n\nSilakan gunakan format:\n*.cek [ID_TRANSAKSI]*\n\n_Contoh: .cek TRX-F9X2A_' });
            return;
        }

        const targetId = parts[1].trim().toUpperCase();
        await sock.sendMessage(from, { react: { text: '🔍', key: m.key } }).catch(() => { });

        try {
            // 1. Cari di Google Sheets 'botorder'
            const doc = await getDoc();
            const sheet = doc.sheetsByTitle['botorder'];
            let foundInSheet = null;

            if (sheet) {
                const rows = await sheet.getRows();
                foundInSheet = rows.find(row => {
                    const rowId = (row.get('Order ID') || '').toString().trim().toUpperCase();
                    return rowId === targetId;
                });
            }

            if (foundInSheet) {
                const orderId = foundInSheet.get('Order ID') || targetId;
                const waktu = foundInSheet.get('Waktu') || '-';
                const nomor = foundInSheet.get('Nomor') || '-';
                const produk = foundInSheet.get('Produk') || '-';
                const nominal = foundInSheet.get('Nominal') || '0';

                const successText = `🔍 𝐃𝐄𝐓𝐀𝐈𝐋 𝐓𝐑𝐀𝐍𝐒𝐀𝐊𝐒𝐈 ❱

 ⟡ *Order ID* : ${orderId}
 ⟡ *Produk*   : ${produk}
 ⟡ *Nomor*    : ${nomor}
 ⟡ *Waktu*    : ${waktu}
 ⟡ *Nominal*  : ${formatRupiah(parseInt(nominal))}
 ⟡ *Status*   : ✅ *SUCCESS*

©NakunStore`.trim();

                await sock.sendMessage(from, { react: { text: '✅', key: m.key } }).catch(() => { });
                await sock.sendMessage(from, { text: successText });
                return;
            }

            // 2. Fallback: Cari di local processed deposits
            const processedFile = path.join(__dirname, '../database/processed_deposits.json');
            if (fs.existsSync(processedFile)) {
                try {
                    const localData = JSON.parse(fs.readFileSync(processedFile, 'utf8') || '{}');
                    if (localData[targetId]) {
                        const info = localData[targetId];
                        const dateStr = new Date(info.processedAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
                        const successText = `🔍 𝐃𝐄𝐓𝐀𝐈𝐋 𝐓𝐑𝐀𝐍𝐒𝐀𝐊𝐒𝐈 ❱

 ⟡ *Order ID* : ${targetId}
 ⟡ *Waktu*    : ${dateStr} WIB
 ⟡ *Nominal*  : ${formatRupiah(info.price || 0)}
 ⟡ *Status*   : ✅ *SUCCESS*

©NakunStore`.trim();

                        await sock.sendMessage(from, { react: { text: '✅', key: m.key } }).catch(() => { });
                        await sock.sendMessage(from, { text: successText });
                        return;
                    }
                } catch (e) { }
            }

            // 3. Fallback: Cari di local failed deposits (Expired)
            const failedFile = path.join(__dirname, '../database/failed_deposits.json');
            if (fs.existsSync(failedFile)) {
                try {
                    const failedData = JSON.parse(fs.readFileSync(failedFile, 'utf8') || '{}');
                    if (failedData[targetId]) {
                        const info = failedData[targetId];
                        const dateStr = new Date(info.failedAt || Date.now()).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
                        const expiredText = `🔍 𝐃𝐄𝐓𝐀𝐈𝐋 𝐓𝐑𝐀𝐍𝐒𝐀𝐊𝐒𝐈 ❱

 ⟡ *Order ID* : ${targetId}
 ⟡ *Waktu*    : ${dateStr} WIB
 ⟡ *Nominal*  : ${formatRupiah(info.price || 0)}
 ⟡ *Status*   : ❌ *EXPIRED / FAILED*

©NakunStore`.trim();

                        await sock.sendMessage(from, { react: { text: '❌', key: m.key } }).catch(() => { });
                        await sock.sendMessage(from, { text: expiredText });
                        return;
                    }
                } catch (e) { }
            }

            // 4. Jika benar-benar tidak ditemukan
            await sock.sendMessage(from, { react: { text: '❓', key: m.key } }).catch(() => { });
            await sock.sendMessage(from, {
                text: `❌ *ORDER ID TIDAK DITEMUKAN*\n\nOrder ID *${targetId}* tidak terdaftar di sistem.\n\n_Pastikan ID yang dimasukkan sudah benar atau silakan hubungi Owner jika Anda memiliki kendala pembayaran._`
            });

        } catch (error) {
            console.error('[Cek Order Error]:', error);
            await sock.sendMessage(from, { react: { text: '⚠️', key: m.key } }).catch(() => { });
            await sock.sendMessage(from, { text: '⚠️ Terjadi kesalahan koneksi saat memeriksa transaksi di Google Sheets. Silakan coba lagi.' });
        }
    }
};
