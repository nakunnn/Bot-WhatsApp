module.exports = {
    name: 'menu',
    match: (body) => {
        const lowerBody = body.toLowerCase();
        return [
            '.menu', 'menu', '.start', '/start', 'start', 'nakunorder',
            'menu_uncheck', 'menu_bug', 'menu_file', 'menu_pricelist', 'menu_panel',
            'sub_uncheck:gg', 'sub_uncheck:premium', 'sub_uncheck:vvip', 'sub_uncheck:antizonk',
            'sub_file:bodylock', 'sub_file:drag_hs', 'sub_file:easy_drag', 'sub_file:apk', 'sub_file:tutor'
        ].includes(lowerBody);
    },
    execute: async (sock, m, context) => {
        const { from, lowerBody, sendButtons, getProductLink } = context;

        const { getSettings } = require('../lib/settings');
        const settings = getSettings();

        // Main Menu
        if ([
            '.menu', 'menu', '.start', '/start', 'start', 'nakunorder'
        ].includes(lowerBody)) {
            const botStatus = settings.maintenanceMode ? '🚨 *MAINTENANCE*' : 'Online';
            const caption = `
 ───────『𝐍𝐚𝐤𝐮𝐧𝐎𝐫𝐝𝐞𝐫』───────
╰┈➤ 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : ❐ NakunBOT
╰┈➤ 𝐎𝐰𝐧𝐞𝐫 : +6285726013874
╰┈➤ 𝐒𝐭𝐚𝐭𝐮𝐬 : ${botStatus}

Silakan pilih kategori menu toko di bawah ini untuk melihat produk yang tersedia:
            `.trim();

            const path = require('path');
            const menuImage = path.join(__dirname, '../media/banner.jpeg');

            await sendButtons(from, "", caption, '  ❐ NakunBOT | © MARIN V15', [
                { displayText: `Menu Bug ${settings.features.bug ? '🚨' : ''}`, id: 'menu_bug' },
                { displayText: `Menu File ${settings.features.file ? '🚨' : ''}`, id: 'menu_file' },
                { displayText: `Menu Uncheck ${settings.features.uncheck ? '🚨' : ''}`, id: 'menu_uncheck' },
                { displayText: `Menu Panel ${settings.features.panel ? '🚨' : ''}`, id: 'menu_panel' },
                { displayText: 'Pricelist', id: 'menu_pricelist' },
                { displayText: 'Tanya Admin', url: 'https://wa.me/6285879673319' },
                { displayText: 'Testimoni', url: 'https://whatsapp.com/channel/0029VbC3DioDeONBPSW8hH3n' }
            ], menuImage);
            return;
        }

        // Panel Menu
        if (lowerBody === 'menu_panel') {
            const caption = `Silakan pilih spesifikasi server panel Pterodactyl yang ingin Anda pesan di bawah ini:`.trim();

            await sendButtons(from, "𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔", caption, 'Nakun Pterodactyl Catalog', [
                { displayText: 'Panel 1GB RAM (Rp 2.000)', id: 'select_panel:1gb:2000' },
                { displayText: 'Panel 2GB RAM (Rp 3.000)', id: 'select_panel:2gb:3000' },
                { displayText: 'Panel 3GB RAM (Rp 4.000)', id: 'select_panel:3gb:4000' },
                { displayText: 'Panel 4GB RAM (Rp 5.000)', id: 'select_panel:4gb:5000' },
                { displayText: 'Panel 5GB RAM (Rp 6.000)', id: 'select_panel:5gb:6000' },
                { displayText: 'Panel 6GB RAM (Rp 7.000)', id: 'select_panel:6gb:7000' },
                { displayText: 'Panel 7GB RAM (Rp 8.000)', id: 'select_panel:7gb:8000' },
                { displayText: 'Panel 8GB RAM (Rp 9.000)', id: 'select_panel:8gb:9000' },
                { displayText: 'Panel 9GB RAM (Rp 10.000)', id: 'select_panel:9gb:10000' },
                { displayText: 'Panel 10GB RAM (Rp 11.000)', id: 'select_panel:10gb:11000' },
                { displayText: 'Panel 11GB RAM (Rp 12.000)', id: 'select_panel:11gb:12000' },
                { displayText: 'Panel 12GB RAM (Rp 13.000)', id: 'select_panel:12gb:13000' },
                { displayText: 'Panel 13GB RAM (Rp 14.000)', id: 'select_panel:13gb:14000' },
                { displayText: 'Panel 14GB RAM (Rp 15.000)', id: 'select_panel:14gb:15000' },
                { displayText: 'Panel 15GB RAM (Rp 16.000)', id: 'select_panel:15gb:16000' },
                { displayText: 'Panel Unlimited (Rp 20.000)', id: 'select_panel:unlimited:20000' },
                { displayText: 'Kembali Ke Menu Utama', id: 'menu' }
            ]);
            return;
        }

        // Pricelist Menu
        if (lowerBody === 'menu_pricelist') {
            const caption = `
*FFKIPAS 5K*
*BOT BUG WA: 15K*
*GAMEBOOSTER VIP : 5K*
*FF V7A : 5K*

🔥 *FILE & CHEAT FF*
🔰*[ BASIC TOOLS ]*
🛠️ *FF V7A* — 3.000
🛠️ *Panel Remote* — 10.000
🧹 *Penghapus File* — 5.000

🔰 *[ AIM & DRAG ]*
🎯 *Aimlock 70% - 89%* — _5k - 10k_
🎯 *Aimlock V1 - VVIP* — _10k - 20k_
🕹️ *Easy Drag V1 - 95%* — _5k - 20k_
🕹️ *Drag HS 70% - 83%* — _10k - 40k_
_full pricelist chat admin_

🔰 *[ COMBO STABILIZER ]*
⚡ *HS 75% + Stab* — _10.000_
⚡ *HS 83% + Stab* — _15.000_
⚡ *HS 85% + Stab* — _20.000_
⚡ *HS 90% + Stab* — _35.000_


*🔰[ UNCHEK GG ]*
*💌 5 UNCHEK - 4K* ~7k~
*💌 15 UNCHEK - 8K* ~15k~
*💌 25 UNCHEK - 18K* ~25k~
*💌 40 UNCHEK - 28K* ~35k~
*💌 100 UNCHEK - 38K* ~45k~
*💌 150 UNCHEK - 48K* ~100k~

*🔰[ UNCHECK PREMIUM ]*
*🎁 20 UNCHEK - 14K* ~20k~
*🎁 30 UNCHEK - 19K* ~29k~
*🎁 40 UNCHEK - 24K* ~35k~
*🎁 50 UNCHEK - 29K* ~39k~
*🎁 100 UNCHEK - 49K* ~70k~
*BELI DI ATAS 50K PASTI DAPET POLOSAN SG*

*🔰[ UNCHECK VVIP ]*
*🎁 20 UNCHEK - 19K* ~30k~
*🎁 30 UNCHEK - 29K* ~35k~
*🎁 40 UNCHEK - 39K* ~40k~
*🎁 50 UNCHEK - 49K* ~45k~
*🎁 100 UNCHEK - 69K* ~80k~
*BELI DIATAS 50K PASTI DAPET AKUN OLD S1 S2 S3 S4*

*🔰[ UNCHECK ANTI ZONK ]*
*⚜️ 10 UNCHEK - 29K* ~50k~
*⚜️ 20 UNCHEK - 39K* ~70k~
*⚜️ 25 UNCHEK - 49K* ~90k~
*⚜️ 30 UNCHEK - 59K* ~100k~
*⚜️ 60 UNCHEK - 99K* ~150k~
*UNCHECK ANTI ZONK 100%*
*GADAPET? DIGANTI*
            `.trim();

            await sendButtons(from, "𝐏𝐑𝐈𝐂𝐄𝐋𝐈𝐒𝐓", caption, '  ❐ NakunBOT | © MARIN V15', [
                { displayText: 'Menu Utama', id: 'menu' }
            ]);
            return;
        }

        // Uncheck Menu
        if (lowerBody === 'menu_uncheck') {
            const caption = `Silakan pilih kategori Uncheck di bawah ini:`.trim();

            await sendButtons(from, "𝐔𝐍𝐂𝐇𝐄𝐂𝐊 𝐌𝐄𝐍𝐔", caption, 'Nakun Uncheck Catalog', [
                { displayText: 'Uncheck GG', id: 'sub_uncheck:gg' },
                { displayText: 'Uncheck Premium', id: 'sub_uncheck:premium' },
                { displayText: 'Uncheck VVIP', id: 'sub_uncheck:vvip' },
                { displayText: 'Uncheck Anti Zonk', id: 'sub_uncheck:antizonk' },
                { displayText: 'Kembali Ke Menu Utama', id: 'menu' }
            ]);
            return;
        }

        if (lowerBody === 'sub_uncheck:gg') {
            const caption = `Silakan pilih jumlah Uncheck GG di bawah ini:`.trim();

            await sendButtons(from, "𝐔𝐍𝐂𝐇𝐄𝐂𝐊 𝐆𝐆", caption, 'GG Series', [
                { displayText: '5 UNCHECK (Rp 4.000)', id: 'select_uncheck:gg:5:4000' },
                { displayText: '15 UNCHECK (Rp 8.000)', id: 'select_uncheck:gg:15:8000' },
                { displayText: '25 UNCHECK (Rp 18.000)', id: 'select_uncheck:gg:25:18000' },
                { displayText: '40 UNCHECK (Rp 28.000)', id: 'select_uncheck:gg:40:28000' },
                { displayText: '100 UNCHECK (Rp 38.000)', id: 'select_uncheck:gg:100:38000' },
                { displayText: '150 UNCHECK (Rp 48.000)', id: 'select_uncheck:gg:150:48000' },
                { displayText: 'Kembali', id: 'menu_uncheck' }
            ]);
            return;
        }

        if (lowerBody === 'sub_uncheck:premium') {
            const caption = `
Silakan pilih jumlah Uncheck Premium di bawah ini:

*Info:* BELI DI ATAS 50K PASTI DAPET POLOSAN SG
            `.trim();

            await sendButtons(from, "𝐔𝐍𝐂𝐇𝐄𝐂𝐊 𝐏𝐑𝐄𝐌𝐈𝐔𝐌", caption, 'Premium Series', [
                { displayText: '5 UNCHECK (Rp 9.000)', id: 'select_uncheck:premium:5:9000' },
                { displayText: '30 UNCHECK (Rp 19.000)', id: 'select_uncheck:premium:30:19000' },
                { displayText: '40 UNCHECK (Rp 24.000)', id: 'select_uncheck:premium:40:24000' },
                { displayText: '50 UNCHECK (Rp 29.000)', id: 'select_uncheck:premium:50:29000' },
                { displayText: '100 UNCHECK (Rp 49.000)', id: 'select_uncheck:premium:100:49000' },
                { displayText: 'Kembali', id: 'menu_uncheck' }
            ]);
            return;
        }

        if (lowerBody === 'sub_uncheck:vvip') {
            const caption = `
Silakan pilih jumlah Uncheck VVIP di bawah ini:

*Info:* BELI DIATAS 50K PASTI DAPET AKUN OLD S1 S2 S3 S4
            `.trim();

            await sendButtons(from, "𝐔𝐍𝐂𝐇𝐄𝐂𝐊 𝐕𝐕𝐈𝐏", caption, 'VVIP Series', [
                { displayText: '20 UNCHECK (Rp 19.000)', id: 'select_uncheck:vvip:20:19000' },
                { displayText: '30 UNCHECK (Rp 29.000)', id: 'select_uncheck:vvip:30:29000' },
                { displayText: '40 UNCHECK (Rp 39.000)', id: 'select_uncheck:vvip:40:39000' },
                { displayText: '50 UNCHECK (Rp 49.000)', id: 'select_uncheck:vvip:50:49000' },
                { displayText: '100 UNCHECK (Rp 69.000)', id: 'select_uncheck:vvip:100:69000' },
                { displayText: 'Kembali', id: 'menu_uncheck' }
            ]);
            return;
        }

        if (lowerBody === 'sub_uncheck:antizonk') {
            const caption = `
Silakan pilih jumlah Uncheck Anti Zonk di bawah ini:

*Info:* UNCHECK ANTI ZONK 100% GADAPET? DIGANTI
            `.trim();

            await sendButtons(from, "𝐔𝐍𝐂𝐇𝐄𝐂𝐊 𝐀𝐍𝐓𝐈 𝐙𝐎𝐍𝐊", caption, 'Anti Zonk Series', [
                { displayText: '10 UNCHECK (Rp 29.000)', id: 'select_uncheck:antizonk:10:29000' },
                { displayText: '20 UNCHECK (Rp 39.000)', id: 'select_uncheck:antizonk:20:39000' },
                { displayText: '25 UNCHECK (Rp 49.000)', id: 'select_uncheck:antizonk:25:49000' },
                { displayText: '30 UNCHECK (Rp 59.000)', id: 'select_uncheck:antizonk:30:59000' },
                { displayText: '60 UNCHECK (Rp 99.000)', id: 'select_uncheck:antizonk:60:99000' },
                { displayText: 'Kembali', id: 'menu_uncheck' }
            ]);
            return;
        }

        // Bug Menu
        if (lowerBody === 'menu_bug') {
            const caption = `Silakan pilih jenis bug yang ingin dipesan di bawah ini:`.trim();

            await sendButtons(from, "𝐁𝐔𝐆 𝐌𝐄𝐍𝐔", caption, 'Nakun Bug Catalog', [
                { displayText: 'Bug Ringan (Rp 2.000)', id: 'select_bug:ringan:2000' },
                { displayText: 'Bug Normal (Rp 3.000)', id: 'select_bug:normal:3000' },
                { displayText: 'Bug Blank (Rp 4.000)', id: 'select_bug:blank:4000' },
                { displayText: 'Bug Crash (Rp 5.000)', id: 'select_bug:crash:5000' },
                { displayText: 'Bug Invisible (Rp 10.000)', id: 'select_bug:invisible:10000' },
                { displayText: 'Bug IP (Rp 10.000)', id: 'select_bug:ip:10000' },
                { displayText: 'Bug KENON (Rp 20.000)', id: 'select_bug:kenon:20000' },
                { displayText: 'Kembali Ke Menu', id: 'menu' }
            ]);
            return;
        }

        // File Menu
        if (lowerBody === 'menu_file') {
            const caption = `Silakan pilih kategori berkas premium di bawah ini:`.trim();

            await sendButtons(from, "𝐅𝐈𝐋𝐄 𝐌𝐄𝐍𝐔", caption, 'Nakun File Sub-Catalog', [
                { displayText: 'Bodylock', id: 'sub_file:bodylock' },
                { displayText: 'Drag HS', id: 'sub_file:drag_hs' },
                { displayText: 'Easy Drag', id: 'sub_file:easy_drag' },
                { displayText: 'APK Mod', id: 'sub_file:apk' },
                { displayText: 'Tutor Pemasangan', id: 'sub_file:tutor' },
                { displayText: 'Kembali Ke Menu Utama', id: 'menu' }
            ]);
            return;
        }

        if (lowerBody === 'sub_file:bodylock') {
            const caption = `Silakan pilih jenis script Bodylock di bawah ini:`.trim();

            await sendButtons(from, "𝐁𝐎𝐃𝐘𝐋𝐎𝐂𝐊", caption, 'Aimlock Series', [
                { displayText: 'Aimlock 70% (Rp 4.000)', id: 'select_file:bl_70' },
                { displayText: 'Aimlock 80% (Rp 6.000)', id: 'select_file:bl_80' },
                { displayText: 'Aimlock VIP (Rp 14.000)', id: 'select_file:bl_vip' },
                { displayText: 'Aimlock VVIP (Rp 16.000)', id: 'select_file:bl_vvip' },
                { displayText: 'Kembali', id: 'menu_file' }
            ]);
            return;
        }

        if (lowerBody === 'sub_file:drag_hs') {
            const caption = `Silakan pilih jenis script Drag HS di bawah ini:`.trim();

            await sendButtons(from, "𝐃𝐑𝐀𝐆 𝐇𝐒", caption, 'Combo Stabilizer Series', [
                { displayText: 'DRAG HS 75% (Rp 10.000)', id: 'select_file:dhs_75' },
                { displayText: 'DRAG HS 85% (Rp 15.000)', id: 'select_file:dhs_85' },
                { displayText: 'DRAG HS 89% (Rp 28.000)', id: 'select_file:dhs_89' },
                { displayText: 'DRAG HS 90% (Rp 40.000)', id: 'select_file:dhs_90' },
                { displayText: 'Kembali', id: 'menu_file' }
            ]);
            return;
        }

        if (lowerBody === 'sub_file:easy_drag') {
            const caption = `Silakan pilih jenis script Easy Drag di bawah ini:`.trim();

            await sendButtons(from, "𝐄𝐀𝐒𝐘 𝐃𝐑𝐀𝐆", caption, 'Easy Drag Series', [
                { displayText: 'Easy Drag 60% (Rp 4.000)', id: 'select_file:ed_60' },
                { displayText: 'Easy Drag 75% (Rp 6.000)', id: 'select_file:ed_75' },
                { displayText: 'Kembali', id: 'menu_file' }
            ]);
            return;
        }

        if (lowerBody === 'sub_file:apk') {
            const caption = `Silakan pilih APK premium di bawah ini:`.trim();

            await sendButtons(from, "𝐀𝐏𝐊 𝐌𝐎𝐃𝐒", caption, 'APK Mods Series', [
                { displayText: 'FF V7A (Rp 5.000)', id: 'select_file:ffv7a' },
                { displayText: 'FFKIPAS (Rp 5.000)', id: 'select_file:ffkipas' },
                { displayText: 'GGMPRO (Rp 5.000)', id: 'select_file:ggmpro' },
                { displayText: 'GAMEBOOSTER (Rp 5.000)', id: 'select_file:gamebooster' },
                { displayText: 'Kembali', id: 'menu_file' }
            ]);
            return;
        }

        if (lowerBody === 'sub_file:tutor') {
            const tutorLink = getProductLink('tutor');
            const caption = `
Berikut panduan cara pemasangan dan penggunaan script/APK NakunTools:

1. Download file/APK yang sudah Anda beli melalui link resmi yang diberikan.
2. Ekstrak file jika berformat .zip/.rar menggunakan aplikasi ZArchiver.
3. Untuk Script (Bodylock, Drag HS, Easy Drag): Pindahkan file payload ke folder data game sesuai instruksi.
4. Untuk APK: Hapus versi game original terlebih dahulu, lalu install APK mod yang baru.
5. Aktifkan perizinan aplikasi di pengaturan HP Anda.

Link Video Tutorial Pemasangan Lengkap:
🔗 ${tutorLink}
            `.trim();

            await sendButtons(from, "𝐓𝐔𝐓𝐎𝐑𝐈𝐀𝐋 𝐆𝐔𝐈𝐃𝐄", caption, 'Nakun Tutor', [
                { displayText: 'Kembali Ke Menu File', id: 'menu_file' },
                { displayText: 'Menu Utama', id: 'menu' }
            ]);
            return;
        }
    }
};
