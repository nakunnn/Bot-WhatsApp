module.exports = {
    name: 'payment',
    match: (body, state) => {
        return body.toLowerCase().startsWith('check_order_pay:');
    },
    execute: async (sock, m, context) => {
        const { from, body, userStates, formatRupiah, getOrderState, deleteOrderState, isOrderProcessed, markOrderProcessed, fetchPakasirStatus, executeBugDelivery, executeFileDelivery, executeUncheckDelivery, executePanelDelivery, markCodeClaimed } = context;

        const parts = body.split(':');
        const orderId = parts[1];
        const price = parseInt(parts[2]);

        const currentState = getOrderState(from, orderId);
        if (!currentState || currentState.orderId !== orderId) {
            await sock.sendMessage(from, { text: 'Transaksi tidak aktif atau telah kadaluwarsa.' });
            return;
        }

        if (isOrderProcessed(orderId)) {
            await sock.sendMessage(from, { text: 'Pesanan ini sudah diproses.' });
            return;
        }

        const apiKey = process.env.PAKASIR;
        const slug = process.env.PAKASIR_SLUG || 'nakuntools';

        if (!apiKey) {
            await sock.sendMessage(from, { text: 'Kesalahan Konfigurasi: API Key Pembayaran tidak ditemukan.' });
            return;
        }

        const checkResult = await fetchPakasirStatus(slug, price, orderId, apiKey);

        if (checkResult && checkResult.transaction && checkResult.transaction.status === 'completed') {
            markOrderProcessed(orderId, price);

            // Mark discount code claimed immediately
            if (currentState && currentState.appliedDiscount) {
                markCodeClaimed(from, currentState.appliedDiscount.code);
            }

            if (currentState.type === 'bug') {
                userStates.set(from, {
                    step: 'WAITING_DELIVERY_BUG',
                    bugType: currentState.bugType,
                    price,
                    orderId
                });
                const paymentSuccessMsg = `
  ◆ 𝐃𝐄𝐏𝐎𝐒𝐈𝐓 𝐒𝐔𝐊𝐒𝐄𝐒 ◆
────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(price)}
  Status   : *Completed*
────────────────────────

Terima kasih! Pembayaran Anda telah diterima. 

Silakan masukkan nomor WhatsApp target Anda sekarang untuk mengirimkan Bug:
*(Format lengkap dengan kode negara, contoh: 6285726013874)*
                `.trim();
                await sock.sendMessage(from, { text: paymentSuccessMsg });
            } else if (currentState.type === 'uncheck') {
                userStates.set(from, {
                    step: 'WAITING_DELIVERY_UNCHECK',
                    category: currentState.category,
                    amount: currentState.amount,
                    price,
                    orderId
                });
                const paymentSuccessMsg = `
  ◆ 𝐃𝐄𝐏𝐎𝐒𝐈𝐓 𝐒𝐔𝐊𝐒𝐄𝐒 ◆
────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(price)}
  Status   : *Completed*
────────────────────────

Terima kasih! Pembayaran Anda telah diterima. 

Silakan masukkan alamat Email Anda sekarang untuk mengirimkan akun Uncheck:
*(Contoh: pembeli@gmail.com)*
                `.trim();
                await sock.sendMessage(from, { text: paymentSuccessMsg });
            } else {
                deleteOrderState(from, orderId);
                if (currentState.type === 'file') {
                    await executeFileDelivery(from, currentState.productName, price, orderId, m.key);
                } else if (currentState.type === 'panel') {
                    await executePanelDelivery(from, currentState.email, price, orderId, currentState.planName, currentState.limits, m.key);
                }
            }
        } else {
            await sock.sendMessage(from, { text: 'Pembayaran belum terdeteksi. Silakan bayar terlebih dahulu atau tunggu beberapa saat lalu coba lagi.' });
        }
        return;
    }
};
