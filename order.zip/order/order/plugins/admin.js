const fs = require('fs');
const path = require('path');
const { getSettings, saveSettings } = require('../lib/settings');
const { updateBotModeSheet } = require('../lib/gsheets');

module.exports = {
    name: 'admin',
    match: (body) => {
        const lowerBody = body.toLowerCase();
        return [
            '.admin', '.dashboard', 'menu_admin', 'admin_menu_features', 'admin_close', 'admin_restart'
        ].includes(lowerBody) || lowerBody.startsWith('admin_toggle:') || lowerBody.startsWith('.bc ') || lowerBody.startsWith('.broadcast ');
    },
    execute: async (sock, m, context) => {
        const { from, sender, body, lowerBody, formatRupiah, sendButtons } = context;

        // VERIFIKASI HANYA NOMOR OWNER YANG BISA MENGAKSES
        const senderNum = (sender || '').split('@')[0].split(':')[0];
        const isOwner = senderNum === '6285726013874';
        if (!isOwner) {
            await sock.sendMessage(from, { text: '⚠️ Akses ditolak! Menu ini khusus untuk Owner Bot.' });
            return;
        }

        // Ambil Pengaturan
        const settings = getSettings();

        // Hitung Statistik Penjualan
        const failedFile = path.join(__dirname, '../database/failed_deposits.json');

        let failed = {};
        if (fs.existsSync(failedFile)) {
            try { failed = JSON.parse(fs.readFileSync(failedFile, 'utf8') || '{}'); } catch (e) { }
        }

        let totalRevenue = 0;
        let totalSuccess = 0;

        // Integrasi Real-Time dengan Google Sheets (Membaca data dari sheet 'botorder')
        const { getDoc } = require('../lib/gsheets');
        try {
            const doc = await getDoc();
            const sheet = doc.sheetsByTitle['botorder'];
            if (sheet) {
                const rows = await sheet.getRows();
                totalSuccess = rows.length;
                rows.forEach(row => {
                    const priceVal = parseInt(row.get('Nominal') || '0');
                    if (!isNaN(priceVal)) {
                        totalRevenue += priceVal;
                    }
                });
            }
        } catch (err) {
            console.error('[Admin GSheets Stats Error]:', err.message);
            // Fallback ke file local jika GSheets gagal/offline
            const processedFile = path.join(__dirname, '../database/processed_deposits.json');
            let processed = {};
            if (fs.existsSync(processedFile)) {
                try { processed = JSON.parse(fs.readFileSync(processedFile, 'utf8') || '{}'); } catch (e) { }
            }
            totalSuccess = Object.keys(processed).length;
            for (const key in processed) {
                totalRevenue += processed[key].price || 5000;
            }
        }

        const totalFailed = Object.keys(failed).length;
        const totalTrx = totalSuccess + totalFailed;

        // 1. Tampilkan Main Admin Menu
        if (['.admin', '.dashboard', 'menu_admin'].includes(lowerBody)) {
            const caption = `
  ◆ 𝐍𝐀𝐊𝐔𝐍𝐁𝐎𝐓 𝐀𝐃𝐌𝐈𝐍 𝐃𝐀𝐒𝐇𝐁𝐎𝐀𝐑𝐃 ◆
────────────────────────
  Role : *Owner*
  Bot Mode : ${settings.maintenanceMode ? '🚨 *MAINTENANCE*' : '✅ *AKTIF (NORMAL)*'}
────────────────────────
  📊 *STATISTIK PENJUALAN:*
  ⟡ Total Transaksi : *${totalTrx}*
  ⟡ Transaksi Sukses : *${totalSuccess}*
  ⟡ Transaksi Gagal  : *${totalFailed}*
  ⟡ Total Pendapatan : *${formatRupiah(totalRevenue)}*
  
  ⚙️ *STATUS MAINTENANCE FITUR:*
  ⟡ Fitur Bug     : ${settings.features.bug ? '🚨 *Maintenance*' : '✅ *Aktif*'}
  ⟡ Fitur File    : ${settings.features.file ? '🚨 *Maintenance*' : '✅ *Aktif*'}
  ⟡ Fitur Uncheck : ${settings.features.uncheck ? '🚨 *Maintenance*' : '✅ *Aktif*'}
  ⟡ Fitur Panel   : ${settings.features.panel ? '🚨 *Maintenance*' : '✅ *Aktif*'}
────────────────────────
Silakan gunakan tombol di bawah untuk mengontrol sistem bot:
            `.trim();

            await sendButtons(from, "𝐀𝐃𝐌𝐈𝐍 𝐏𝐀𝐍𝐄𝐋", caption, 'Nakun Admin Center', [
                { displayText: settings.maintenanceMode ? 'Matikan MT Bot' : 'Aktifkan MT Bot', id: 'admin_toggle:bot' },
                { displayText: 'Set Fitur Maintenance', id: 'admin_menu_features' },
                { displayText: 'Restart Bot', id: 'admin_restart' },
                { displayText: 'Tutup Dashboard', id: 'admin_close' }
            ]);
            return;
        }

        // 2. Toggle Bot Maintenance Mode
        if (lowerBody === 'admin_toggle:bot') {
            settings.maintenanceMode = !settings.maintenanceMode;
            saveSettings(settings);

            // Sync status ke Google Sheets
            await updateBotModeSheet(settings.maintenanceMode).catch(e => console.error('[GSheets Mode Sync Error]:', e));

            await sock.sendMessage(from, { text: `✅ Mode maintenance bot berhasil diubah menjadi: *${settings.maintenanceMode ? 'AKTIF (Maintenance)' : 'NON-AKTIF (Normal)'}*` });

            // Redirect back to admin dashboard
            await sock.sendMessage(from, { text: 'Memuat ulang dashboard...' });
            const adminPlugin = module.exports;
            await adminPlugin.execute(sock, m, { ...context, body: 'menu_admin', lowerBody: 'menu_admin' });
            return;
        }

        // 3. Menu Kontrol Fitur Maintenance
        if (lowerBody === 'admin_menu_features') {
            const caption = `
  ◆ 𝐌𝐀𝐈𝐍𝐓𝐄𝐍𝐀𝐍𝐂𝐄 𝐅𝐈𝐓𝐔𝐑 ◆
────────────────────────
Silakan pilih fitur di bawah untuk mengubah status maintenance (Aktif / Non-aktif):

  ⟡ Fitur Bug     : ${settings.features.bug ? '🚨 *Maintenance*' : '✅ *Aktif*'}
  ⟡ Fitur File    : ${settings.features.file ? '🚨 *Maintenance*' : '✅ *Aktif*'}
  ⟡ Fitur Uncheck : ${settings.features.uncheck ? '🚨 *Maintenance*' : '✅ *Aktif*'}
  ⟡ Fitur Panel   : ${settings.features.panel ? '🚨 *Maintenance*' : '✅ *Aktif*'}
────────────────────────
            `.trim();

            await sendButtons(from, "𝐅𝐈𝐓𝐔𝐑 𝐌𝐀𝐈𝐍𝐓𝐄𝐍𝐀𝐍𝐂𝐄", caption, 'Nakun Feature Control', [
                { displayText: settings.features.bug ? 'Aktifkan Bug' : 'Matikan Bug', id: 'admin_toggle:feature:bug' },
                { displayText: settings.features.file ? 'Aktifkan File' : 'Matikan File', id: 'admin_toggle:feature:file' },
                { displayText: settings.features.uncheck ? 'Aktifkan Uncheck' : 'Matikan Uncheck', id: 'admin_toggle:feature:uncheck' },
                { displayText: settings.features.panel ? 'Aktifkan Panel' : 'Matikan Panel', id: 'admin_toggle:feature:panel' },
                { displayText: 'Kembali Ke Menu Admin', id: 'menu_admin' }
            ]);
            return;
        }

        // 4. Toggle Feature Maintenance Mode
        if (lowerBody.startsWith('admin_toggle:feature:')) {
            const featureName = body.split(':')[2];
            if (settings.features.hasOwnProperty(featureName)) {
                settings.features[featureName] = !settings.features[featureName];
                saveSettings(settings);

                // Sync status ke Google Sheets
                const { updateGSheetsSettings } = require('../lib/gsheets');
                await updateGSheetsSettings(settings).catch(e => console.error('[GSheets Feature Sync Error]:', e));

                await sock.sendMessage(from, { text: `✅ Status maintenance fitur *${featureName.toUpperCase()}* berhasil diubah menjadi: *${settings.features[featureName] ? 'MAINTENANCE' : 'AKTIF'}*` });
            }

            // Redirect back to features control menu
            const adminPlugin = module.exports;
            await adminPlugin.execute(sock, m, { ...context, body: 'admin_menu_features', lowerBody: 'admin_menu_features' });
            return;
        }

        // Broadcast Feature
        if (lowerBody.startsWith('.bc ') || lowerBody.startsWith('.broadcast ')) {
            const textToBroadcast = body.substring(body.indexOf(' ') + 1).trim();
            if (!textToBroadcast) {
                await sock.sendMessage(from, { text: '⚠️ Silakan masukkan teks broadcast!\n\nContoh: `.bc Halo semuanya!`' });
                return;
            }

            let users = [];

            // 1. Load database/users.json
            const usersFile = path.join(__dirname, '../database/users.json');
            if (fs.existsSync(usersFile)) {
                try {
                    const loaded = JSON.parse(fs.readFileSync(usersFile, 'utf8') || '[]');
                    if (Array.isArray(loaded)) {
                        users.push(...loaded);
                    }
                } catch (e) {
                    console.error('Failed to parse database/users.json:', e);
                }
            }

            // 2. Load database/created_panels.json
            const panelsFile = path.join(__dirname, '../database/created_panels.json');
            if (fs.existsSync(panelsFile)) {
                try {
                    const panels = JSON.parse(fs.readFileSync(panelsFile, 'utf8') || '[]');
                    if (Array.isArray(panels)) {
                        panels.forEach(p => {
                            if (p.buyer && typeof p.buyer === 'string' && p.buyer.endsWith('@s.whatsapp.net')) {
                                users.push(p.buyer);
                            }
                        });
                    }
                } catch (e) {
                    console.error('Failed to parse database/created_panels.json for broadcast:', e);
                }
            }

            // 3. Load database/processed_deposits.json (DEP-<timestamp>-<number> keys)
            const processedFile = path.join(__dirname, '../database/processed_deposits.json');
            if (fs.existsSync(processedFile)) {
                try {
                    const processed = JSON.parse(fs.readFileSync(processedFile, 'utf8') || '{}');
                    for (const key of Object.keys(processed)) {
                        const parts = key.split('-');
                        if (parts.length >= 3) {
                            const num = parts[2];
                            if (num && /^\d+$/.test(num)) {
                                users.push(`${num}@s.whatsapp.net`);
                            }
                        }
                    }
                } catch (e) {
                    console.error('Failed to parse database/processed_deposits.json for broadcast:', e);
                }
            }

            // Deduplicate and filter JIDs
            const uniqueUsers = Array.from(new Set(users)).filter(u => u && u.endsWith('@s.whatsapp.net'));

            if (uniqueUsers.length === 0) {
                await sock.sendMessage(from, { text: '❌ Tidak ada user terdaftar di database untuk menerima broadcast.' });
                return;
            }

            await sock.sendMessage(from, { text: `📢 *Memulai Broadcast ke ${uniqueUsers.length} user...*` });

            let successCount = 0;
            let failCount = 0;

            const broadcastMessage = `${textToBroadcast}\n\n-pengumuman`;

            for (const userJid of uniqueUsers) {
                try {
                    await sock.sendMessage(userJid, { text: broadcastMessage });
                    successCount++;
                    // Delay to avoid spam block (1.5 seconds)
                    await new Promise(resolve => setTimeout(resolve, 1500));
                } catch (err) {
                    console.error(`Failed to send broadcast to ${userJid}:`, err.message);
                    failCount++;
                }
            }

            await sock.sendMessage(from, { text: `✅ *Broadcast Selesai!*\n\n🚀 Berhasil dikirim: *${successCount}*\n❌ Gagal: *${failCount}*` });
            return;
        }

        // 5. Restart Bot
        if (lowerBody === 'admin_restart') {
            await sock.sendMessage(from, { text: '🔄 *Menghidupkan ulang (restarting) bot...* Silakan tunggu beberapa detik.' });
            setTimeout(() => {
                process.exit(0);
            }, 1000);
            return;
        }

        // 6. Close Dashboard
        if (lowerBody === 'admin_close') {
            await sock.sendMessage(from, { text: '🔒 *Admin Dashboard ditutup.*\n\nTerima kasih, Owner!' });
            return;
        }
    }
};
