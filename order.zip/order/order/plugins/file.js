module.exports = {
    name: 'file',
    match: (body, state) => {
        const lowerBody = body.toLowerCase();
        return lowerBody.startsWith('select_file:') || lowerBody.startsWith('start_file_order:');
    },
    execute: async (sock, m, context) => {
        const { from, body, lowerBody, userStates, sendButtons, formatRupiah, getProductDetails, createPakasirTransaction, buildQRImage, fetchPakasirStatus, isOrderProcessed, markOrderProcessed, markOrderFailed, executeFileDelivery, checkQrisRateLimit, markCodeClaimed } = context;

        // Step 1: select_file & start_file_order -> Instantly generate QRIS
        if (lowerBody.startsWith('select_file:') || lowerBody.startsWith('start_file_order:')) {
            const rateCheck = checkQrisRateLimit(from);
            if (!rateCheck.allowed) {
                await sock.sendMessage(from, { text: `⚠️ *BATAS GENERATE QRIS TERKABUL*\n\nAnda telah mencapai batas maksimal pembuatan QRIS (maksimal 3 kali dalam 30 menit).\n\nHarap tunggu *${rateCheck.remainingMinutes} menit* lagi sebelum memesan kembali.` });
                return;
            }

            const parts = body.split(':');
            const name = parts[1];

            const { name: displayName, price: originalPrice } = getProductDetails(name);
            let price = originalPrice;

            // Check for active discount coupon
            const session = userStates.get(from);
            let discountInfo = null;
            if (session && session.activeDiscount) {
                discountInfo = session.activeDiscount;
                price = Math.max(100, price - discountInfo.amount);
            }

            const orderId = 'TRX-' + Math.random().toString(36).substring(2, 7).toUpperCase();
            const slug = process.env.PAKASIR_SLUG || 'nakuntools';
            const apiKey = process.env.PAKASIR;
            const paymentUrl = `https://app.pakasir.com/pay/${slug}/${price}?order_id=${orderId}&qris_only=1`;

            if (!apiKey) {
                await sock.sendMessage(from, { text: 'Kesalahan Konfigurasi: API Key Pembayaran tidak ditemukan pada server.' });
                return;
            }

            const waitQR = await sock.sendMessage(from, { text: `Sedang memproses QRIS untuk pesanan File ${displayName} Anda...` });

            try {
                const result = await createPakasirTransaction(slug, price, orderId, apiKey);
                let qrBuffer = null;
                let qrString = '';

                if (result && result.payment && result.payment.payment_number) {
                    qrString = result.payment.payment_number;
                    if (qrString.includes('000201')) {
                        qrString = qrString.substring(qrString.indexOf('000201'));
                    }
                    qrBuffer = await buildQRImage(qrString);
                }

                const invoicePending = `
  ◆ 𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐆 𝐈𝐍𝐕𝐎𝐈𝐂𝐄 ◆
────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(price)} ${discountInfo ? `_(Diskon: -${formatRupiah(discountInfo.amount)})_` : ''}
  Status   : *Menunggu Pembayaran* (60 Menit)
────────────────────────
`.trim();

                await sock.sendMessage(from, { delete: waitQR.key }).catch(() => { });

                userStates.set(from, {
                    step: 'WAITING_PAYMENT',
                    type: 'file',
                    fileName: name,
                    price,
                    orderId,
                    appliedDiscount: discountInfo
                });

                const bodyText = `${invoicePending}\nScan QRIS di atas atau klik Link Pembayaran untuk membayar. Setelah pembayaran lunas, file premium Anda akan otomatis terkirim secara instan!`;

                await sendButtons(from, "𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐆", bodyText, 'Automatic Payment System', [
                    { displayText: 'Salin ID Transaksi', copyCode: orderId },
                    { displayText: 'Link Pembayaran', url: paymentUrl }
                ], qrBuffer || null);

                // Polling Loop
                const pollingInterval = setInterval(async () => {
                    if (isOrderProcessed(orderId)) {
                        clearInterval(pollingInterval);
                        return;
                    }

                    const checkResult = await fetchPakasirStatus(slug, price, orderId, apiKey);
                    if (checkResult && checkResult.transaction && checkResult.transaction.status === 'completed') {
                        clearInterval(pollingInterval);
                        markOrderProcessed(orderId, price);

                        // Mark discount code claimed
                        const curState = userStates.get(from);
                        if (curState && curState.appliedDiscount) {
                            markCodeClaimed(from, curState.appliedDiscount.code);
                        }

                        // Deliver file premium immediately
                        await executeFileDelivery(from, name, price, orderId, m.key);
                        userStates.delete(from);
                    }
                }, 7000);

                setTimeout(async () => {
                    clearInterval(pollingInterval);
                    if (isOrderProcessed(orderId)) return;
                    try {
                        if (userStates.get(from)?.orderId === orderId) {
                            userStates.delete(from);
                        }
                        markOrderFailed(orderId, price);
                        await sock.sendMessage(from, {
                            text: `❌ *INVOICE EXPIRED*\n\nOrder ID: ${orderId}\nNominal: ${formatRupiah(price)}\n\nInvoice pembayaran Anda telah kadaluwarsa.`
                        });
                    } catch (e) { }
                }, 60 * 60 * 1000);

            } catch (err) {
                console.error(err);
                await sock.sendMessage(from, { text: 'Terjadi kesalahan saat membuat QRIS.' });
                userStates.delete(from);
            }
            return;
        }
    }
};
