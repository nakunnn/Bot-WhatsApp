module.exports = {
    name: 'bug',
    match: (body, state) => {
        const lowerBody = body.toLowerCase();
        if (lowerBody.startsWith('select_bug:') || lowerBody.startsWith('start_order:')) return true;
        if (state && state.step === 'WAITING_DELIVERY_BUG') return true;
        return false;
    },
    execute: async (sock, m, context) => {
        const { from, body, lowerBody, state, userStates, sendButtons, formatRupiah, createPakasirTransaction, buildQRImage, fetchPakasirStatus, isOrderProcessed, markOrderProcessed, markOrderFailed, checkNumber, executeBugDelivery, checkQrisRateLimit, markCodeClaimed } = context;

        // Step 1: select_bug & start_order -> Instantly generate QRIS
        if (lowerBody.startsWith('select_bug:') || lowerBody.startsWith('start_order:')) {
            const rateCheck = checkQrisRateLimit(from);
            if (!rateCheck.allowed) {
                await sock.sendMessage(from, { text: `⚠️ *BATAS GENERATE QRIS TERKABUL*\n\nAnda telah mencapai batas maksimal pembuatan QRIS (maksimal 3 kali dalam 30 menit).\n\nHarap tunggu *${rateCheck.remainingMinutes} menit* lagi sebelum memesan kembali.` });
                return;
            }

            const parts = body.split(':');
            const bugType = parts[1];
            let price = parseInt(parts[2]);

            // Check for active discount coupon
            const session = userStates.get(from);
            let discountInfo = null;
            if (session && session.activeDiscount) {
                discountInfo = session.activeDiscount;
                price = Math.max(100, price - discountInfo.amount);
            }

            // Create Pakasir invoice for bug order
            const orderId = 'TRX-' + Math.random().toString(36).substring(2, 7).toUpperCase();
            const slug = process.env.PAKASIR_SLUG || 'nakuntools';
            const apiKey = process.env.PAKASIR;
            const paymentUrl = `https://app.pakasir.com/pay/${slug}/${price}?order_id=${orderId}&qris_only=1`;

            if (!apiKey) {
                await sock.sendMessage(from, { text: 'Kesalahan Konfigurasi: API Key Pembayaran tidak ditemukan pada server.' });
                return;
            }

            const waitQR = await sock.sendMessage(from, { text: 'Sedang memproses QRIS untuk pesanan Bug Anda...' });

            try {
                const result = await createPakasirTransaction(slug, price, orderId, apiKey);
                let qrBuffer = null;
                let qrString = '';

                if (result && result.payment && result.payment.payment_number) {
                    qrString = result.payment.payment_number;
                    if (qrString.includes('000201')) {
                        qrString = qrString.substring(qrString.indexOf('000201'));
                    }
                    qrBuffer = await buildQRImage(qrString);
                }

                const invoicePending = `
  ◆ 𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐆 𝐈𝐍𝐕𝐎𝐈𝐂𝐄 ◆
────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(price)} ${discountInfo ? `_(Diskon: -${formatRupiah(discountInfo.amount)})_` : ''}
  Status   : *Menunggu Pembayaran* (60 Menit)
────────────────────────
`.trim();

                await sock.sendMessage(from, { delete: waitQR.key }).catch(() => { });

                userStates.set(from, {
                    step: 'WAITING_PAYMENT',
                    type: 'bug',
                    bugType,
                    price,
                    orderId,
                    appliedDiscount: discountInfo
                });

                const bodyText = `${invoicePending}\nScan QRIS di atas atau klik Link Pembayaran untuk membayar. Setelah pembayaran lunas, Anda akan diminta memasukkan nomor WhatsApp target.`;

                await sendButtons(from, "𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐆", bodyText, 'Automatic Payment System', [
                    { displayText: 'Salin ID Transaksi', copyCode: orderId },
                    { displayText: 'Link Pembayaran', url: paymentUrl }
                ], qrBuffer || null);

                // Polling Loop
                const pollingInterval = setInterval(async () => {
                    if (isOrderProcessed(orderId)) {
                        clearInterval(pollingInterval);
                        return;
                    }

                    const checkResult = await fetchPakasirStatus(slug, price, orderId, apiKey);
                    if (checkResult && checkResult.transaction && checkResult.transaction.status === 'completed') {
                        clearInterval(pollingInterval);
                        markOrderProcessed(orderId, price);
                        
                        // Mark discount code claimed
                        const curState = userStates.get(from);
                        if (curState && curState.appliedDiscount) {
                            markCodeClaimed(from, curState.appliedDiscount.code);
                        }

                        // Transition to WAITING_DELIVERY_BUG
                        userStates.set(from, {
                            step: 'WAITING_DELIVERY_BUG',
                            bugType,
                            price,
                            orderId
                        });

                        const paymentSuccessMsg = `
  ◆ 𝐃𝐄𝐏𝐎𝐒𝐈𝐓 𝐒𝐔𝐊𝐒𝐄𝐒 ◆
────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(price)}
  Status   : *Completed*
────────────────────────

Terima kasih! Pembayaran Anda telah diterima. 

Silakan masukkan nomor WhatsApp target Anda sekarang untuk mengirimkan Bug:
*(Format lengkap dengan kode negara, contoh: 6285726013874)*
                        `.trim();

                        await sock.sendMessage(from, { text: paymentSuccessMsg });
                    }
                }, 7000);

                setTimeout(async () => {
                    clearInterval(pollingInterval);
                    if (isOrderProcessed(orderId)) return;
                    try {
                        if (userStates.get(from)?.orderId === orderId) {
                            userStates.delete(from);
                        }
                        markOrderFailed(orderId, price);
                        await sock.sendMessage(from, {
                            text: `❌ *INVOICE EXPIRED*\n\nOrder ID: ${orderId}\nNominal: ${formatRupiah(price)}\n\nInvoice pembayaran Anda telah kadaluwarsa.`
                        });
                    } catch (e) { }
                }, 60 * 60 * 1000);

            } catch (err) {
                console.error(err);
                await sock.sendMessage(from, { text: 'Terjadi kesalahan saat membuat QRIS.' });
                userStates.delete(from);
            }
            return;
        }

        // Step 2: WAITING_DELIVERY_BUG state input
        if (state && state.step === 'WAITING_DELIVERY_BUG') {
            const cleanInput = body.trim().toLowerCase();
            if (['batal', 'cancel', 'menu'].includes(cleanInput)) {
                userStates.delete(from);
                const menu = require('./menu');
                context.lowerBody = 'menu';
                context.body = 'menu';
                await menu.execute(sock, m, context);
                return;
            }

            const waNumber = body.replace(/[^0-9]/g, '');
            if (!waNumber || waNumber.length < 5) {
                await sock.sendMessage(from, { text: 'Format Salah! Harap masukkan nomor target yang valid (lengkap dengan kode negara).\n\nContoh: 6285123456789\nSilakan masukkan ulang nomor target:' });
                return;
            }

            const { bugType, price, orderId } = state;

            // Verify Target Number
            const waitVerif = await sock.sendMessage(from, { text: 'Sedang memverify nomor di server WhatsApp target...' });
            const verif = await checkNumber(waNumber);

            if (!verif.exists) {
                await sock.sendMessage(from, { delete: waitVerif.key }).catch(() => { });
                await sock.sendMessage(from, { text: `Verifikasi Gagal!\n\nNomor ${waNumber} tidak terdaftar di WhatsApp.\n\nSilakan masukkan kembali nomor target yang valid:` });
                return;
            }

            await sock.sendMessage(from, { delete: waitVerif.key }).catch(() => { });

            // Clear state and perform delivery
            userStates.delete(from);
            await executeBugDelivery(from, bugType, waNumber, price, orderId, m.key);
            return;
        }
    }
};
