module.exports = {
    name: 'panel',
    match: (body) => {
        const lowerBody = body.toLowerCase();
        return lowerBody.startsWith('select_panel:') || lowerBody.startsWith('start_panel_order:');
    },
    execute: async (sock, m, context) => {
        const { from, body, lowerBody, state, userStates, saveOrderState, deleteOrderState, sendButtons, formatRupiah, createPakasirTransaction, buildQRImage, fetchPakasirStatus, isOrderProcessed, markOrderProcessed, markOrderFailed, executePanelDelivery, checkQrisRateLimit, markCodeClaimed } = context;

        // Step 1: select_panel & start_panel_order -> Instantly generate QRIS
        if (lowerBody.startsWith('select_panel:') || lowerBody.startsWith('start_panel_order:')) {
            const rateCheck = checkQrisRateLimit(from);
            if (!rateCheck.allowed) {
                await sock.sendMessage(from, { text: `⚠️ *BATAS GENERATE QRIS TERKABUL*\n\nAnda telah mencapai batas maksimal pembuatan QRIS (maksimal 3 kali dalam 30 menit).\n\nHarap tunggu *${rateCheck.remainingMinutes} menit* lagi sebelum memesan kembali.` });
                return;
            }

            const parts = body.split(':');
            const planName = parts[1];
            let price = parseInt(parts[2]);
            
            const displayName = planName === 'unlimited' ? 'Panel Unlimited' : `Panel ${planName.toUpperCase()} RAM`;
            const waNumber = from.split('@')[0];
            const email = `${waNumber}@renmods.com`; // Auto-generate dummy email to bypass email inputs and disable system mailings

            // Limits configuration based on selected Pterodactyl plan
            let limits = { memory: 1024, cpu: 100, disk: 5120 };
            if (planName === 'unlimited') {
                limits = { memory: 32768, cpu: 1000, disk: 102400 };
            } else {
                const ramGB = parseInt(planName.replace('gb', ''));
                if (!isNaN(ramGB)) {
                    limits.memory = ramGB * 1024;
                    limits.cpu = 100 + (ramGB - 1) * 30;
                    limits.disk = (5 + (ramGB - 1) * 3) * 1024;
                }
            }

            // Check for active discount coupon
            const session = userStates.get(from);
            let discountInfo = null;
            if (session && session.activeDiscount) {
                discountInfo = session.activeDiscount;
                price = Math.max(100, price - discountInfo.amount);
            }

            // Create Pakasir invoice for panel order
            const orderId = 'TRX-' + Math.random().toString(36).substring(2, 7).toUpperCase();
            const slug = process.env.PAKASIR_SLUG || 'nakuntools';
            const apiKey = process.env.PAKASIR;
            const paymentUrl = `https://app.pakasir.com/pay/${slug}/${price}?order_id=${orderId}&qris_only=1`;

            if (!apiKey) {
                await sock.sendMessage(from, { text: 'Kesalahan Konfigurasi: API Key Pembayaran tidak ditemukan pada server.' });
                return;
            }

            const waitQR = await sock.sendMessage(from, { text: `Sedang memproses QRIS untuk pesanan ${displayName} Anda...` });

            try {
                const result = await createPakasirTransaction(slug, price, orderId, apiKey);
                let qrBuffer = null;
                let qrString = '';

                if (result && result.payment && result.payment.payment_number) {
                    qrString = result.payment.payment_number;
                    if (qrString.includes('000201')) {
                        qrString = qrString.substring(qrString.indexOf('000201'));
                    }
                    qrBuffer = await buildQRImage(qrString);
                }

                const invoicePending = `
  ◆ 𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐆 𝐈𝐍𝐕𝐎𝐈𝐂𝐄 ◆
────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(price)} ${discountInfo ? `_(Diskon: -${formatRupiah(discountInfo.amount)})_` : ''}
  Status   : *Menunggu Pembayaran* (60 Menit)
────────────────────────
`.trim();

                await sock.sendMessage(from, { delete: waitQR.key }).catch(() => { });

                saveOrderState(from, {
                    step: 'WAITING_PAYMENT',
                    type: 'panel',
                    planName,
                    price,
                    orderId,
                    email,
                    displayName,
                    limits,
                    appliedDiscount: discountInfo
                });

                const bodyText = `${invoicePending}\nScan QRIS di atas atau klik Link Pembayaran untuk membayar. Setelah pembayaran lunas, panel Pterodactyl Anda akan otomatis dibuat secara instan!`;

                await sendButtons(from, "𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐆", bodyText, 'Automatic Payment System', [
                    { displayText: 'Salin ID Transaksi', copyCode: orderId },
                    { displayText: 'Link Pembayaran', url: paymentUrl }
                ], qrBuffer || null);

                // Polling Loop
                const pollingInterval = setInterval(async () => {
                    if (isOrderProcessed(orderId)) {
                        clearInterval(pollingInterval);
                        return;
                    }

                    const checkResult = await fetchPakasirStatus(slug, price, orderId, apiKey);
                    if (checkResult && checkResult.transaction && checkResult.transaction.status === 'completed') {
                        clearInterval(pollingInterval);
                        markOrderProcessed(orderId, price);

                        // Mark discount code claimed
                        const curState = getOrderState(from, orderId);
                        if (curState && curState.appliedDiscount) {
                            markCodeClaimed(from, curState.appliedDiscount.code);
                        }

                        // Provision Pterodactyl Panel immediately
                        await executePanelDelivery(from, email, price, orderId, displayName, limits, m.key);
                        deleteOrderState(from, orderId);
                    }
                }, 7000);

                setTimeout(async () => {
                    clearInterval(pollingInterval);
                    if (isOrderProcessed(orderId)) return;
                    try {
                        const curState = getOrderState(from, orderId);
                        if (curState) {
                            deleteOrderState(from, orderId);
                        }
                        markOrderFailed(orderId, price);
                        await sock.sendMessage(from, {
                            text: `❌ *INVOICE EXPIRED*\n\nOrder ID: ${orderId}\nNominal: ${formatRupiah(price)}\n\nInvoice pembayaran Anda telah kadaluwarsa.`
                        });
                    } catch (e) { }
                }, 60 * 60 * 1000);

            } catch (err) {
                console.error(err);
                await sock.sendMessage(from, { text: 'Terjadi kesalahan saat membuat QRIS.' });
                deleteOrderState(from, orderId);
            }
            return;
        }
    }
};
