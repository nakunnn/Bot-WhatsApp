module.exports = {
    name: 'uncheck',
    match: (body, state) => {
        const lowerBody = body.toLowerCase();
        if (lowerBody.startsWith('select_uncheck:') || lowerBody.startsWith('start_uncheck_order:')) return true;
        if (state && state.step === 'WAITING_DELIVERY_UNCHECK') return true;
        return false;
    },
    execute: async (sock, m, context) => {
        const { from, body, lowerBody, state, userStates, sendButtons, formatRupiah, createPakasirTransaction, buildQRImage, fetchPakasirStatus, isOrderProcessed, markOrderProcessed, markOrderFailed, executeUncheckDelivery, checkQrisRateLimit, markCodeClaimed } = context;

        // Step 1: select_uncheck & start_uncheck_order -> Instantly generate QRIS
        if (lowerBody.startsWith('select_uncheck:') || lowerBody.startsWith('start_uncheck_order:')) {
            const rateCheck = checkQrisRateLimit(from);
            if (!rateCheck.allowed) {
                await sock.sendMessage(from, { text: `⚠️ *BATAS GENERATE QRIS TERKABUL*\n\nAnda telah mencapai batas maksimal pembuatan QRIS (maksimal 3 kali dalam 30 menit).\n\nHarap tunggu *${rateCheck.remainingMinutes} menit* lagi sebelum memesan kembali.` });
                return;
            }

            const parts = body.split(':');
            const category = parts[1];
            const amount = parseInt(parts[2]);
            let price = parseInt(parts[3]);

            // Check for active discount coupon
            const session = userStates.get(from);
            let discountInfo = null;
            if (session && session.activeDiscount) {
                discountInfo = session.activeDiscount;
                price = Math.max(100, price - discountInfo.amount);
            }

            // Create Pakasir invoice for uncheck order
            const orderId = 'TRX-' + Math.random().toString(36).substring(2, 7).toUpperCase();
            const slug = process.env.PAKASIR_SLUG || 'nakuntools';
            const apiKey = process.env.PAKASIR;
            const paymentUrl = `https://app.pakasir.com/pay/${slug}/${price}?order_id=${orderId}&qris_only=1`;

            if (!apiKey) {
                await sock.sendMessage(from, { text: 'Kesalahan Konfigurasi: API Key Pembayaran tidak ditemukan pada server.' });
                return;
            }

            const waitQR = await sock.sendMessage(from, { text: 'Sedang memproses QRIS untuk pesanan Uncheck Anda...' });

            try {
                const result = await createPakasirTransaction(slug, price, orderId, apiKey);
                let qrBuffer = null;
                let qrString = '';

                if (result && result.payment && result.payment.payment_number) {
                    qrString = result.payment.payment_number;
                    if (qrString.includes('000201')) {
                        qrString = qrString.substring(qrString.indexOf('000201'));
                    }
                    qrBuffer = await buildQRImage(qrString);
                }

                const invoicePending = `
  ◆ 𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐆 𝐈𝐍𝐕𝐎𝐈𝐂𝐄 ◆
────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(price)} ${discountInfo ? `_(Diskon: -${formatRupiah(discountInfo.amount)})_` : ''}
  Status   : *Menunggu Pembayaran* (60 Menit)
────────────────────────
`.trim();

                await sock.sendMessage(from, { delete: waitQR.key }).catch(() => { });

                userStates.set(from, {
                    step: 'WAITING_PAYMENT',
                    type: 'uncheck',
                    category,
                    amount,
                    price,
                    orderId,
                    appliedDiscount: discountInfo
                });

                const bodyText = `${invoicePending}\nScan QRIS di atas atau klik Link Pembayaran untuk membayar. Setelah pembayaran lunas, Anda akan diminta memasukkan email target.`;

                await sendButtons(from, "𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐆", bodyText, 'Automatic Payment System', [
                    { displayText: 'Salin ID Transaksi', copyCode: orderId },
                    { displayText: 'Link Pembayaran', url: paymentUrl }
                ], qrBuffer || null);

                // Polling Loop
                const pollingInterval = setInterval(async () => {
                    if (isOrderProcessed(orderId)) {
                        clearInterval(pollingInterval);
                        return;
                    }

                    const checkResult = await fetchPakasirStatus(slug, price, orderId, apiKey);
                    if (checkResult && checkResult.transaction && checkResult.transaction.status === 'completed') {
                        clearInterval(pollingInterval);
                        markOrderProcessed(orderId, price);
                        
                        // Mark discount code claimed
                        const curState = userStates.get(from);
                        if (curState && curState.appliedDiscount) {
                            markCodeClaimed(from, curState.appliedDiscount.code);
                        }

                        // Transition to WAITING_DELIVERY_UNCHECK
                        userStates.set(from, {
                            step: 'WAITING_DELIVERY_UNCHECK',
                            category,
                            amount,
                            price,
                            orderId
                        });

                        const paymentSuccessMsg = `
  ◆ 𝐃𝐄𝐏𝐎𝐒𝐈𝐓 𝐒𝐔𝐊𝐒𝐄𝐒 ◆
────────────────────────
  Order ID : ${orderId}
  Nominal  : ${formatRupiah(price)}
  Status   : *Completed*
────────────────────────

Terima kasih! Pembayaran Anda telah diterima.

Silakan masukkan alamat Email Anda untuk pengiriman Uncheck:
*(Contoh: emailkamu@gmail.com)*
                        `.trim();

                        await sock.sendMessage(from, { text: paymentSuccessMsg });
                    }
                }, 7000);

                setTimeout(async () => {
                    clearInterval(pollingInterval);
                    if (isOrderProcessed(orderId)) return;
                    try {
                        if (userStates.get(from)?.orderId === orderId) {
                            userStates.delete(from);
                        }
                        markOrderFailed(orderId, price);
                        await sock.sendMessage(from, {
                            text: `❌ *INVOICE EXPIRED*\n\nOrder ID: ${orderId}\nNominal: ${formatRupiah(price)}\n\nInvoice pembayaran Anda telah kadaluwarsa.`
                        });
                    } catch (e) { }
                }, 60 * 60 * 1000);

            } catch (err) {
                console.error(err);
                await sock.sendMessage(from, { text: 'Terjadi kesalahan saat membuat QRIS.' });
                userStates.delete(from);
            }
            return;
        }

        // Step 2: WAITING_DELIVERY_UNCHECK state input
        if (state && state.step === 'WAITING_DELIVERY_UNCHECK') {
            const cleanInput = body.trim().toLowerCase();
            if (['batal', 'cancel', 'menu'].includes(cleanInput)) {
                userStates.delete(from);
                const menu = require('./menu');
                context.lowerBody = 'menu';
                context.body = 'menu';
                await menu.execute(sock, m, context);
                return;
            }

            const email = body.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                await sock.sendMessage(from, { text: 'Format Email Salah! Silakan masukkan alamat email yang valid:\n*(Contoh: nama@gmail.com)*' });
                return;
            }

            const { category, amount, price, orderId } = state;

            // Clear state and perform delivery
            userStates.delete(from);
            await executeUncheckDelivery(from, category, amount, email, price, orderId, m.key);
            return;
        }
    }
};
