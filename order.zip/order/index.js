require('dotenv').config();
const https = require('https');

// Force all HTTPS requests globally to use IPv4 & keepAlive to prevent slow connection / ETIMEDOUT (IPv6 issues)
https.globalAgent = new https.Agent({
    family: 4,
    keepAlive: true
});

// Optimize DNS resolution to prefer IPv4
const dns = require('dns');
if (typeof dns.setDefaultResultOrder === 'function') {
    dns.setDefaultResultOrder('ipv4first');
}

const { connectToWhatsApp } = require('./lib/wa');

console.log('🚀 Starting NakunTools WhatsApp Bot...');
connectToWhatsApp();
