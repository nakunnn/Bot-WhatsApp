const fs = require('fs');
const path = require('path');

const otpRateLimits = new Map();

// Helper: Rate limiting check
function checkOtpRateLimit(from) {
    const now = Date.now();
    const windowMs = 60 * 1000; // 1 minute
    let timestamps = otpRateLimits.get(from) || [];
    
    // Filter timestamps to only keep those within last 1 minute
    timestamps = timestamps.filter(ts => (now - ts) < windowMs);
    
    if (timestamps.length >= 2) {
        const oldestTimestamp = timestamps[0];
        const waitMs = windowMs - (now - oldestTimestamp);
        const waitSeconds = Math.ceil(waitMs / 1000);
        const minutes = Math.floor(waitSeconds / 60);
        const seconds = waitSeconds % 60;
        
        let waitText = '';
        if (minutes > 0) {
            waitText += `${minutes} menit `;
        }
        waitText += `${seconds} detik`;
        
        return { allowed: false, waitText };
    }
    
    timestamps.push(now);
    otpRateLimits.set(from, timestamps);
    return { allowed: true };
}

// File paths for local OTP databases
const nomorPath = path.join(__dirname, '../otp order/nomor.txt');
const codePath = path.join(__dirname, '../otp order/code.txt');
const localOtpDbPath = path.join(__dirname, '../database/local_otp_orders.json');

// Helper: Safely count lines in a text stock file
function getStockCount(filePath) {
    if (!fs.existsSync(filePath)) return 0;
    try {
        const content = fs.readFileSync(filePath, 'utf8');
        return content.split('\n').map(l => l.trim()).filter(l => l.length > 0).length;
    } catch (e) {
        console.error(`Error counting stock for ${filePath}:`, e);
        return 0;
    }
}

// Helper: Retrieve a random pair of phone number and code from local files (without deleting)
function getRandomOtpPair() {
    if (!fs.existsSync(nomorPath) || !fs.existsSync(codePath)) return null;
    try {
        const nomorContent = fs.readFileSync(nomorPath, 'utf8');
        const codeContent = fs.readFileSync(codePath, 'utf8');
        
        const nomorLines = nomorContent.split('\n').map(l => l.trim()).filter(l => l.length > 0);
        const codeLines = codeContent.split('\n').map(l => l.trim()).filter(l => l.length > 0);
        
        if (nomorLines.length === 0 || codeLines.length === 0) return null;
        
        // Pick a random index based on the smaller list to avoid out-of-bounds
        const maxIndex = Math.min(nomorLines.length, codeLines.length);
        const randomIndex = Math.floor(Math.random() * maxIndex);
        
        return {
            phone: nomorLines[randomIndex],
            code: codeLines[randomIndex]
        };
    } catch (e) {
        console.error('Error getting random OTP pair:', e);
        return null;
    }
}

// Helper: Save local active OTP transaction
function saveLocalOtpOrder(orderId, data) {
    let orders = {};
    const dir = path.dirname(localOtpDbPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (fs.existsSync(localOtpDbPath)) {
        try {
            orders = JSON.parse(fs.readFileSync(localOtpDbPath, 'utf8') || '{}');
        } catch (e) {
            orders = {};
        }
    }
    orders[orderId] = {
        ...data,
        createdAt: new Date().toISOString()
    };
    fs.writeFileSync(localOtpDbPath, JSON.stringify(orders, null, 2), 'utf8');
}

// Helper: Retrieve local active OTP transaction
function getLocalOtpOrder(orderId) {
    if (!fs.existsSync(localOtpDbPath)) return null;
    try {
        const orders = JSON.parse(fs.readFileSync(localOtpDbPath, 'utf8') || '{}');
        return orders[orderId] || null;
    } catch (e) {
        console.error('Error reading local OTP database:', e);
        return null;
    }
}

module.exports = {
    name: 'otp',
    match: (body) => {
        const lowerBody = body.toLowerCase();
        return lowerBody === 'menu_otp' || 
               lowerBody.startsWith('select_otp:') || 
               lowerBody.startsWith('otp_status:');
    },
    execute: async (sock, m, context) => {
        const { 
            from, body, lowerBody, userStates, 
            saveOrderState, deleteOrderState, sendButtons, 
            formatRupiah, createPakasirTransaction, buildQRImage, 
            fetchPakasirStatus, isOrderProcessed, markOrderProcessed, 
            markOrderFailed, checkQrisRateLimit, getOrderState 
        } = context;

        // Rate limiting check
        const rateLimit = checkOtpRateLimit(from);
        if (!rateLimit.allowed) {
            await sock.sendMessage(from, { 
                text: `*BATAS LIMIT PERMINTAAN*\n\nAnda telah mencapai batas maksimal permintaan OTP (maksimal 2 kali dalam 1 menit).\n\nHarap tunggu *${rateLimit.waitText}* lagi sebelum mencoba kembali.` 
            });
            return;
        }

        // ==========================================
        // 1. MENU OTP (Direct Local Indonesia OTP Pricelist)
        // ==========================================
        if (lowerBody === 'menu_otp') {
            const stock = getStockCount(nomorPath);

            const buttons = [
                { displayText: `Server 1 (Reguler) - Rp2.000`, id: `select_otp:Indonesia:local_1:local_provider:2000` },
                { displayText: `Server 2 (Standard) - Rp5.000`, id: `select_otp:Indonesia:local_2:local_provider:5000` },
                { displayText: `Server 3 (Premium) - Rp10.000`, id: `select_otp:Indonesia:local_3:local_provider:10000` },
                { displayText: `Server 4 (VVIP) - Rp15.000`, id: `select_otp:Indonesia:local_4:local_provider:15000` },
                { displayText: 'Kembali Ke Menu Utama', id: 'menu' }
            ];

            const caption = `
◆ 𝐌𝐄𝐍𝐔 𝐍𝐎𝐌𝐎𝐑 𝐕𝐈𝐑𝐓𝐔𝐀𝐋 𝐎𝐓𝐏 ◆
────────────────────────
Layanan nomor virtual WhatsApp Indonesia menggunakan stok lokal mandiri dengan berbagai pilihan server:

  *Negara* : Indonesia 🇮🇩
  *Stok*   : ${stock} Nomor Tersedia

Silakan pilih opsi server di bawah ini:
────────────────────────
            `.trim();

            await sendButtons(from, "𝐎𝐓𝐏 𝐒𝐄𝐑𝐕𝐈𝐂𝐄", caption, 'NakunBOT OTP System', buttons);
            return;
        }

        // ==========================================
        // 2. SELECT OTP / PLACE QRIS ORDER
        // ==========================================
        if (lowerBody.startsWith('select_otp:')) {
            const rateCheck = checkQrisRateLimit(from);
            if (!rateCheck.allowed) {
                await sock.sendMessage(from, { text: `*BATAS GENERATE QRIS TERKABUL*\n\nAnda telah mencapai batas maksimal pembuatan QRIS (maksimal 3 kali dalam 30 menit).\n\nHarap tunggu *${rateCheck.remainingMinutes} menit* lagi sebelum memesan kembali.` });
                return;
            }

            const parts = body.split(':');
            const countryName = parts[1];
            if (!countryName || countryName.toLowerCase() !== 'indonesia') {
                await sock.sendMessage(from, { text: 'Maaf, pemesanan nomor OTP saat ini hanya didukung untuk negara Indonesia.' });
                return;
            }
            const price = parseInt(parts[4]);

            const orderId = 'TRX-' + Math.random().toString(36).substring(2, 7).toUpperCase();
            const slug = process.env.PAKASIR_SLUG || 'nakuntools';
            const apiKey = process.env.PAKASIR;
            const paymentUrl = `https://app.pakasir.com/pay/${slug}/${price}?order_id=${orderId}&qris_only=1`;

            if (!apiKey) {
                await sock.sendMessage(from, { text: 'Kesalahan Konfigurasi: API Key Pembayaran tidak ditemukan pada server.' });
                return;
            }

            // Check if stock is available before generating QRIS to save payment headache
            const currentStock = getStockCount(nomorPath);
            if (currentStock === 0) {
                await sock.sendMessage(from, { text: '⚠️ *STOK KOSONG*\n\nMaaf, stok nomor virtual Indonesia saat ini sedang kosong. Silakan hubungi Owner untuk restok.' });
                return;
            }

            const waitQR = await sock.sendMessage(from, { text: `Sedang memproses QRIS untuk pesanan OTP WhatsApp ${countryName} Anda...` });

            try {
                const result = await createPakasirTransaction(slug, price, orderId, apiKey);
                let qrBuffer = null;
                let qrString = '';

                if (result && result.payment && result.payment.payment_number) {
                    qrString = result.payment.payment_number;
                    if (qrString.includes('000201')) {
                        qrString = qrString.substring(qrString.indexOf('000201'));
                    }
                    qrBuffer = await buildQRImage(qrString);
                }

                const invoicePending = `
◆ 𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐍𝐆 𝐈𝐍𝐕𝐎𝐈𝐂𝐄 ◆
────────────────────────
  Order ID : ${orderId}
  Produk   : OTP WhatsApp ${countryName}
  Nominal  : ${formatRupiah(price)}
  Status   : *Menunggu Pembayaran* (60 Menit)
────────────────────────
`.trim();

                await sock.sendMessage(from, { delete: waitQR.key }).catch(() => {});

                saveOrderState(from, {
                    step: 'WAITING_PAYMENT',
                    type: 'otp',
                    country: countryName,
                    price,
                    orderId,
                    displayName: `OTP WhatsApp ${countryName}`
                });

                const bodyText = `${invoicePending}\nScan QRIS di atas atau klik Link Pembayaran untuk membayar. Setelah lunas, nomor virtual Anda akan otomatis ditampilkan!`;

                await sendButtons(from, "𝐐𝐑𝐈𝐒 𝐁𝐈𝐋𝐋𝐈𝐍𝐆", bodyText, 'Automatic Payment System', [
                    { displayText: 'Salin ID Transaksi', copyCode: orderId },
                    { displayText: 'Link Pembayaran', url: paymentUrl }
                ], qrBuffer || null);

                // Polling Loop for QRIS
                const pollingInterval = setInterval(async () => {
                    if (isOrderProcessed(orderId)) {
                        clearInterval(pollingInterval);
                        return;
                    }

                    const checkResult = await fetchPakasirStatus(slug, price, orderId, apiKey);
                    if (checkResult && checkResult.transaction && checkResult.transaction.status === 'completed') {
                        clearInterval(pollingInterval);
                        markOrderProcessed(orderId, price);

                        // Complete purchase dynamically using local text databases
                        const provState = getOrderState(from, orderId);
                        if (provState) {
                            await executeOtpDelivery(sock, from, provState, m.key, sendButtons);
                            deleteOrderState(from, orderId);
                        }
                    }
                }, 7000);

                setTimeout(async () => {
                    clearInterval(pollingInterval);
                    if (isOrderProcessed(orderId)) return;
                    try {
                        const curState = getOrderState(from, orderId);
                        if (curState) {
                            deleteOrderState(from, orderId);
                        }
                        markOrderFailed(orderId, price);
                        await sock.sendMessage(from, {
                            text: `*INVOICE EXPIRED*\n\nOrder ID: ${orderId}\nNominal: ${formatRupiah(price)}\n\nInvoice pembayaran Anda telah kadaluwarsa.`
                        });
                    } catch (e) {}
                }, 60 * 60 * 1000);

            } catch (err) {
                console.error(err);
                await sock.sendMessage(from, { text: 'Terjadi kesalahan saat membuat QRIS.' });
                deleteOrderState(from, orderId);
            }
            return;
        }

        // ==========================================
        // 3. CHECK OTP STATUS (Local File Checker)
        // ==========================================
        if (lowerBody.startsWith('otp_status:')) {
            const orderId = body.split(':')[1];
            if (!orderId) return;

            try {
                const localOrder = getLocalOtpOrder(orderId);

                if (localOrder) {
                    const phone = localOrder.phone;
                    const otpCode = localOrder.code;
                    const createdAt = new Date(localOrder.createdAt).getTime();
                    const now = Date.now();
                    
                    const timeElapsedMs = now - createdAt;
                    const oneMinuteMs = 60 * 1000;
                    
                    if (timeElapsedMs < oneMinuteMs) {
                        const remainingSeconds = Math.ceil((oneMinuteMs - timeElapsedMs) / 1000);
                        
                        const waitText = `
◆ 𝐖𝐀𝐈𝐓𝐈𝐍𝐆 𝐅𝐎𝐑 𝐎𝐓𝐏 ◆
────────────────────────
  *Nomor*   : \`${phone}\`
  *Status*  : Sedang Menunggu SMS OTP...
  *Estimasi* : Masuk dalam ${remainingSeconds} detik
────────────────────────
Sistem sedang memproses penerimaan SMS OTP secara aman. Silakan klik **Cek Kode OTP** kembali setelah tombol hitung mundur selesai.
                        `.trim();
                        
                        await sendButtons(from, "𝐖𝐀𝐈𝐓𝐈𝐍𝐆 𝐎𝐓𝐏", waitText, 'NakunBOT OTP System', [
                            { displayText: 'Cek Kode OTP', id: `otp_status:${orderId}` },
                            { displayText: 'Menu Utama', id: 'menu' }
                        ]);
                    } else {
                        const otpSuccessText = `
◆ 𝐊𝐎𝐃𝐄 𝐎𝐓𝐏 𝐃𝐈𝐓𝐄𝐑𝐈𝐌𝐀 ◆
────────────────────────
  *Nomor*   : \`${phone}\`
  *Kode OTP* : *${otpCode}*
────────────────────────

✉️ *Pesan Lengkap*:
\`\`\`
WhatsApp OTP Code: ${otpCode}
\`\`\`

Terima kasih telah memesan di NakunStore!
                        `.trim();

                        await sendButtons(from, "𝐎𝐓𝐏 𝐑𝐄𝐂𝐄𝐈𝐕𝐄𝐃", otpSuccessText, 'NakunBOT OTP System', [
                            { displayText: 'Menu Utama', id: 'menu' }
                        ]);
                    }
                } else {
                    await sock.sendMessage(from, { text: 'Transaksi OTP tidak ditemukan atau telah kadaluwarsa.' });
                }
            } catch (err) {
                console.error(err);
                await sock.sendMessage(from, { text: 'Terjadi kesalahan saat memeriksa status OTP.' });
            }
            return;
        }
    }
};

// ==========================================
// HELPER FUNCTION: ORDER PHONE NUMBER & DELIVER
// ==========================================
async function executeOtpDelivery(sock, from, provState, triggerKey, sendButtons) {
    try {
        const { country, price, orderId } = provState;

        // Get random number and code pair from local database
        const otpPair = getRandomOtpPair();

        if (otpPair) {
            const rawPhone = otpPair.phone;
            const otpCode = otpPair.code;

            // Save this mapping locally so status checker retrieves it
            saveLocalOtpOrder(orderId, {
                phone: rawPhone,
                code: otpCode
            });

            const caption = `
◆ 𝐏𝐄𝐌𝐁𝐀𝐘𝐀𝐑𝐀𝐍 𝐋𝐔𝐍𝐀𝐒 ◆
────────────────────────
Nomor virtual WhatsApp Anda berhasil dipesan:

  *Nomor*: \`+${rawPhone.replace(/[^0-9]/g, '')}\`
  *Negara*: ${country} 🇮🇩
  *Aktif*: 15-20 Menit
────────────────────────

*Langkah Selanjutnya:*
1. Masukkan nomor di atas ke aplikasi WhatsApp Anda.
2. Minta pengiriman kode verifikasi (SMS).
3. Setelah meminta OTP di WA, klik tombol **Cek Kode OTP** di bawah ini untuk melihat kodenya!
            `.trim();

            await sendButtons(from, "𝐎𝐓𝐏 𝐎𝐑𝐃𝐄𝐑 𝐑𝐄𝐀𝐃𝐘", caption, 'NakunBOT OTP System', [
                { displayText: 'Cek Kode OTP', id: `otp_status:${orderId}` }
            ]);

            // Sync order to Testimony / Google Sheets if available
            const formatRupiah = (nom) => `Rp${nom.toLocaleString('id-ID')}`;
            const waktu = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
            
            // Try notifying owner
            try {
                await sock.sendMessage('6285726013874@s.whatsapp.net', {
                    text: `*OTP ORDER COMPLETED*\n\nUser: @${from.split('@')[0]}\nNomor: ${rawPhone}\nNegara: ${country}\nNominal: ${formatRupiah(price)}\nWaktu: ${waktu}`
                });
            } catch (e) {}

        } else {
            // Local stock is empty
            const refundMessage = `
◆ 𝐒𝐓𝐎𝐊 𝐎𝐓𝐏 𝐇𝐀𝐁𝐈𝐒 ◆
────────────────────────
Pembayaran Anda sebesar *Rp${price.toLocaleString('id-ID')}* telah berhasil diterima. Namun, saat ini stok nomor virtual lokal kami sedang kosong.

Harap hubungi Admin di wa.me/6285726013874 untuk bantuan pengembalian dana (refund) 100% secara utuh atau restok manual. Kami memohon maaf atas ketidaknyamanan ini!
            `.trim();

            await sock.sendMessage(from, { text: refundMessage });
            
            // Critical warning to Owner
            try {
                await sock.sendMessage('6285726013874@s.whatsapp.net', {
                    text: `*WARNING: OTP STOCK EMPTY*\n\nUser @${from.split('@')[0]} membayar Rp${price} tetapi gagal order karena stok nomor/code di file habis!`
                });
            } catch (e) {}
        }
    } catch (err) {
        console.error('Otp execution failed:', err);
        await sock.sendMessage(from, { 
            text: `Terjadi kendala teknis saat memesan nomor OTP. Harap hubungi Admin di wa.me/6285726013874 untuk bantuan manual.` 
        });
    }
}
