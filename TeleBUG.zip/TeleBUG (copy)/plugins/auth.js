const { Markup } = require('telegraf');
const { registerUser, loginUser, getUserByTelegramId } = require('../lib/db');

module.exports = (bot) => {
    const ownerID = '7548346607';
    const createAccStates = new Map();

    // /register <usn> <pwd>
    bot.command('register', async (ctx) => {
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.reply('⚠️ Format salah! Gunakan: /register <username> <password>');
        }
        const username = args[1];
        const password = args[2];
        const res = await registerUser(username, password, ctx.from.id);
        if (res.success) {
            ctx.reply(`✅ Berhasil mendaftar!\n👤 Username: ${username}\n🔑 Silakan login menggunakan /login ${username} ${password}`);
        } else {
            ctx.reply(`❌ Gagal: ${res.message}`);
        }
    });

    // /login <usn> <pwd>
    bot.command('login', async (ctx) => {
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.reply('⚠️ Format salah! Gunakan: /login <username> <password>');
        }
        const username = args[1];
        const password = args[2];
        const res = await loginUser(username, password, ctx.from.id);
        if (res.success) {
            await ctx.reply(`✅ Login Berhasil! Selamat datang, ${username}.`);
            const { sendMainMenu } = require('../lib/menu');
            await sendMainMenu(ctx);
        } else {
            ctx.reply(`❌ Gagal: ${res.message}`);
        }
    });

    // Logout logic
    bot.command('logout', async (ctx) => {
        await handleLogout(ctx);
    });

    bot.action('logout', async (ctx) => {
        await handleLogout(ctx);
        await ctx.answerCbQuery('Berhasil logout.');
    });

    async function handleLogout(ctx) {
        const { GoogleSpreadsheet } = require('google-spreadsheet');
        const { JWT } = require('google-auth-library');
        const path = require('path');
        const SPREADSHEET_ID = '1R6xjfPHdxouVoVMra_NRwYPw3cSE2ME74j64feYsloY';
        const CREDS_PATH = path.join(__dirname, '../credentials.json');
        
        const creds = require(CREDS_PATH);
        const auth = new JWT({
            email: creds.client_email,
            key: creds.private_key,
            scopes: ['https://www.googleapis.com/auth/spreadsheets'],
        });
        const doc = new GoogleSpreadsheet(SPREADSHEET_ID, auth);
        await doc.loadInfo();
        const sheet = doc.sheetsByTitle['Data Users'];
        const rows = await sheet.getRows();
        const row = rows.find(r => (r.get('TelegramID') || '').toString() === ctx.from.id.toString());
        
        if (row) {
            row.set('TelegramID', ''); // Clear session
            await row.save();
            await ctx.reply('✅ Berhasil logout. Silakan ketik /start untuk login kembali.');
        } else {
            await ctx.reply('⚠️ Anda belum login.');
        }
    }

    // Interactive Create Account Flow (triggered by buttons in menu.js)
    bot.action(['create_user_admin', 'create_user_owner', 'create_admin_owner'], async (ctx) => {
        const isOwner = ctx.from.id.toString() === ownerID;
        const user = await getUserByTelegramId(ctx.from.id);
        const userRole = user ? user.Role.toLowerCase() : (isOwner ? 'owner' : null);

        if (userRole !== 'owner' && userRole !== 'admin') {
            return ctx.answerCbQuery('❌ Akses ditolak!');
        }

        const action = ctx.match[0];
        let targetRole = 'user';
        if (action === 'create_admin_owner') targetRole = 'admin';

        createAccStates.set(ctx.from.id, { 
            step: 'WAIT_USN', 
            userRole, 
            targetRole 
        });

        await ctx.answerCbQuery();
        await ctx.reply('👤 𝐌𝐚𝐬𝐮𝐤𝐤𝐚𝐧 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞 𝐮𝐧𝐭𝐮𝐤 𝐚𝐤𝐮𝐧 𝐛𝐚𝐫𝐮:');
    });

    bot.action('delete_account_owner', async (ctx) => {
        const isOwner = ctx.from.id.toString() === ownerID;
        if (!isOwner) return ctx.answerCbQuery('❌ Akses ditolak!');

        createAccStates.set(ctx.from.id, { step: 'WAIT_DELETE_USN' });
        await ctx.answerCbQuery();
        await ctx.reply('🗑️ 𝐌𝐚𝐬𝐮𝐤𝐤𝐚𝐧 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞 𝐚𝐤𝐮𝐧 𝐲𝐚𝐧𝐠 𝐢𝐧𝐠𝐢𝐧 𝐝𝐢𝐡𝐚𝐩𝐮𝐬:');
    });

    // Handle interactive inputs
    bot.on('text', async (ctx, next) => {
        const state = createAccStates.get(ctx.from.id);
        if (!state) return next();

        const input = ctx.message.text.trim();

        // Deletion Flow
        if (state.step === 'WAIT_DELETE_USN') {
            const { deleteUser } = require('../lib/db');
            createAccStates.delete(ctx.from.id);
            const res = await deleteUser(input);
            if (res.success) {
                ctx.reply(`✅ 𝐀𝐤𝐮𝐧 '${input}' 𝐛𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐝𝐢𝐡𝐚𝐩𝐮𝐬 𝐝𝐚𝐫𝐢 𝐝𝐚𝐭𝐚𝐛𝐚𝐬𝐞.`);
            } else {
                ctx.reply(`❌ Gagal: ${res.message}`);
            }
            return;
        }

        if (state.step === 'WAIT_USN') {
            createAccStates.set(ctx.from.id, { ...state, step: 'WAIT_PWD', username: input });
            return ctx.reply('🔑 𝐌𝐚𝐬𝐮𝐤𝐤𝐚𝐧 𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝 𝐮𝐧𝐭𝐮𝐤 𝐚𝐤𝐮𝐧 𝐛𝐚𝐫𝐮:');
        }

        if (state.step === 'WAIT_PWD') {
            createAccStates.set(ctx.from.id, { ...state, step: 'WAIT_BAL', password: input });
            let prompt = '💰 𝐌𝐚𝐬𝐮𝐤𝐤𝐚𝐧 𝐒𝐚𝐥𝐝𝐨 𝐮𝐧𝐭𝐮𝐤 𝐚𝐤𝐮𝐧 𝐛𝐚𝐫𝐮:';
            if (state.userRole === 'admin') prompt += '\n(𝐌𝐚𝐤𝐬𝐢𝐦𝐚𝐥 𝐑𝐩 𝟓𝟎.𝟎𝟎𝟎)';
            return ctx.reply(prompt);
        }

        if (state.step === 'WAIT_BAL') {
            const balance = parseInt(input.replace(/\D/g, ''));
            if (isNaN(balance)) return ctx.reply('⚠️ Masukkan angka nominal saldo!');

            // Admin Limit Check
            if (state.userRole === 'admin' && balance > 50000) {
                return ctx.reply('❌ Admin hanya bisa memberi saldo maksimal Rp 50.000. Masukkan ulang:');
            }

            const { username, password, targetRole } = state;
            createAccStates.delete(ctx.from.id);

            const res = await registerUser(username, password, '', targetRole, balance);
            if (res.success) {
                ctx.reply(`✅ 𝐀𝐤𝐮𝐧 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐃𝐢𝐛𝐮𝐚𝐭!\n\n👤 Username: ${username}\n🔑 Password: ${password}\n🎭 Role: ${targetRole.toUpperCase()}\n💰 Saldo: Rp ${balance.toLocaleString('id-ID')}`);
            } else {
                ctx.reply(`❌ Gagal: ${res.message}`);
            }
        }
    });

    // Legacy Command /createacc (still works)
    bot.command('createacc', async (ctx) => {
        const ownerID = '7548346607';
        const isOwner = ctx.from.id.toString() === ownerID;
        const user = await getUserByTelegramId(ctx.from.id);
        const userRole = user ? user.Role.toLowerCase() : (isOwner ? 'owner' : null);

        if (userRole !== 'owner' && userRole !== 'admin') return;

        const args = ctx.message.text.split(' ');
        if (args.length < 5) return ctx.reply('⚠️ Format: /createacc <usn> <pwd> <role:user/admin> <balance>');

        const username = args[1];
        const password = args[2];
        const targetRole = args[3].toLowerCase();
        const balance = parseInt(args[4]);

        if (userRole === 'admin') {
            if (targetRole !== 'user' || balance > 50000) return ctx.reply('❌ Admin hanya bisa buat User (Max 50rb)');
        }

        const res = await registerUser(username, password, '', targetRole, balance);
        if (res.success) ctx.reply(`✅ Akun ${targetRole} dibuat!`);
        else ctx.reply(`❌ Gagal: ${res.message}`);
    });
};
