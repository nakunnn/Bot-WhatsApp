const { Markup } = require('telegraf');
const path = require('path');
const fs = require('fs');

module.exports = (bot) => {
    const { sendMainMenu } = require('../lib/menu');
    const userStates = new Map();

    bot.action('deposit', async (ctx) => {
        const { getUserByTelegramId } = require('../lib/db');
        const userData = await getUserByTelegramId(ctx.from.id);
        if (!userData) return ctx.answerCbQuery('⚠️ Silakan login terlebih dahulu!', { show_alert: true });

        const message = `
───────『𝐃𝐄𝐏𝐎𝐒𝐈𝐓 𝐌𝐄𝐍𝐔』───────

════════════════════════════
╰┈➤ 𝐒𝐭𝐚𝐭𝐮𝐬 : 𝐎𝐧𝐥𝐢𝐧𝐞 🟢
╰┈➤ 𝐌𝐞𝐭𝐨𝐝𝐞 : 𝐐𝐑𝐈𝐒 (𝐌𝐚𝐧𝐮𝐚𝐥)
════════════════════════════
 Silakan pilih salah satu metode deposit
 di bawah ini untuk melanjutkan.
        `.trim();

        const keyboard = Markup.inlineKeyboard([
            [Markup.button.callback('𝐐𝐑𝐈𝐒 (𝐌𝐚𝐧𝐮𝐚𝐥)', 'pay_qris')],
            [Markup.button.callback('← 𝐊𝐄𝐌𝐁𝐀𝐋𝐈', 'back_start')]
        ]);

        try {
            await ctx.editMessageCaption(
                message.replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1'),
                {
                    parse_mode: 'MarkdownV2',
                    ...keyboard
                }
            );
        } catch (e) {
            await ctx.editMessageText(
                message.replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1'),
                {
                    parse_mode: 'MarkdownV2',
                    ...keyboard
                }
            ).catch(() => { });
        }
    });

    // QRIS Flow
    bot.action('pay_qris', async (ctx) => {
        userStates.set(ctx.from.id, { step: 'WAITING_NOMINAL', type: 'QRIS' });
        await ctx.answerCbQuery();
        await ctx.reply('✍️ 𝐒𝐢𝐥𝐚𝐤𝐚𝐧 𝐦𝐚𝐬𝐮𝐤𝐤𝐚𝐧 𝐧𝐨𝐦𝐢𝐧𝐚𝐥 𝐝𝐞𝐩𝐨𝐬𝐢𝐭 𝐀𝐧𝐝𝐚\n\n(𝐂𝐨𝐧𝐭𝐨𝐡: 𝟏𝟎𝟎𝟎𝟎)');
    });

    bot.on('text', async (ctx, next) => {
        const state = userStates.get(ctx.from.id);
        if (state && state.step === 'WAITING_NOMINAL' && state.type === 'QRIS') {
            const amount = parseInt(ctx.message.text.replace(/\D/g, ''));
            if (isNaN(amount) || amount < 1000) {
                return ctx.reply('⚠️ 𝐍𝐨𝐦𝐢𝐧𝐚𝐥 𝐭𝐢𝐝𝐚𝐤 𝐯𝐚𝐥𝐢𝐝. 𝐌𝐢𝐧𝐢𝐦𝐚𝐥 𝐝𝐞𝐩𝐨𝐬𝐢𝐭 𝐚𝐝𝐚𝐥𝐚𝐡 𝐑𝐩 𝟏.𝟎𝟎𝟎');
            }

            userStates.set(ctx.from.id, { step: 'HAS_NOMINAL', amount, type: 'QRIS' });
            const { generateDynamicQRIS, buildQRImage } = require('../lib/qris');
            try {
                const waitMsg = await ctx.reply('⏳ 𝐒𝐞𝐝𝐚𝐧𝐠 𝐦𝐞𝐧𝐠𝐡𝐚𝐬𝐢𝐥𝐤𝐚𝐧 𝐐𝐑𝐈𝐒...');
                const qrisString = generateDynamicQRIS(amount);
                const qrBuffer = await buildQRImage(qrisString);

                await ctx.replyWithPhoto(
                    { source: qrBuffer },
                    {
                        caption: `
╭❰ 𝐐𝐑𝐈𝐒 𝐃𝐈𝐍𝐀𝐌𝐈𝐒 ❱
│ ⟡ 𝐍𝐨𝐦𝐢𝐧𝐚𝐥 : Rp ${amount.toLocaleString('id-ID')}
│ ⟡ 𝐔𝐧𝐭𝐮𝐤   : 𝐍𝐚𝐤𝐮𝐧 𝐒𝐭𝐨𝐫𝐞
╰────────────❱

𝐒𝐢𝐥𝐚𝐤𝐚𝐧 𝐬𝐞𝐥𝐞𝐬𝐚𝐢𝐤𝐚𝐧 𝐩𝐞𝐦𝐛𝐚𝐲𝐚𝐫𝐚𝐧 𝐝𝐚𝐧 𝐤𝐥𝐢𝐤 𝐭𝐨𝐦𝐛𝐨𝐥 𝐝𝐢 𝐛𝐚𝐰𝐚𝐡.
                        `.trim(),
                        ...Markup.inlineKeyboard([
                            [Markup.button.callback('𝐒𝐔𝐃𝐀𝐇 𝐁𝐀𝐘𝐀𝐑', 'done_payment')]
                        ])
                    }
                );
                await ctx.deleteMessage(waitMsg.message_id).catch(() => { });
            } catch (err) {
                console.error(err);
                ctx.reply('❌ 𝐓𝐞𝐫𝐣𝐚𝐝𝐢 𝐤𝐞𝐬𝐚𝐥𝐚𝐡𝐚𝐧 𝐬𝐚𝐚𝐭 𝐦𝐞𝐧𝐠𝐡𝐚𝐬𝐢𝐥𝐤𝐚𝐧 𝐐𝐑𝐈𝐒.');
            }
        } else {
            return next();
        }
    });

    bot.action('done_payment', async (ctx) => {
        const state = userStates.get(ctx.from.id);
        if (!state || !state.amount) return ctx.answerCbQuery('⚠️ Sesi kedaluwarsa. Silakan ulang deposit.');

        userStates.set(ctx.from.id, { ...state, step: 'WAITING_PROOF' });
        await ctx.answerCbQuery();
        await ctx.reply('📸 𝐒𝐢𝐥𝐚𝐤𝐚𝐧 𝐤𝐢𝐫𝐢𝐦𝐤𝐚𝐧 𝐛𝐮𝐤𝐭𝐢 𝐭𝐫𝐚𝐧𝐬𝐟𝐞𝐫 (𝐒𝐜𝐫𝐞𝐞𝐧𝐬𝐡𝐨𝐭) 𝐀𝐧𝐝𝐚.');
    });

    bot.on('photo', async (ctx, next) => {
        const state = userStates.get(ctx.from.id);
        if (state && state.step === 'WAITING_PROOF') {
            const amount = state.amount;
            userStates.delete(ctx.from.id);
            const ownerID = '7548346607';
            
            try {
                await ctx.telegram.sendPhoto(ownerID, ctx.message.photo[ctx.message.photo.length - 1].file_id, {
                    caption: `🔔 𝐁𝐮𝐤𝐭𝐢 𝐏𝐞𝐦𝐛𝐚𝐲𝐚𝐫𝐚𝐧 𝐁𝐚𝐫𝐮!\n\n👤 𝐃𝐚𝐫𝐢: ${ctx.from.first_name} (${ctx.from.id})\n💬 Username: @${ctx.from.username || '-'}\n💰 Nominal: Rp ${amount.toLocaleString('id-ID')}\n💳 Metode: QRIS`,
                    ...Markup.inlineKeyboard([
                        [Markup.button.callback('𝐀𝐂𝐂𝐄𝐏𝐓', `acc_dep:${ctx.from.id}:${amount}:${ctx.from.username || '-'}`)]
                    ])
                });

                await ctx.reply('✅ 𝐓𝐞𝐫𝐢𝐦𝐚 𝐤𝐚𝐬𝐢𝐡! 𝐁𝐮𝐤𝐭𝐢 𝐩𝐞𝐦𝐛𝐚𝐲𝐚𝐫𝐚𝐧 𝐀𝐧𝐝𝐚 𝐭𝐞𝐥𝐚𝐡 𝐝𝐢𝐤𝐢𝐫𝐢𝐦 𝐤𝐞 𝐎𝐰𝐧𝐞𝐫. 𝐌𝐨𝐡𝐨𝐧 𝐭𝐮𝐧𝐠𝐠𝐮 𝐤𝐨𝐧𝐟𝐢𝐫𝐦𝐚𝐬𝐢.');
            } catch (err) {
                console.error(err);
                ctx.reply('❌ 𝐆𝐚𝐠𝐚𝐥 𝐦𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐛𝐮𝐤𝐭𝐢 𝐤𝐞 𝐎𝐰𝐧𝐞𝐫.');
            }
        } else {
            return next();
        }
    });

    bot.action(/^acc_dep:(\d+):(\d+):(.+)$/, async (ctx) => {
        const ownerID = '7548346607';
        if (ctx.from.id.toString() !== ownerID) return ctx.answerCbQuery('❌ Hanya owner yang bisa ACC!');

        const userId = ctx.match[1];
        const amount = parseInt(ctx.match[2]);
        const username = ctx.match[3];

        try {
            const { updateBalance } = require('../lib/db');
            const newBalance = await updateBalance(userId, amount);
            await ctx.telegram.sendMessage(userId, `✅ 𝐃𝐞𝐩𝐨𝐬𝐢𝐭 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥!\n\n💰 𝐒𝐚𝐥𝐝𝐨 𝐦𝐚𝐬𝐮𝐤: Rp ${amount.toLocaleString('id-ID')}\n💳 𝐓𝐨𝐭𝐚𝐥 𝐬𝐚𝐥𝐝𝐨: Rp ${newBalance.toLocaleString('id-ID')}`);
            await ctx.editMessageCaption(`✅ 𝐃𝐞𝐩𝐨𝐬𝐢𝐭 𝐓𝐞𝐥𝐚𝐡 𝐃𝐢-𝐀𝐂𝐂!\n\n👤 𝐔𝐬𝐞𝐫: ${userId}\n💰 Nominal: Rp ${amount.toLocaleString('id-ID')}\n📅 Status: 𝐒𝐮𝐤𝐬𝐞𝐬`).catch(() => { });
            await ctx.answerCbQuery('✅ Deposit berhasil di-ACC!');
        } catch (err) {
            console.error(err);
            ctx.answerCbQuery('❌ Terjadi kesalahan saat ACC.');
        }
    });

    bot.action('back_start', async (ctx) => {
        await ctx.answerCbQuery();
        await sendMainMenu(ctx, true);
    });
};
