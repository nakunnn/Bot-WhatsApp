const { sendMainMenu } = require('../lib/menu');

const getProgressBar = (percent) => {
    const total = 20; // 20 blocks for a longer, more premium-looking bar
    const active = Math.round((percent / 100) * total);
    const inactive = total - active;
    return '▰'.repeat(active) + '▱'.repeat(inactive); // Premium futuristic indicators
};

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

module.exports = (bot) => {
    bot.start(async (ctx) => {
        try {
            // 1. Instantly reply with 0% loading bar
            const loadingMsg = await ctx.reply(`𝐋𝐨𝐚𝐝𝐢𝐧𝐠 𝐌𝐞𝐧𝐮...\n[▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱] 0%`);

            // 2. Start rendering the main menu and fetching user data in the background
            const menuPromise = sendMainMenu(ctx);

            // 3. Animate progress bar smoothly up to exactly 65% (perfectly between 55% and 70%)
            const targetPercent = 65;
            for (let percent = 5; percent <= targetPercent; percent += 5) {
                await delay(60); // 60ms refresh rate for high-end pacing
                const progress = getProgressBar(percent);
                await ctx.telegram.editMessageText(ctx.chat.id, loadingMsg.message_id, null, `𝐋𝐨𝐚𝐝𝐢𝐧𝐠 𝐌𝐞𝐧𝐮...\n[${progress}] ${percent}%`).catch(() => { });
            }

            // 4. Ensure the menu promise has resolved and menu is fully rendered
            await menuPromise;

            // 5. Delete the loading message gracefully when the menu appears (exactly at 65%)
            await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => { });
        } catch (err) {
            console.error('Error in /start command:', err);
            // Fallback: directly try to send menu if anything goes wrong
            await sendMainMenu(ctx).catch(() => { });
        }
    });
};
