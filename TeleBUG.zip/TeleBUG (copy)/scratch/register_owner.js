const { registerUser } = require('../lib/db');

async function main() {
    try {
        console.log('⏳ Mendaftarkan akun owner (Telegram ID: 7548346607) ke database...');
        const res = await registerUser('nakunowner', 'owner123', '7548346607', 'owner', 0);
        if (res.success) {
            console.log('✅ Akun owner berhasil didaftarkan di Google Spreadsheet!');
            console.log('👤 Username: nakunowner');
            console.log('🔑 Password: owner123');
            console.log('🆔 TelegramID: 7548346607');
            console.log('🎭 Role: owner');
        } else {
            console.error('❌ Gagal mendaftarkan owner:', res.message);
        }
    } catch (err) {
        console.error('Error:', err);
    }
}

main();
