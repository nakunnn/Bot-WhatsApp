const { GoogleSpreadsheet } = require('google-spreadsheet');
const { JWT } = require('google-auth-library');
const path = require('path');
const fs = require('fs');

const SPREADSHEET_ID = '1R6xjfPHdxouVoVMra_NRwYPw3cSE2ME74j64feYsloY';
const CREDS_PATH = path.join(__dirname, '../credentials.json');
const SHEET_TITLE = 'Data Users';

async function main() {
    try {
        if (!fs.existsSync(CREDS_PATH)) throw new Error('File credentials.json tidak ditemukan!');
        const creds = require(CREDS_PATH);
        const auth = new JWT({
            email: creds.client_email,
            key: creds.private_key,
            scopes: ['https://www.googleapis.com/auth/spreadsheets'],
        });

        const doc = new GoogleSpreadsheet(SPREADSHEET_ID, auth);
        await doc.loadInfo();
        const sheet = doc.sheetsByTitle[SHEET_TITLE];
        const rows = await sheet.getRows();
        console.log(`=== Daftar User di Google Spreadsheet (${rows.length} Baris) ===`);
        rows.forEach((row, i) => {
            console.log(`[${i + 1}] Username: "${row.get('Username')}", Password: "${row.get('Password')}", Role: "${row.get('Role')}", TelegramID: "${row.get('TelegramID')}", Balance: Rp ${row.get('Balance')}`);
        });
        console.log('================================================');
    } catch (err) {
        console.error('Error fetching sheet rows:', err);
    }
}

main();
